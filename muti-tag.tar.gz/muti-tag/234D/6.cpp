﻿#include <bits/stdc++.h>
using namespace std;
#define v vector
#define f first
#define s second
#define p pair
#define ll long long int
#define fr(i, a, b) for (ll i = a; i < b; i++)
#define frn(i, a, b) for (ll i = a; i > b; i--)
#define mk make_pair
#define pb push_back
const ll mod = 1e9 + 7;
const ll inf = 1e18;
const double EPS = 1E-9;
ll m, k, n;
v<ll> arr;
v<p<string, ll>> brr;
v<bool> drr(105, false);
v<ll> high(105, 0);
v<ll> low(105, 0);
int main(void)
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    cin >> m >> k;
    arr.resize(k);
    fr(i, 0, k)
    {
        cin >> arr[i];
        drr[arr[i]] = true;
    }
    cin >> n;
    brr.resize(n);
    fr(i, 0, n)
    {
        cin >> brr[i].f >> brr[i].s;
        ll fav, may_be, hate;
        fav = may_be = hate = 0;
        fr(j, 0, brr[i].s)
        {
            ll x;
            cin >> x;
            if (drr[x])
            {
                fav++;
            }
            else if (x == 0)
            {
                may_be++;
            }
            else
            {
                hate++;
            }
        }
        low[i] = fav + max((ll)0, may_be - (m - k - hate));
        high[i] = min(fav + may_be, k);
    }
    fr(i, 0, n)
    {
        ll lower = 1, upper = 0;
        fr(j, 0, n)
        {
            if (i == j)
            {
                continue;
            }
            if (high[i] < low[j])
            {
                upper = 1;
            }
            if (low[i] < high[j])
            {
                lower = 0;
            }
        }
        if (upper)
        {
            cout << "1" << endl;
        }
        else if (lower)
        {
            cout << "0" << endl;
        }
        else
        {
            cout << "2" << endl;
        }
    }
}