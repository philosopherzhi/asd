﻿/* -*- coding: utf-8 -*-
 *
 * 0234D.cc: D. Cinema
 */

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <list>
#include <queue>
#include <deque>
#include <algorithm>
#include <numeric>
#include <utility>
#include <complex>
#include <functional>

using namespace std;

/* constant */

const int MAX_M = 100;
const int MAX_N = 100;

/* typedef */

/* global variables */

bool fvs[MAX_M];
int wfs[MAX_N], bfs[MAX_N];

/* subroutines */

/* main */

int main()
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    int m, k;
    scanf("%d%d", &m, &k);
    int l = m - k;

    for (int i = 0; i < k; i++)
    {
        int ai;
        scanf("%d", &ai);
        ai--;
        fvs[ai] = true;
    }

    int n;
    scanf("%d", &n);

    for (int i = 0; i < n; i++)
    {
        char s[16];
        int d;
        scanf("%s%d", s, &d);

        int u = 0, f = 0, g = 0;
        for (int j = 0; j < d; j++)
        {
            int bj;
            scanf("%d", &bj);
            bj--;

            if (bj < 0)
                u++;
            else if (fvs[bj])
                f++;
            else
                g++;
        }

        wfs[i] = f + max(0, u - (l - g));
        bfs[i] = min(k, u + f);
        // printf("%d %d\n", wfs[i], bfs[i]);
    }

    for (int i = 0; i < n; i++)
    {
        bool wok = true;
        for (int j = 0; wok && j < n; j++)
            if (i != j)
                wok = (wfs[i] >= bfs[j]);

        bool bok = true;
        for (int j = 0; bok && j < n; j++)
            if (i != j)
                bok = (bfs[i] >= wfs[j]);

        if (wok)
            puts("0");
        else if (!bok)
            puts("1");
        else
            puts("2");
    }
    return 0;
}
