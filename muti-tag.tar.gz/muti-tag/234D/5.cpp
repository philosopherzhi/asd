﻿#include <bits/stdc++.h>
using namespace std;
int a[101] = { 0 };
struct movie
{
    string name;
    int max_fav;
    int min_fav;
};
main()
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    int m, k;
    cin >> m >> k;
    for (int i = 0; i < k; i++)
    {
        int fav;
        cin >> fav;
        a[fav] = 1;
    }
    int n;
    cin >> n;
    vector<movie> v(n);
    for (int i = 0; i < n; i++)
    {
        cin >> v[i].name;
        int actors;
        cin >> actors;
        int id, fav_actors = 0, unknown = 0;
        for (int j = 0; j < actors; j++)
        {
            cin >> id;
            if (id == 0)
                unknown++;
            else if (a[id] == 1)
                fav_actors++;
        }
        // cout<<fav_actors<<" "<<unknown<<endl;
        v[i].max_fav = min(fav_actors + unknown, k);
        v[i].min_fav = fav_actors;
        if (actors - fav_actors > m - k)
        {
            v[i].min_fav += (actors - fav_actors) - (m - k);
        }
        // cout<<v[i].min_fav<<" "<<v[i].max_fav<<endl;
    }
    // for(int i=0;i<n;i++) cout<<v[i].max_fav<<" "<<v[i].min_fav<<endl;
    for (int i = 0; i < v.size(); i++)
    {
        int flag = 1;
        for (int j = 0; j < v.size(); j++)
        {
            if (j == i)
                continue;
            if (v[i].min_fav < v[j].max_fav)
            {
                flag = 0;
                break;
            }
        }
        if (flag)
            cout << "0" << endl;
        else
        {
            int flag = 0;
            for (int j = 0; j < v.size(); j++)
            {
                if (j == i)
                    continue;
                if (v[i].max_fav < v[j].min_fav)
                {
                    flag = 1;
                    break;
                }
            }
            if (flag)
                cout << "1" << endl;
            else
                cout << "2" << endl;
        }
    }
}