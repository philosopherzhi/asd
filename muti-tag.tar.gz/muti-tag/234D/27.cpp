﻿
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
#define For(i, n) for (ll i = 0; i < n; i++)
//#define fast ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL)
#define f(a, b, c) for (ll a = b; a < c; a++)
#define mod 1000000007
//#define int long long
#define read(t)                                                                                    \
    ll t;                                                                                          \
    cin >> t;
#define rs(t)                                                                                      \
    string t;                                                                                      \
    cin >> t;
#define all(x) x.begin(), x.end()
#define fi first
#define se second
#define pii pair<ll, ll>
// g++ code.cpp -o /x
//=====================================================================================================================================//


//=====================================================================================================================================//


int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    ll n, m;
    cin >> n >> m;
    map<ll, ll> fav;
    For(i, m)
    {
        read(x);
        fav[x]++;
    }

    ll confirm = 0;
    ll prob = 0;
    ll minconf = 0;

    ll mov;
    cin >> mov;

    ll confinx[mov];
    ll probinx[mov];
    memset(confinx, 0, sizeof confinx);
    memset(probinx, 0, sizeof probinx);

    For(i, mov)
    {
        string faltu;
        cin >> faltu;
        ll y;
        cin >> y;
        ll zero = 0, pehle = 0, pehlenahi = 0, nahi = 0, hain = 0;
        For(j, y)
        {
            read(p);

            if (p == 0)
                zero++;

            else if (fav[p] == 1)
                hain++;

            else
                nahi++;
        }

        pehle = m - hain;

        pehlenahi = n - m - nahi;
        ll fu = 0;
        confinx[i] = hain + max((ll)0, (zero - pehlenahi));
        probinx[i] = hain + min(zero, pehle);
        confirm = max(confirm, confinx[i]);

        if (probinx[i] > minconf)
            minconf = probinx[i];

        if (minconf > prob)
        {
            ll temp = prob;
            prob = minconf;
            minconf = temp;
        }
    }
    For(i, mov)
    {
        if (confinx[i] == prob || probinx[i] == prob && confinx[i] >= minconf)
            cout << '0' << endl;
        else if (probinx[i] < confirm)
        {
            cout << '1' << endl;
        }
        else
            cout << '2' << endl;
    }
}
