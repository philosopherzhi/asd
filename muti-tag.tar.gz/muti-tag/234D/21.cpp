﻿#include <bits/stdc++.h>
#define MOD 1e9 + 7
using namespace std;
#define pp push_back
#define po pop_back
#define mp make_pair
#define clr(a) memset(a, 0, sizeof(a))
#define debug(x) cout << #x << ": " << x << endl
#define debug1(x) cout << #x << ": " << x << " "
#define rev(x) reverse(x.begin(), x.end())
#define int long long
#define F first
#define S second
// int a[2000];
void printvector(std::vector<int> v)
{
    for (int i = 0; i < v.size(); ++i)
    {
        cout << v[i] << " ";
    }
    cout << "" << endl;
}
void printarray(int a[], int n)
{
    for (int i = 0; i < n; ++i)
    {
        cout << a[i] << " ";
    }
    cout << "" << endl;
}


void solve()
{
    int m1, k;
    cin >> m1 >> k;
    std::map<int, int> m;
    for (int i = 0; i < k; ++i)
    {
        int z;
        cin >> z;
        m[z]++;
    }
    int k1 = k;
    int k2 = m1 - k;

    multiset<int, greater<int> > s1;
    multiset<int, greater<int> > s2;
    int n;
    cin >> n;
    pair<int, int> p[n];
    for (int i = 0; i < n; ++i)
    {
        string s;
        cin >> s;
        int d;
        cin >> d;
        int t = 0;
        int f1 = 0, f2 = 0;
        for (int h = 0; h < d; ++h)
        {

            int x;
            cin >> x;
            if (x == 0)
                t++;
            else if (m[x])
                f1++;
            else
                f2++;
        }

        s1.insert(f1 + min(k1 - f1, t));
        s2.insert(d - (f2 + min(k2 - f2, t)));

        p[i].F = d - (f2 + min(k2 - f2, t));
        p[i].S = f1 + min(k1 - f1, t);
        // cout<<p[i].F<<" "<<p[i].S<<endl;
    }
    std::vector<int> v1, v2;
    for (int i = 0; i < n; ++i)
    {
        v1.pp(p[i].F);
        v2.pp(p[i].S);
    }
    sort(v1.begin(), v1.end());
    sort(v2.begin(), v2.end());
    reverse(v1.begin(), v1.end());
    reverse(v2.begin(), v2.end());


    if (n == 1)
    {
        cout << 0 << endl;
    }
    else
    {
        for (int i = 0; i < n; ++i)
        {

            if ((v2[0] != p[i].S && p[i].F >= v2[0]) || (v2[0] == p[i].S && p[i].F >= v2[1]))
            {
                cout << 0 << endl;
            }
            else if ((v1[0] != p[i].F && p[i].S < v1[0]) || (v1[0] == p[i].F && p[i].S < v1[1]))
            {

                cout << 1 << endl;
            }
            else
            {
                cout << 2 << endl;
            }
        }
    }
}


int32_t main()
{

    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int t;
    // cin>>t;
    t = 1;
    while (t--)
        solve();

    return 0;
}