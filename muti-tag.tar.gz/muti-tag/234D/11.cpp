﻿#include <bits/stdc++.h>
#define ll long long int
using namespace std;
#define fio ios_base::sync_with_stdio(false), cin.tie(NULL), cout.tie(NULL)
#define mp make_pair
#define fi first
#define se second
#define pb push_back
#define endl "\n"
#define maxpq priority_queue<ll>
#define minpq priority_queue<ll, vector<ll>, greater<ll> >
#define vi vector<ll>
#define pii pair<ll, ll>
#define vii vector<pii>
#define for0(i, n) for (int i = 0; i < n; i++)
#define for1(i, n) for (int i = 1; i <= n; i++)
#define loop(i, a, b) for (int i = a; i < b; i++)
#define bloop(i, a, b) for (int i = a; i >= b; i--)
#define MOD 1000000007
#define INT_MAXI 9000000000000000000
#define INT_MINI -9000000000000000000

ll max(ll a, ll b)
{
    if (a > b)
        return a;
    else
        return b;
}
ll min(ll a, ll b)
{
    if (a < b)
        return a;
    else
        return b;
}

const int dx[4] = { -1, 1, 0, 0 };
const int dy[4] = { 0, 0, -1, 1 };
int XX[] = { -1, -1, -1, 0, 0, 1, 1, 1 };
int YY[] = { -1, 0, 1, -1, 1, -1, 0, 1 };


int main()
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);


    fio;
    ll k, i, j, u, v, t, x, y, n, l, r, m;

    cin >> m >> k;
    set<ll> s, s2;

    for (i = 1; i <= m; i++)
    {
        s2.insert(i);
    }


    for (i = 0; i < k; i++)
    {
        cin >> x;
        s.insert(x);
        s2.erase(x);
    }
    vector<pii> vec;
    cin >> n;

    for (i = 0; i < n; i++)
    {
        string str;
        cin >> str;
        ll siz;
        cin >> siz;
        ll mini = 0, maxi = 0, count = 0, c2 = 0, c3 = 0;

        for (j = 0; j < siz; j++)
        {
            cin >> x;
            if (x == 0)
            {
                count++;
                continue;
            }
            if (s.find(x) != s.end())
            {
                c2++;
            }
            else
            {
                c3++;
            }
        }
        ll z = s.size();
        y = min(count, z - c2);
        maxi = c2 + y;

        z = s2.size();
        y = min(count, z - c3);

        count -= y;
        mini = c2 + count;

        vec.pb(mp(mini, maxi));
    }

    for (i = 0; i < n; i++)
    {
        ll mini = vec[i].fi, maxi = vec[i].se;
        ll flag = 0;

        for (j = 0; j < n; j++)
        {
            if (i == j)
                continue;

            if (mini < vec[j].se)
            {
                flag = 1;
                break;
            }
        }
        if (flag == 0)
        {
            cout << "0" << endl;
            continue;
        }

        flag = 0;

        for (j = 0; j < n; j++)
        {
            if (i == j)
                continue;

            if (maxi < vec[j].fi)
            {
                flag = 1;
                break;
            }
        }
        if (flag == 1)
        {
            cout << 1 << endl;
            continue;
        }
        cout << 2 << endl;
    }
}
