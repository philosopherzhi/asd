﻿#include <bits/stdc++.h>
#include <sstream>

using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;

#define sz(a) int((a).size())
#define pb push_back
#define all(c) (c).begin(), (c).end()
#define tr(c, i) for (auto i = (c).begin(); i != (c).end(); i++)
#define present(c, x) ((c).find(x) != (c).end())

#define edl '\n'
#define ll long long int

#define forn(i, n) for (int i = 0; i < n; i++)
#define forni(i, j, n) for (int i = j; i < n; i++)
#define forr (i, n) for (int i = n; i >= 0; i--)
#define numb(arr, i) (int)(arr[i] - '0')

#define filecode                                                                                   \
    ifstream cin("input.txt");                                                                     \
    ofstream cout("output.txt");
#define IOFAST                                                                                     \
    ios::sync_with_stdio(false);                                                                   \
    cin.tie(0);                                                                                    \
    cout.tie(0);
#define setPrecision(n) cout << std::setprecision(n) << std::fixed;

#define MOD 1000000007
#define PI 3.14159265

bool fav[200];

int main()
{

    // IOFAST;
    filecode;
    int m, k;
    cin >> m >> k;
    int tmp;
    forn(i, k)
    {
        cin >> tmp;
        fav[tmp] = 1;
    }
    int n;
    cin >> n;
    string f;
    ii prs[n];
    int tot;
    int fl, nfl, scr, nsr, t;
    int bs = 0, bf = 0;
    int as = 0, af = 0;
    forn(i, n)
    {
        cin >> f;
        prs[i].first = prs[i].second = 0;
        cin >> t;
        scr = 0;
        fl = k;
        nfl = m - k;
        nsr = 0;
        forn(j, t)
        {
            cin >> tmp;
            if (tmp == 0)
                nsr++;
            else if (fav[tmp])
                fl--, scr++;
            else
                nfl--;
        }
        prs[i].first = scr + max(0, nsr - nfl);
        prs[i].second = scr + min(fl, nsr);
        if (prs[i].second > bf)
        {
            af = bf;
            bf = prs[i].second;
        }
        else if (prs[i].second > af)
        {
            af = prs[i].second;
        }
        if (prs[i].first > bs)
        {
            as = bs;
            bs = prs[i].first;
        }
        else if (prs[i].first > as)
        {
            as = prs[i].first;
        }
    }
    int otf, ots;
    forn(i, n)
    {
        if (prs[i].second == bf)
            ots = af;
        else
            ots = bf;
        if (prs[i].first == bs)
            otf = as;
        else
            otf = bs;

        if (prs[i].first >= ots)
            cout << 0 << edl;
        else if (prs[i].second >= otf)
            cout << 2 << edl;
        else
            cout << 1 << edl;
    }
}
