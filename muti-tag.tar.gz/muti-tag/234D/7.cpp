﻿#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
#define pb push_back

const int N = 105;
int maxi[N], mini[N];
set<int> goodn;
int good[N], bad[N], cnt[N], empty[N];
main()
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    int m, k;
    scanf("%d %d", &m, &k);
    for (int i = 1; i <= k; i++)
    {
        int x;
        scanf("%d", &x);
        goodn.insert(x);
    }
    int n;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
    {
        string s;
        cin >> s;
        scanf("%d", &cnt[i]);
        for (int j = 1; j <= cnt[i]; j++)
        {
            int x;
            scanf("%d", &x);
            if (goodn.find(x) != goodn.end())
                good[i]++;
            else if (x != 0)
                bad[i]++;
            else
                empty[i]++;
        }
        maxi[i] = good[i] + min(k - good[i], empty[i]);
        mini[i] = good[i] + empty[i] - min(m - k - bad[i], empty[i]);
    }
    for (int i = 1; i <= n; i++)
    {
        int other_min = 0, other_max = 0;
        for (int j = i - 1; j >= 1; j--)
        {
            other_min = max(other_min, mini[j]);
            other_max = max(other_max, maxi[j]);
        }
        for (int j = i + 1; j <= n; j++)
        {
            other_min = max(other_min, mini[j]);
            other_max = max(other_max, maxi[j]);
        }
        if (maxi[i] < other_min)
            printf("1\n");
        else if (mini[i] >= other_max)
            printf("0\n");
        else
            printf("2\n");
    }
    return 0;
}