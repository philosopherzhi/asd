﻿#include <bits/stdc++.h>
using namespace std;

int m, k, n, d, a, mn[105], mx[105];
bool f[105] = {};
string s;
vector<int> good, bad;
bitset<105> bs;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    cin >> m >> k;

    for (int i = 0; i < k; i++)
    {
        cin >> a;
        f[a] = 1;
    }

    for (int i = 1; i <= m; i++)
    {
        if (f[i])
        {
            good.push_back(i);
        }
        else
        {
            bad.push_back(i);
        }
    }

    cin >> n;

    for (int i = 0; i < n; i++)
    {
        cin >> s >> d;

        bs.reset();
        int zero = 0, cur = 0;
        for (int j = 0; j < d; j++)
        {
            cin >> a;
            if (a == 0)
            {
                zero++;
            }
            else
            {
                if (f[a])
                {
                    cur++;
                }
                bs[a] = 1;
            }
        }

        int tmp = zero;
        mn[i] = mx[i] = cur;

        for (int j = 0; j < bad.size() && tmp; j++)
        {
            if (!bs[bad[j]] && tmp)
            {
                tmp--;
            }
        }

        for (int j = 0; j < good.size() && tmp; j++)
        {
            if (!bs[good[j]] && tmp)
            {
                mn[i]++;
                tmp--;
            }
        }

        tmp = zero;
        for (int j = 0; j < good.size() && tmp; j++)
        {
            if (!bs[good[j]] && tmp)
            {
                mx[i]++;
                tmp--;
            }
        }
    }

    for (int i = 0; i < n; i++)
    {
        // cout << i << ": " << mn[i] << " " << mx[i] << '\n';
        bool x = 1, y = 1;

        for (int j = 0; j < n; j++)
        {
            if (i == j)
            {
                continue;
            }

            if (mn[i] < mx[j])
            {
                x = 0;
            }

            if (mx[i] < mn[j])
            {
                y = 0;
            }
        }

        if (x)
        {
            cout << "0\n";
        }
        else if (y)
        {
            cout << "2\n";
        }
        else
        {
            cout << "1\n";
        }
    }

    return 0;
}