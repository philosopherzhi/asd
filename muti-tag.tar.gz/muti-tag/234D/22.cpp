﻿#include <bits/stdc++.h>
#define int long long int // comment for large arrays
#define pll pair<int, int>
#define dbl long double
#define ff first
#define ss second
#define endl "\n"
#define mod 1000000007
#define eps 0.00000001
#define inf 1000000000000000001
#define all(x) (x).begin(), (x).end()
#define LB(v, x) (lower_bound(all(v), x) - v.begin())
#define UB(v, x) (upper_bound(all(v), x) - v.begin())
#define size(x) (int)(x).size()
#define pb(x) push_back(x)
#define pf(x) push_front(x)
#define popb() pop_back()
#define popf() pop_front()
#define mp(x, y) make_pair((x), (y))
#define vec(dt) vector<dt>
#define vv(dt) vector<vector<dt> >
#define fastio(x)                                                                                  \
    ios_base::sync_with_stdio(x);                                                                  \
    cin.tie(NULL)
#define init(v, s) memset(v, s, sizeof(v))
#define bug(x)                                                                                     \
    cerr << "LINE: " << __LINE__ << " || click to see test details " << #x << " = " << x << endl
#define loop(i, s, n) for (int i = s; i < n; i++)
using namespace std;


bool f(vec(int) & B, vec(int) & W, int j)
{
    loop(i, 0, size(B))
    {
        if (i == j)
            continue;
        if (W[j] < B[i])
            return false;
    }
    return true;
}


signed main()
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    fastio(0);
    int m, k;
    cin >> m >> k;
    set<int> fav, nfav;
    loop(i, 1, m + 1) nfav.insert(i);
    loop(i, 0, k)
    {
        int x;
        cin >> x;
        fav.insert(x);
        nfav.erase(x);
    }
    int n, wmax = -1, bmax = -1;
    cin >> n;
    vec(int)B(n, 0), W(n, 0);
    loop(i, 0, n)
    {
        string s;
        cin >> s;
        int d;
        cin >> d;
        vec(int)a(d);
        int good = 0, x, y, z; // x - best, y - worst case
        x = y = z = 0;
        set<int> s1 = fav, s2 = nfav;
        loop(i, 0, d) cin >> a[i];
        loop(i, 0, d) if (a[i] == 0) z++;
        else if (s1.find(a[i]) != s1.end())
        {
            y++;
            x++;
            s1.erase(a[i]);
        }
        else s2.erase(a[i]);

        x += min(z, size(s1));
        y += (z - min(z, size(s2)));

        B[i] = x;
        W[i] = y;
        wmax = max(wmax, W[i]);
        bmax = max(bmax, B[i]);
    }

    // cout<<endl;
    // loop(i,0,n) cout<<B[i]<<" "<<W[i]<<endl;
    // cout<<wmax<<endl<<bmax<<endl<<endl;

    loop(i, 0, n)
    {
        if (B[i] < wmax)
            cout << 1 << endl;
        else if (f(B, W, i))
            cout << 0 << endl;
        else
            cout << 2 << endl;
    }


    return 0;
}
