﻿// check check
#include <vector>
#include <algorithm>
#include <fstream>
#include <queue>
#include <cstring>

#define ll long long
#define pb(x) push_back(x)

using namespace std;

const int NMAX = 105;

ifstream cin("input.txt");
ofstream cout("output.txt");

int favactors[NMAX];
bool isfavact[NMAX];
int M, K, N, maximreal, maximpotential;


struct movie
{
    string name;
    int nrfavact = 0, nrpotential = 0;
} v[NMAX];

int freq[NMAX], potfreq[NMAX], sndmaximpotential;

int main()
{
    int i, j;

    cin >> M >> K;

    for (i = 1; i <= K; ++i)
    {
        cin >> favactors[i];
        isfavact[favactors[i]] = 1;
    }


    cin >> N;
    int len;
    int x;
    for (i = 1; i <= N; ++i)
    {
        cin >> v[i].name;
        cin >> len;
        int nefav = M - K, holes = 0;
        int x[NMAX];
        for (j = 1; j <= len; ++j)
        {
            cin >> x[j];
            if (x[j] == 0)
                holes++;
            if (x[j] == 0 || isfavact[x[j]])
                v[i].nrpotential = min(K, v[i].nrpotential + 1);

            if (x[j] != 0)
            {
                if (isfavact[x[j]])
                    v[i].nrfavact = min(K, v[i].nrfavact + 1);
                else
                    nefav--;
            }
        }
        for (j = 1; j <= len; ++j)
        {
            if (x[j] == 0)
            {
                if (nefav == 0)
                    v[i].nrfavact = min(K, v[i].nrfavact + 1);
                else
                    nefav--;
            }
        }

        maximreal = max(v[i].nrfavact, maximreal);
        freq[maximreal]++;
        if (v[i].nrpotential > maximpotential)
        {
            sndmaximpotential = maximpotential;
            maximpotential = v[i].nrpotential;
        }
        else if (v[i].nrpotential > sndmaximpotential)
        {
            sndmaximpotential = v[i].nrpotential;
        }
        potfreq[maximpotential]++;
    }

    for (i = 1; i <= N; ++i)
    {
        if (v[i].nrpotential < maximreal)
        {
            cout << "1\n";
        }
        else if (v[i].nrfavact >= maximpotential
            || (v[i].nrpotential == maximpotential && v[i].nrfavact >= sndmaximpotential))
            cout << "0\n";
        else
            cout << "2\n";
    }

    return 0;
}
