﻿#include <bits/stdc++.h>
using namespace std;
const int MAX = 109;
int l[MAX], r[MAX], a[MAX], b[MAX], m, k, n;
int main()
{
    ifstream cin("input.txt");
    ofstream cout("output.txt");
    ios_base::sync_with_stdio(false), cin.tie(0), cout.tie(0);
    cin >> m >> k;
    for (int i = 0, x; i < k; i++)
        cin >> x, a[x] = 1;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        memset(b, 0, sizeof b);
        string s;
        cin >> s;
        int t, z = 0, y = 0;
        cin >> t;
        for (int i = 0, s; i < t; i++)
        {
            cin >> s;
            if (!s)
                z++;
            else
                y += a[s], b[s] = 1;
        }
        int u = 0, v = 0;
        for (int j = 1; j <= m; j++)
            if (a[j] && !b[j])
                u++;
            else if (!a[j] && !b[j])
                v++;
        int rr = min(z, u);
        r[i] = rr + y;
        l[i] = z + y - min(z, v);
    }
    for (int i = 0; i < n; i++)
    {
        bool flg1 = true, flg2 = false;
        for (int j = 0; j < n; j++)
            if (i != j)
            {
                if (r[i] < l[j])
                    flg2 = true;
                if (l[i] < r[j])
                    flg1 = false;
            }
        if (flg2)
            cout << 1 << endl;
        else if (flg1)
            cout << 0 << endl;
        else
            cout << 2 << endl;
    }
    return 0;
}