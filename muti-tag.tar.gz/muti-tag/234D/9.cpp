﻿#include <bits/stdc++.h>
using namespace std;
#define int long long
#define IOS                                                                                        \
    ios::sync_with_stdio(0);                                                                       \
    cin.tie(0);                                                                                    \
    cout.tie(0);
#define trace1(x) cerr << #x << ": " << x << endl
#define trace2(x, y) cerr << #x << ": " << x << " | " << #y << ": " << y << endl
#define trace3(x, y, z)                                                                            \
    cerr << #x << ":" << x << " | " << #y << ": " << y << " | " << #z << ": " << z << endl
#define trace4(a, b, c, d)                                                                         \
    cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d \
         << ": " << d << endl
#define trace5(a, b, c, d, e)                                                                      \
    cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d \
         << ": " << d << " | " << #e << ": " << e << endl
#define trace6(a, b, c, d, e, f)                                                                   \
    cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d \
         << ": " << d << " | " << #e << ": " << e << " | " << #f << ": " << f << endl
#define endl '\n'
int fav[200];
int32_t main()
{
    IOS;
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    int m, k;
    cin >> m >> k;
    for (int i = 0; i < k; i++)
    {
        int x;
        cin >> x;
        fav[x] = 1;
    }
    int n;
    cin >> n;
    vector<int> mi(n), mx(n);
    for (int i = 0; i < n; i++)
    {
        string s;
        cin >> s;
        int x;
        cin >> x;
        mi[i] = 0;
        mx[i] = 0;
        int zeroes = 0;
        for (int j = 0; j < x; j++)
        {
            int a;
            cin >> a;
            mi[i] += fav[a];
            zeroes += (a == 0);
        }
        mx[i] = mi[i] + min(zeroes, k - mi[i]);
        int nonfav = m - k;
        int left = nonfav - (x - mi[i] - zeroes);
        if (left < zeroes)
            mi[i] += zeroes - left;
    }
    for (int i = 0; i < n; i++)
    {
        int flag = 0;
        for (int j = 0; j < n; j++)
        {
            if (i == j)
                continue;
            if (mi[i] < mx[j])
            {
                flag = 1;
                break;
            }
        }
        if (flag == 0)
        {
            cout << 0 << endl;
            continue;
        }
        flag = 0;
        for (int j = 0; j < n; j++)
        {
            if (i == j)
                continue;
            if (mx[i] < mi[j])
            {
                flag = 1;
                break;
            }
        }
        if (flag == 1)
        {
            cout << 1 << endl;
            continue;
        }
        cout << 2 << endl;
    }
}
