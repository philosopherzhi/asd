﻿#include <iostream>
#include <cassert>
#include <algorithm>
#include <map>
#include <queue>
#include <vector>
#include <cstring>
using namespace std;


int n, m, k;
string s[5000];
int a[1000];
int sz[1000];
int fav[2000];
int f[200][200];
int used[5000];
int res[500];
int ares[500];
int main()
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    cin >> m >> k;

    for (int i = 1; i <= k; i++)
        cin >> a[i], fav[a[i]] = 1;

    cin >> n;

    int mnf = 0;
    for (int i = 1; i <= n; i++)
    {
        cin >> s[i];
        cin >> sz[i];
        int available = 0;
        for (int j = 1; j <= sz[i]; j++)
        {
            cin >> f[i][j];
            used[f[i][j]] = 1;
            if (f[i][j] == 0)
                available++;
        }
        int cnt = 0;
        int sp = 0;
        for (int j = 1; j <= m; j++)
        {
            if (fav[j] && used[j])
                cnt++;
            else
            {
                if (!fav[j] && !used[j])
                    sp++;
            }
            used[j] = 0;
        }
        cnt += max(0, min(available - sp, k));
        mnf = max(mnf, cnt);
        res[i] = cnt;
    }
    /*
    for(int i = 1; i <= n; i++) {
            cout << res[i] << ' ';

    }
    cout << mnf;
    return 0;
    */
    //	cout<<endl;
    int mxf = 0;
    int mxxf = 0;
    for (int i = 1; i <= n; i++)
    {
        int available = 0;
        for (int j = 1; j <= sz[i]; j++)
        {
            used[f[i][j]] = 1;
            if (f[i][j] == 0)
                available++;
        }
        int cnt = 0;
        int sp = 0;
        bool ok = 0;
        for (int j = 1; j <= m; j++)
        {
            if (fav[j] && used[j])
                cnt++;
            else
            {
                if (fav[j] && !used[j])
                {
                    if (available)
                        available--, cnt++, ok = 1;
                }
            }
            used[j] = 0;
        }
        ares[i] = cnt;
        if (cnt > mxf)
        {
            mxxf = mxf;
            mxf = max(mxf, cnt);
        }
        else if (cnt >= mxxf)
        {
            mxxf = cnt;
        }
    }
    //	cout << mxf << ' ' << mxxf;
    for (int i = 1; i <= n; i++)
    {
        int cnt = ares[i];
        //		cout << res[i] << "X" << ares[i] << endl;
        int xd = mxf;
        if (cnt == mxf)
            xd = mxxf;

        if (res[i] >= xd && cnt >= mnf && cnt == mxf)
            cout << 0 << endl;
        else if (cnt >= mnf)
            cout << 2 << endl;
        else
            cout << 1 << endl;
    }
    return 0;
}
