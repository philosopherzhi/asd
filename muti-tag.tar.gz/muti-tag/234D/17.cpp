﻿
#include <bits/stdc++.h>
#define int long long
#define input freopen("input.txt", "r", stdin), freopen("output.txt", "w", stdout)
using namespace std;


signed main()
{
    input;
    int n, k;
    cin >> n >> k;
    map<int, int> mp;
    for (int i = 0; i < k; i++)
    {
        int x;
        cin >> x;
        mp[x] = 1;
    }
    int t;
    cin >> t;
    int mn[t + 3], mx[t + 4];
    for (int i = 0; i < t; i++)
    {
        string s;
        cin >> s;

        int z;
        cin >> z;
        int a[z];
        int g, b;
        g = k;
        b = n - k;
        int fix = 0;
        int zo = 0;
        for (int i = 0; i < z; i++)
        {
            cin >> a[i];
            if (a[i] == 0)
                zo++;
            else if (mp[a[i]])
            {
                fix++;
                g--;
            }
            else
            {
                b--;
            }
        }
        mn[i] = fix + max(zo - b, 0LL);
        mx[i] = fix + min(zo, g);
    }
    for (int i = 0; i < t; i++)
    {
        int f1 = 0, f2 = 0;
        for (int j = 0; j < t; j++)
        {
            if (i != j)
            {
                if (mn[i] < mx[j])
                {
                    f2 = 1;
                }
                if (mx[i] < mn[j])
                {
                    f1 = 1;
                }
            }
        }
        if (!f2)
        {
            cout << "0" << endl;
        }
        else if (f1)
        {
            cout << "1" << endl;
        }
        else
        {
            cout << 2 << endl;
        }
    }
}
