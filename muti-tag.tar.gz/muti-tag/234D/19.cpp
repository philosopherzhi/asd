﻿#include <bits/stdc++.h>
using namespace std;

int aktor, many, fav[105], n, k, a;
pair<int, int> movie[105];

string nama;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    cin >> aktor >> many;
    for (int i = 0; i < many; i++)
    {
        cin >> a;
        fav[a] = 1;
    }

    cin >> n;

    for (int i = 0; i < n; i++)
    {
        cin >> nama >> k;

        int zero = 0, ada = 0, ga = 0;
        for (int j = 0; j < k; j++)
        {
            cin >> a;
            if (a == 0)
            {
                zero++;
            }
            else if (fav[a])
            {
                ada++;
            }
            else
            {
                ga++;
            }
        }

        movie[i].first = ada + max(0, zero - (aktor - many - ga));
        movie[i].second = ada + min(many - ada, zero);
    }

    for (int i = 0; i < n; i++)
    {
        int ter1 = 0, ter2 = 0;
        for (int j = 0; j < n; j++)
        {
            if (i == j)
                continue;
            ter1 = max(ter1, movie[j].first);
            ter2 = max(ter2, movie[j].second);
        }

        if (movie[i].first >= ter2)
        {
            cout << 0 << '\n';
        }
        else if (movie[i].first < ter2 && movie[i].second >= ter1)
        {
            cout << 2 << '\n';
        }
        else
        {
            cout << 1 << '\n';
        }
    }

    return 0;
}