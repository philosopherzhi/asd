﻿//  RAKSHIT KADAM
// USE LONG LONG INT ONLY WHEN ITS NECESSARY!!! OR ELSE IT MAY LEAD TO MLE OR RTE
#include <bits/stdc++.h>

// #include <ext/pb_ds/assoc_container.hpp>
// #include <ext/pb_ds/tree_policy.hpp>
// using namespace __gnu_pbds;
// #define ordered_set tree< int ,  null_type ,  less<int> ,  rb_tree_tag ,
// tree_order_statistics_node_update>
#warning !!!check the size of arrayss!!!
#define ll int
//#define ll long long
// #define int long long
#define MOD 1000000007
#define newMOD 998244353
#define MAX 300006
#define P(gg)                                                                                      \
    for (auto rax : gg)                                                                            \
    {                                                                                              \
        cout << rax << " ";                                                                        \
    }                                                                                              \
    cout << endl;
#define Need_for_speed(activated)                                                                  \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(NULL);                                                                                 \
    cout.tie(NULL)
#define satisfy                                                                                    \
    ll t;                                                                                          \
    cin >> t;                                                                                      \
    while (t--)
#define inp(n)                                                                                     \
    int n;                                                                                         \
    cin >> n
#define mp make_pair
#define pb push_back
#define endl "\n"
#define x first
#define y second
#define fore(i, a, b) for (ll i = a; i < b; i++)
#define forci(i, n) for (ll i = 0; i < n; i++)
//#define INF 2000000000000000005
#define INF 100000000
#define vi vector<ll>
#define pi 3.1415926535897932384626433832795
#define Endl endl
#define lb lower_bound
#define ub upper_bound

using namespace std;
ll ans = INF;
// ll gcd(ll a, ll b){if (b == 0)return a;return gcd(b, a % b);}
// int power(int x, unsigned int y, unsigned int m){ if (y == 0) return 1;int p = power(x, y/2, m) %
// m;  p = (p * p) % m;                                                  return (y%2 == 0)? p : (x *
// p) % m;}


// ll modInverse(int a, int m){ return power(a, m-2, m);} // if a and m are relativelyprime
ll good[103];

void solve()
{
    ll n;
    cin >> n;
    ll k;
    cin >> k;


    forci(i, k)
    {
        ll a;
        cin >> a;
        good[a] = 1;
    }
    ll t;
    cin >> t;
    string ss;
    vi v[t + 4];
    for (ll i = 0; i < t; i++)
    {
        cin >> ss;
        ll x;
        cin >> x;
        forci(j, x)
        {
            ll d;
            cin >> d;
            v[i].pb(d);
        }
    }
    ll mn[t + 3], mx[t + 4];
    ll maxx = -1;
    ll maxfix = -1;

    for (ll i = 0; i < t; i++)
    {
        ll g_a = k;
        ll g_b = n - k;
        ll fix = 0;
        ll z = 0;
        for (auto it : v[i])
        {
            if (it != 0)
            {
                if (good[it])
                {
                    fix++, g_a--;
                }
                else
                    g_b--;
            }
            else
                z++;
        }

        mn[i] = fix + max(z - g_b, 0);
        mx[i] = fix + min(z, g_a);
    }

    for (ll i = 0; i < t; i++)
    {
        bool f1 = true;
        bool f2 = false;
        for (ll j = 0; j < t; j++)
        {
            if (i != j)
            {
                if (mx[i] < mn[j])
                    f2 = true;
                if (mn[i] < mx[j])
                    f1 = false;
            }
        }
        if (f1)
            cout << 0 << endl;
        else if (f2)
            cout << 1 << endl;
        else
            cout << 2 << endl;
    }
}
signed main()
{


    Need_for_speed(activated);
    // satisfy
    //    {
    //   solve();
    //    }
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    //
    solve();
    return 0;
}
