﻿///****In the name of ALLAH, most Gracious, most Compassionate****//

#pragma GCC target("avx2")
#pragma GCC optimization("O3")
#pragma GCC optimization("unroll-loops")

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;

#define ALL(a) a.begin(), a.end()
#define FastIO                                                                                     \
    ios::sync_with_stdio(false);                                                                   \
    cin.tie(0);                                                                                    \
    cout.tie(0)
#define IN freopen("input.txt", "r+", stdin)
#define OUT freopen("output.txt", "w+", stdout)

#define DBG(a) cerr << "line " << __LINE__ << " : " << #a << " --> " << (a) << endl
#define NL cout << endl

template <class T1, class T2>
ostream& operator<<(ostream& os, const pair<T1, T2>& p)
{
    os << "{" << p.first << "," << p.second << "}";
    return os;
}

const int N = 3e5 + 5;
const int oo = 1e9 + 7;

bool ase[N];
int mn[N];
int mx[N];

int32_t main()
{
    IN;
    OUT;
    //    FastIO;
    int n, m, k;
    cin >> m >> k;
    for (int i = 0; i < k; i++)
    {
        int x;
        cin >> x;
        ase[x] = 1;
    }
    cin >> n;

    int mn_mx = -1;
    int mx_mn = oo;
    multiset<int> mx_, mn_;

    for (int i = 0; i < n; i++)
    {
        string s;
        cin >> s;
        int d;
        cin >> d;

        int un = 0;

        for (int j = 0; j < d; j++)
        {
            int x;
            cin >> x;
            if (x > 0 and ase[x])
                mn[i]++;
            else if (x == 0)
                un++;
        }

        mx[i] = min(k, mn[i] + un);
        int rem = (m - k) - (d - un - mn[i]);
        mn[i] += max(0, un - rem);

        mn_mx = max(mn_mx, mn[i]);
        mx_mn = min(mx_mn, mx[i]);

        mx_.insert(mx[i]);
        mn_.insert(mn[i]);
    }

    //    for(int i=0;i<n;i++)
    //    {
    //        DBG(i);
    //        DBG(mn[i]);
    //        DBG(mx[i]);
    //        NL;
    //    }
    for (int i = 0; i < n; i++)
    {
        mx_.erase(mx_.find(mx[i]));
        mn_.erase(mn_.find(mn[i]));

        bool can_lose = n > 1 and mn[i] < *mx_.rbegin();
        bool can_win = n == 1 or mx[i] >= *mn_.rbegin();
        if (can_lose and can_win)
        {
            cout << "2\n";
        }
        else if (can_win)
        {
            cout << "0\n";
        }
        else if (can_lose)
            cout << "1\n";
        else
            assert(0);

        mx_.insert(mx[i]);
        mn_.insert(mn[i]);
    }
}
