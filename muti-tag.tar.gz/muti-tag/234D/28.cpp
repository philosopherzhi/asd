﻿#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
using namespace __gnu_pbds;
using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef tree<ii, null_type, less<ii>, rb_tree_tag, tree_order_statistics_node_update> indexed_set;

int main()
{
    cin.tie(0);
    cout.tie(0);
    ios_base::sync_with_stdio(0);
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    int m, k;
    cin >> m >> k;
    set<int> st;
    for (int i = 0; i < k; i++)
    {
        int a;
        cin >> a;
        st.insert(a);
    }
    int n;
    cin >> n;
    vector<int> low(n, -1), high(n, -1);
    int mx = 0;
    for (int i = 0; i < n; i++)
    {
        string s;
        cin >> s;
        int d;
        cin >> d;
        int cur = 0, like = k, dis = m - k, unk = 0;
        for (int j = 0; j < d; j++)
        {
            int b;
            cin >> b;
            if (b == 0)
                unk++;
            else
            {
                if (st.count(b))
                    like--, cur++;
                else
                    dis--;
            }
        }
        low[i] = cur + min(unk - min(unk, dis), like);
        high[i] = cur + min(unk, like);
    }
    for (int i = 0; i < n; i++)
    {
        bool can = true, always = true;
        for (int j = 0; j < n; j++)
        {
            if (j == i)
                continue;
            if (high[i] < low[j])
                can = false;
            if (low[i] < high[j])
                always = false;
        }
        if (always)
            cout << 0 << "\n";
        else if (can)
            cout << 2 << "\n";
        else
            cout << 1 << "\n";
    }
    return 0;
}
