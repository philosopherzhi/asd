﻿#include <bits/stdc++.h>
//#include <ext/pb_ds/assoc_container.hpp> // Common file
//#include <ext/pb_ds/tree_policy.hpp>
#define int long long
#define pb push_back
#define ff first
#define ss second
#define ii insert
#define ld long double
#define ppb pop_back
#define nuenxfiu                                                                                   \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(NULL);                                                                                 \
    cout.tie(NULL);
#define input freopen("input.txt", "r", stdin), freopen("output.txt", "w", stdout);
#define TT                                                                                         \
    int testcases;                                                                                 \
    cin >> testcases;                                                                              \
    while (testcases--)
#define mk make_pair
#define MAX ((int)2e9 + 17)
#define N 200005
#define mod ((int)1e9 + 7)
int fact[1000007] = { 0 };
int exp(int x, int y, int p)
{
    int res = 1;
    while (y)
    {
        if (y % 2)
            res = (res * x % p) % p;
        x = (x * x) % p;
        y /= 2;
    }
    return res;
}
int expo(int x, int y)
{
    int res = 1;
    while (y)
    {
        if (y % 2)
            res = (res * x % mod) % mod;
        x = (x * x) % mod;
        y /= 2;
    }
    return res;
}
int sub(int a, int b)
{
    return (a % mod - b % mod + mod) % mod;
}
int mul(int a, int b)
{
    return ((a % mod) * (b % mod) + mod) % mod;
}
int inv(int x)
{
    return expo(x, mod - 2);
}
using namespace std;

void solve()
{
    input int m, k;
    cin >> m >> k;

    map<int, int> mp;
    for (int i = 0; i < k; i++)
    {
        int a;
        cin >> a;
        mp[a] = 1;
    }

    int t;
    cin >> t;

    int mini[t + 2];
    int maxi[t + 2];

    for (int i = 0; i < t; i++)
    {
        string s;
        cin >> s;

        int x;
        cin >> x;

        int a[x];
        int g = k;
        int b = m - k;
        int z = 0;
        int q = 0;

        for (int i = 0; i < x; i++)
        {
            cin >> a[i];
            if (a[i] == 0)
                z++;
            else if (mp[a[i]])
            {
                q++;
                g--;
            }
            else
                b--;
        }
        mini[i] = q + max(z - b, 0LL);
        maxi[i] = q + min(z, g);
    }


    for (int i = 0; i < t; i++)
    {
        int f1 = 0;
        int f2 = 0;
        for (int j = 0; j < t; j++)
        {
            if (i != j)
            {
                if (mini[i] < maxi[j])
                    f2 = 1;
                if (maxi[i] < mini[j])
                    f1 = 1;
            }
        }
        if (!f2)
            cout << 0 << endl;
        else if (f1)
            cout << 1 << endl;
        else
            cout << 2 << endl;
    }
}


signed main()
{
    nuenxfiu
        // TT
        solve();
    return 0;
}