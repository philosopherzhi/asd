﻿#include <bits/stdc++.h>
using namespace std;

using namespace std;

int n, m, T;
int v[200];
int a1[200], min1[200], max1[200];

int main()
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    scanf("%d%d", &n, &m);
    for (int i = 1, x; i <= m; i++)
        scanf("%d", &x), v[x] = 1;
    scanf("%d", &T);

    for (int k = 1; k <= T; k++)
    {
        int x, y;
        scanf("%*s");
        scanf("%d", &x);
        int m1 = 0, m2 = 0;
        for (int i = 1; i <= x; i++)
        {
            scanf("%d", &y);
            if (v[y] == 1)
                m1++;
            if (y == 0)
                m2++;
        }
        int rikt = m2, hain1 = m - m1, hain2 = n - m - x + m2 + m1;
        min1[k] = max(0, rikt - hain2);
        max1[k] = min(rikt, hain1);
        min1[k] += m1;
        max1[k] += m1;
        // cout<<min1[k]<<" "<<max1[k]<<"\n";
    }
    int lb = 0, ub = 0;
    for (int i = 1; i <= T; i++)
    {
        lb = max(lb, min1[i]);
        ub = max(ub, max1[i]);
    }
    int pref[200], suff[200], i;
    pref[1] = max1[1];
    for (i = 2; i <= T; i++)
    {
        pref[i] = max(pref[i - 1], max1[i]);
    }
    suff[T] = max1[T];
    for (i = T - 1; i >= 1; i--)
    {
        suff[i] = max(suff[i + 1], max1[i]);
    }

    for (int i = 1; i <= T; i++)
    {
        ub = 0;
        if (i == 1 && T > 1)
            ub = suff[2];
        else if (i == T && T > 1)
            ub = pref[T - 1];
        else if (T > 1)
            ub = max(pref[i - 1], suff[i + 1]);
        if (max1[i] < lb)
            cout << "1\n";
        else if (min1[i] >= ub)
            cout << "0\n";
        else
            cout << "2\n";
    }
}
