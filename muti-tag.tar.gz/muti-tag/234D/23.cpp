﻿// Got the soln but copied the code just for records
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define F first
#define S second
#define trace(x) cerr << #x << ": " << x << " " << endl;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    ll m, k;
    cin >> m >> k;
    ll i, j;
    ll a[k];
    map<int, int> fav;
    for (i = 0; i < k; i++)
    {
        cin >> a[i];
        fav[a[i]]++;
    }
    ll n;
    cin >> n;
    ll mini[n];
    ll maxi[n];
    ll ans[n];
    for (i = 0; i < n; i++)
    {
        string s;
        cin >> s;
        ll p;
        cin >> p;
        ll b[p];
        ll x = 0; // pakka
        ll y = 0; // variable
        ll t = 0;
        for (j = 0; j < p; j++)
        {
            cin >> b[j];
            if (b[j] == 0)
                y++;
            else if (fav[b[j]])
                x++;
            else
                t++;
        }

        mini[i] = x + max(0LL, y - (m - k - t));

        maxi[i] = min(x + y, k);
    }
    for (i = 0; i < n; i++)
    {
        bool die = false;
        bool must = true;
        for (j = 0; j < n; j++)
        {
            if (i == j)
                continue;
            if (maxi[i] < mini[j])
                die = true;
            if (mini[i] < maxi[j])
                must = false;
        }


        if (die)
            printf("1\n");
        else if (must)
            printf("0\n");
        else
            printf("2\n");
    }

    return 0;
}
