﻿#include <bits/stdc++.h>
using namespace std;
const int N = 100 + 5;

bool suki[N];
struct Film
{
    int like, hate, wow;
} f[N];

int main()
{
#ifdef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int m, k;
    cin >> m >> k;
    for (int i = 0; i < k; ++i)
    {
        int x;
        cin >> x;
        suki[x] = true;
    }
    int n;
    cin >> n;
    for (int i = 0; i < n; ++i)
    {
        string s;
        cin >> s;
        int d;
        cin >> d;
        while (d--)
        {
            int x;
            cin >> x;
            if (not x)
                f[i].wow++;
            else if (suki[x])
                f[i].like++;
            else
                f[i].hate++;
        }
    }
    for (int i = 0; i < n; ++i)
    {
        int mi_i = f[i].like + max(0, f[i].hate + f[i].wow - (m - k));
        int mx_i = min(k, f[i].like + f[i].wow);
        bool greatest = true, smallest = false;
        for (int j = 0; j < n; ++j)
        {
            if (i == j)
                continue;
            int mi_j = f[j].like + max(0, f[j].hate + f[j].wow - (m - k));
            int mx_j = min(k, f[j].like + f[j].wow);
            greatest &= mi_i >= mx_j;
            smallest |= mx_i < mi_j;
        }
        if (greatest)
        {
            cout << 0 << '\n';
        }
        else if (smallest)
        {
            cout << 1 << '\n';
        }
        else
        {
            cout << 2 << '\n';
        }
    }
    return 0;
}