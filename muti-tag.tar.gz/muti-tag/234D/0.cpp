﻿#include <bits/stdc++.h>
#define ll long long
#define ld long double
#define inf 1000000000000000000
#define maxn 1010
#define MOD 1000000007
#define pb push_back
#define pll pair<ll, ll>
#define vi vector<ll>
#define vvi vector<vector<ll> >
#define vii vector<pll>
#define vvpll vector<vector<pll> >
#define vpll vector<pll>
#define all(v) (v).begin(), (v).end()

using namespace std;

int main()
{
    // ios_base::sync_with_stdio(false);
    // cin.tie(NULL);
    // cout.tie(NULL);
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    ll m, k;
    cin >> m >> k;
    map<ll, ll> mark;
    ll a[k];
    for (int i = 0; i < k; i++)
    {
        cin >> a[i];
        mark[a[i]] = 1;
    }
    ll n;
    cin >> n;
    string name[n];
    ll fav[n] = { 0 }, num, id, zero[n] = { 0 }, bad[n] = { 0 };
    for (int i = 0; i < n; i++)
    {
        cin >> name[i];
        cin >> num;
        for (int j = 0; j < num; j++)
        {
            cin >> id;
            if (id == 0)
            {
                zero[i]++;
                continue;
            }
            if (mark[id])
            {
                fav[i]++;
            }
            else
            {
                bad[i]++;
            }
        }
    }
    vpll bound(n);
    for (int i = 0; i < n; i++)
    {
        ll rem = zero[i];
        ll remgood = k - fav[i];
        ll rembad = m - k - bad[i];
        ll mn = rem - min(rembad, rem) + fav[i]; // least number of favs in the movie.
        ll mx = min(remgood, rem) + fav[i]; // maxi favs.
        bound[i] = { mn, mx };
    }
    ll ans[n];
    for (int i = 0; i < n; i++)
    {
        bool mx = 1;
        for (int j = 0; j < n; j++)
        {
            if (i == j)
                continue;
            if (bound[j].second > bound[i].first)
            {
                mx = 0;
            }
        }
        if (mx)
        {
            ans[i] = 0;
        }
        else
        {
            bool mn = 0;
            for (int j = 0; j < n; j++)
            {
                if (i == j)
                    continue;
                if (bound[i].second < bound[j].first)
                {
                    mn = 1;
                    break;
                }
            }
            if (mn)
            {
                ans[i] = 1;
            }
            else
            {
                ans[i] = 2;
            }
        }
    }
    for (int i = 0; i < n; i++)
    {
        cout << ans[i] << '\n';
    }
}