﻿#pragma GCC optimize("O3")
#include <bits/stdc++.h>
#define case (t) fout << "Case #" << (t) << ": "
#define pii pair<int, int>
#define vii vector<pii>
#define vi vector<int>
#define pb push_back
#define mp make_pair
#define f first
#define s second
typedef long long ll;
const double pi = acos(-1);
const int MOD = 1e9 + 7;
const int INF = 1e9 + 7;
const int MAXN = 1e2 + 5;
const double eps = 1e-9;
using namespace std;
int a[MAXN], vis[MAXN], b[MAXN][MAXN], cnt[MAXN], mx[MAXN], mi[MAXN];
string tmp;

int main()
{
    ifstream fin("input.txt");
    ofstream fout("output.txt");
    int m, k;
    fin >> m >> k;
    for (int i = 0; i < k; i++)
    {
        fin >> a[i];
        vis[a[i]] = 1;
    }
    int n;
    fin >> n;
    for (int i = 0; i < n; i++)
    {
        int d, c = 0;
        fin >> tmp >> d;
        b[i][0] = d;
        for (int j = 1; j <= d; j++)
        {
            fin >> b[i][j];
            if (vis[b[i][j]])
                cnt[i]++;
            if (b[i][j] == 0)
                c++;
        }
        mx[i] = min(k, cnt[i] + c);
        mi[i] = max(c - (m - k - (d - cnt[i] - c)), 0) + cnt[i];
    }
    for (int i = 0; i < n; i++)
    {
        int c = 0, d = 0;
        for (int j = 0; j < n; j++)
            if (i != j)
                c = max(c, mx[j]), d = max(d, mi[j]);
        if (mi[i] >= c)
            fout << 0 << "\n";
        else if (mx[i] < d)
            fout << 1 << "\n";
        else
            fout << 2 << "\n";
    }
    return 0;
}