﻿#include <stdlib.h>
#include <time.h>
#include <vector>
#include <math.h>
#include <algorithm>
#include <sstream>
#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <map>
#include <stack>
#include <queue>
#include <utility>
#include <set>

using namespace std;

typedef long long int ll;

const int M = 100 + 10;


set<int> f;

struct NODE
{
    string name;
    int d;
    int a[M];
    int minf;
    int maxf;
} node[M];

int main()
{

    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    int m, k;
    cin >> m >> k;

    for (int i = 1; i <= k; i++)
    {
        int x;
        cin >> x;
        f.insert(x);
    }

    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cin >> node[i].name;
        cin >> node[i].d;
        int num0 = 0;
        set<int> ff;
        for (int j = 1; j <= node[i].d; j++)
        {
            cin >> node[i].a[j];
            if (node[i].a[j] == 0)
            {
                num0++;
            }
            else
            {
                if (f.find(node[i].a[j]) != f.end())
                {
                    ff.insert(node[i].a[j]);
                }
            }
        }

        int delta = f.size() - ff.size();
        int maxf = min(delta, num0) + ff.size();
        node[i].maxf = maxf;

        int num1 = node[i].d - num0 - ff.size();
        int total = m - k;
        delta = total - num1;
        delta = min(num0, delta);
        node[i].minf = node[i].d - num1 - delta;
    }

    for (int i = 1; i <= n; i++)
    {
        // 0, if the i-th movie will surely be the favourite;
        // 1, if the i-th movie won't surely be the favourite;
        // 2, if the i-th movie can either be favourite, or not favourite.
        // cout<<node[i].minf<<" "<<node[i].maxf<<endl;

        int num0 = 0;
        int num1 = 0;
        for (int j = 1; j <= n; j++)
        {
            if (j != i)
            {
                if (node[j].maxf <= node[i].minf)
                {
                    num0++;
                }
                if (node[j].minf > node[i].maxf)
                {
                    num1++;
                }
            }
        }

        if (num0 == n - 1)
        {
            cout << 0 << endl;
        }
        else
        {
            if (num1 > 0)
            {
                cout << 1 << endl;
            }
            else
            {
                cout << 2 << endl;
            }
        }
    }


    return 0;
}
