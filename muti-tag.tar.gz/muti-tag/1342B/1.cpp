﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string str;
        cin >> str;
        int has[2] = { 0 };
        for (int i = 0; i < str.size(); i++)
        {
            if (str[i] == '1')
                has[1]++;
            else
                has[0]++;
        }
        if (has[0] && has[1])
        {
            if (str[0] == '0')
            {
                for (int i = 0; i < 2 * str.size(); i++)
                {
                    if (i % 2 == 0)
                        cout << 0;
                    else
                        cout << 1;
                }
            }
            else
            {
                for (int i = 0; i < 2 * str.size(); i++)
                {
                    if (i % 2 == 1)
                        cout << 0;
                    else
                        cout << 1;
                }
            }
        }
        else
        {
            for (int i = 0; i < str.size(); i++)
                cout << str[i];
        }
        cout << "\n";
    }
    return 0;
}
