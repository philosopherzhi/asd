﻿#include <bits/stdc++.h>
using namespace std;
#define mp make_pair
#define pb push_back
#define ppb pop_back
#define all(x) (x).begin(), (x).end()
#define int long long
#define double long double

void solve()
{

    string s;
    cin >> s;

    int l = s.length();

    bool flag = false;

    for (int i = 1; i < l; i++)
    {
        if (s[i] != s[i - 1])
        {
            flag = !flag;
            break;
        }
    }

    if (!flag)
    {
        cout << s << "\n";
        return;
    }

    else
    {
        for (int i = 0; i < l; i++)
        {
            cout << "10";
        }
        cout << "\n";
    }
}

signed main()
{

    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
#ifndef ONLINE_JUDGE
    // for getting input from input.txt
    freopen("input.txt", "r", stdin);
    // for writing output to output.txt
    freopen("output.txt", "w", stdout);
#endif

    int t = 1;
    cin >> t;

    for (int i = 1; i <= t; i++)
    {

        solve();
    }

    return 0;
}
