﻿

#include <bits/stdc++.h>
#define ll long long
#define pb push_back
#define fr(a, b) for (int i = a; i < b; i++)
#define rep(i, a, b) for (int i = a; i < b; i++)
#define mod 1000000007
#define inf (1LL << 60)
#define all(x) (x).begin(), (x).end()
#define prDouble(x) cout << fixed << setprecision(10) << x
#define triplet pair<ll, pair<ll, ll> >
using namespace std;


int main()
{
    ll t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        ll cnt = 0;
        for (ll i = 0; i < s.length() - 1; i++)
        {
            if (s[i] == s[i + 1])
                cnt++;
        }
        if (cnt == s.length() - 1)
            cout << s << endl;
        else
        {
            string k;
            for (ll i = 0; i < 2 * s.length(); i++)
            {
                if (i % 2)
                    k += "1";
                else
                    k += "0";
            }
            cout << k << endl;
        }
    }


    return 0;
}
