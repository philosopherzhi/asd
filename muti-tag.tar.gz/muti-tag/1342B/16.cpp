﻿#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define mp make_pair
#define lli long long int
void solve()
{
    string s;
    cin >> s;
    int f = 0;
    for (int i = 1; i < s.length(); i++)
    {
        if (s[0] != s[i])
        {
            f = 1;
            break;
        }
    }
    if (f == 0)
    {
        cout << s << endl;
    }
    else
    {
        string a = "";
        if (s[0] == '1')
        {
            while (a.length() < 2 * s.length() - 1)
            {
                a += "10";
            }
        }
        else
        {
            while (a.length() < 2 * s.length() - 1)
            {
                a += "01";
            }
        }
        cout << a << endl;
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin >> t;
    cin.ignore();
    while (t)
    {
        solve();
        t--;
    }
    return 0;
}
