﻿#include <bits/stdc++.h>
#define ll long long int
#define vi vector<ll>
#define pb push_back
#define mod 1000000007
using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    ll t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        if (count(s.begin(), s.end(), '1') == s.size()
            || count(s.begin(), s.end(), '0') == s.size())
            cout << s << "\n";
        else
        {
            cout << s[0];
            if (s[0] == '1')
            {
                for (ll i = 2; i <= 2 * s.size(); i++)
                {
                    if (i % 2 == 0)
                        cout << "0";
                    else
                        cout << "1";
                }
                cout << "\n";
            }
            else
            {
                for (ll i = 2; i <= 2 * s.size(); i++)
                {
                    if (i % 2 == 1)
                        cout << "0";
                    else
                        cout << "1";
                }
                cout << "\n";
            }
        }
    }
}
