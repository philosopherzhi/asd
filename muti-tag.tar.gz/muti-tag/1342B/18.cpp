﻿#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define int long long
//#define fi first
//#define se second
typedef long long ll;
const ll INF = 1e18 * 9;
const int N = 1e6 + 23;
const int M = 1003;
const int mod1 = 1e9 + 7;
const int mod = 1e9 + 7;
const int base = 131;
int n, m, k, ans, cnt, x, y, mid, sx = -1, sy = -1, mx, mi = INF, aa;
int a[N], in[N];
// int dp[M][M];
// stack<int>st;
// pair<int,int>P[N];
// int c[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
// int c1[]={0,31,29,31,30,31,30,31,31,30,31,30,31};
bool vis[N];
vector<char> ve, ve1;
// string s[N],ss;
string s, ss;
// char b[M][M];
// bool ok(int sx){return ((sx%4==0 && sx%100) || (sx%400==0));}
// bool cmp(int a,int b){return a>b; }
/*inline int read()
{
        int x=0,f=1;char ch=getchar();
        while (!isdigit(ch)){if (ch=='-') f=-1;ch=getchar();}
        while (isdigit(ch)){x=x*10+ch-48;ch=getchar();}
        return x*f;
}*/
void solve()
{
    int pos = 0, s1 = 0, s2 = 0, z, f = 0;
    mx = 0;
    ans = 0;
    cin >> s;
    ve.clear();
    for (auto i : s)
        s1 += (i == '1');
    if (s1 == 0 || s1 == s.size() || s.size() == 2)
    {
        cout << s << endl;
        return;
    }
    while (ve.size() < s.size() * 2)
    {
        ve.push_back('0');
        ve.push_back('1');
    }
    for (auto i : ve)
        cout << i;
    cout << endl;
}
/*
5
1 2 1 2 13513
*/
signed main()
{

    // cout<<"\"<<endl;
    // cout<<(!1)<<endl;
    // cout<<ok(12345678)<<endl
    // cout<<(0%3)<<endl;
    // cout<<pow(12,2)<<endl;
    /*cout<<fun(10000 , 10000)<<endl;
    cout<<fun(9999 , 9999)<<endl;*/
    ios::sync_with_stdio(0);
    cin.tie(nullptr);
    cout.tie(nullptr);
    // cin.tie(nullptr);
    // int T;for(T=read();T--;)
    int T;
    for (cin >> T; T--;)
        // while(cin>>n>>m)
        solve();
}
