﻿#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int c = 0;
        string s;
        cin >> s;
        for (int i = 1; i < s.size(); i++)
            if (s[i] != s[i - 1])
                c = 1;
        if (c == 1)
        {
            for (int i = 0; i < s.size(); i++)
                cout << "01";
            cout << endl;
        }
        else
            cout << s << endl;
    }
}