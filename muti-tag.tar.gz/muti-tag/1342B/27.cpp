﻿#include <iostream>
using namespace std;
void afisare(int n, int k, int c)
{
    k += 1;
    if (k == 1)
        for (int i = 1; i <= n; i++)
            cout << c;
    else
        for (int i = 1; i <= n; i++)
            if (i % k == 0)
            {
                if (c == 1)
                    cout << 0;
                else
                    cout << 1;
            }
            else
                cout << c;
    cout << endl;
}
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int c1 = 0, c0 = 0;
        char s[105];
        cin >> s;
        for (int i = 0; s[i]; i++)
            if (s[i] == '0')
                c0++;
            else
                c1++;

        if (c1 == 0)
            afisare(c0, 0, 0);
        else if (c0 == 0)
            afisare(c1, 0, 1);
        else if (c1 > c0)
            afisare((c1 + c0) * 2, 1, 0);
        else
            afisare((c1 + c0) * 2, 1, 0);
    }
}
