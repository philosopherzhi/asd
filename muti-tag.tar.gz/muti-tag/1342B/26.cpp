﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define fast()                                                                                     \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(NULL);                                                                                 \
    cout.tie(NULL);
#define ld long double
#define pb push_back
#define ff first
#define ss second
#define FOR(i, n) for (ll i = 0; i < n; i++)
#define FORr(i, n) for (ll i = n - 1; i >= 0; i--)
#define MAX 1e18
// vector<vector<int>>a(n,vector<int>(m,0));
// vector<pair<ll,pair<ll,ll>>>a;
/*
bool sortbysec(const pair<int,int> &a, const pair<int,int> &b){
    return (a.second < b.second);
}
*/
int main()
{
    fast();
    int t;
    cin >> t;
    while (t--)
    {
        string t;
        cin >> t;
        int n = t.size();
        set<char> s;
        FOR(i, n)
        {
            s.insert(t[i]);
        }
        if (s.size() == 1)
        {
            cout << t << "\n";
        }
        else
        {
            string ans;
            ans += t[0];
            FOR(i, 2 * (n - 1))
            {
                if (ans.back() == '0')
                {
                    ans += '1';
                }
                else
                {
                    ans += '0';
                }
            }
            cout << ans << "\n";
        }
    }
    return 0;
}