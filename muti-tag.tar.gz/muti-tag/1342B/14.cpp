﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin >> n;
    getchar();
    while (n--)
    {
        string s;
        getline(cin, s);
        int sum3 = 0, sum2 = 0;
        for (int i = 0; i < s.size(); i++)
        {
            if (s[i] == '0')
                sum3++;
            else if (s[i] == '1')
                sum2++;
        }
        if (sum3 == 0 || sum2 == 0)
            cout << s;
        else
        {
            for (int j = 0; j < s.size(); j++)
            {
                if (s[j] == '0')
                {
                    cout << '1' << s[j];
                }
                if (s[j] == '1')
                {
                    cout << s[j] << '0';
                }
            }
        }
        cout << endl;
    }
    return 0;
}
