﻿#include <bits/stdc++.h>
using namespace std;

int main()
{
    int T;
    cin >> T;
    while (T--)
    {
        string t;
        cin >> t;
        int n = t.length();
        int c0 = 0, c1 = 0;
        for (int i = 0; i < n; i++)
        {
            if (t[i] == '0')
                c0++;
            else
                c1++;
        }
        if (c0 == 0 || c1 == 0)
        {
            cout << t << "\n";
        }
        else
        {
            for (int i = 0; i < n; i++)
            {
                cout << "10"
                     << "";
            }
            cout << "\n";
        }
    }
}