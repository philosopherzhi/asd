﻿#include <iostream>
using namespace std;

int main()
{
    // your code goes here

    int t;
    cin >> t;

    while (t--)
    {

        string s;
        cin >> s;

        bool allSame = true;
        for (int i = 1; i < s.length(); i++)
        {

            if (s[i] != s[i - 1])
            {

                allSame = false;
                break;
            }
        }

        if (allSame)
        {
            cout << s << endl;
            continue;
        }

        for (int i = 0; i < s.length(); i++)
        {

            cout << "01";
        }
        cout << endl;
    }
    return 0;
}
