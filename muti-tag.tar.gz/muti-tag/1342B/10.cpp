﻿#include <bits/stdc++.h>
#define endl "\n"
#define PI acos(-1)
#define BMW_GTR ios_base::sync_with_stdio(false), cin.tie(0), cout.tie(0)
#define pb push_back

typedef long long ll;
typedef unsigned long long ull;

using namespace std;

int main()
{
    BMW_GTR;

    int t;
    cin >> t;

    for (int tc = 1; tc <= t; tc++)
    {
        string T;
        cin >> T;

        int zeros = 0, ones = 0;

        for (int i = 0; i < T.size(); i++)
            T[i] == '0' ? zeros++ : ones++;

        if (zeros == 0 || ones == 0)
            cout << T << endl;

        else
        {
            for (int i = 0; i < 2 * T.size(); i++)
            {
                i % 2 == 0 ? cout << 0 : cout << 1;
            }

            cout << endl;
        }
    }

    return 0;
}
