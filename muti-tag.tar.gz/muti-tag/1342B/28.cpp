﻿#include <iostream>
#include <string>
using namespace std;
int main()
{
    int n;
    cin >> n;
    while (n--)
    {
        string ss;
        cin >> ss;
        if (ss.find("0") == -1 || ss.find("1") == -1)
            cout << ss << endl;
        else
        {
            for (int i = 1; i <= ss.length(); i++)
                cout << "01";
            cout << endl;
        }
    }
}
