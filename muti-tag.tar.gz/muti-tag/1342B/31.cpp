﻿#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define mp make_pair
typedef long long ll;
typedef long double ld;
typedef pair<ll, ll> pii;
typedef pair<ll, ll> pll;


const ll N = 1e5;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        bool p2 = false;
        for (int i = 1; i < s.size(); i++)
        {
            if (s[i] != s[i - 1])
            {
                p2 = true;
            }
        }
        if (!p2)
        {
            cout << s << endl;
            continue;
        }
        string ans = "";
        ans += s[0];
        char ch = (s[0] == '1') ? '0' : '1';
        for (int i = 1; i < s.size(); i++)
        {
            if (s[i] == ch)
            {
                ans += ch;
                ch = (s[i] == '1') ? '0' : '1';
            }
            else
            {
                ans += ch;
                ch = s[i];
                i--;
            }
        }
        cout << ans << endl;
    }
    return 0;
}
