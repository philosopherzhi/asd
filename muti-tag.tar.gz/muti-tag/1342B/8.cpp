﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long int
#define lld double
#define rep(i, a, b) for (ll i = a; i <= b; i++)
#define all(v) v.begin(), v.end()
#define vc vector
#define rep1(it, v) for (it = v.begin(); it != v.end(); it++)
#define ayush                                                                                      \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(0);                                                                                    \
    cout.tie(0)
#define input(v)                                                                                   \
    for (auto& it : v)                                                                             \
    cin >> it
#define inf 1000000007
#define pb push_back
#define write(v)                                                                                   \
    {                                                                                              \
        for (auto& it : v)                                                                         \
            cout << it << " ";                                                                     \
        cout << endl;                                                                              \
    }

ll power(ll x, ll n, ll p)
{
    ll result = 1;
    while (n > 0)
    {
        if (n % 2 == 1)
            result = (result % p * x % p) % p;
        x = (x % p * x % p) % p;
        n = n / 2;
    }
    return result % p;
}


void solve()
{
    string s;
    cin >> s;
    ll one = 0;
    ll n = s.length();
    rep(i, 0, n - 1) if (s[i] == '1') one++;
    if (one == n || one == 0)
    {
        cout << s << endl;
        return;
    }

    string ans(2 * n, '0');
    for (ll i = 0; i < 2 * n; i += 2)
        ans[i] = '1';

    cout << ans << endl;
}


int main()
{
    ayush;
    // cout<<setprecision(12);
    ll t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}