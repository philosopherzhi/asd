﻿#include <bits/stdc++.h>
using namespace std;
void solve()
{
    string s;
    cin >> s;
    long long n = s.size(), sum = 0;
    for (int i = 0; i < n; i++)
    {
        if (s[i] == '1')
            sum++;
    }
    if (sum == 0 || sum == n)
    {
        cout << s << endl;
        return;
    }
    for (int i = 0; i < 2 * n; i++)
    {
        if (i % 2 == 0)
            cout << "1";
        else
            cout << "0";
    }
    cout << endl;
}
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        solve();
    }
}