﻿#include <iostream>
#include <string>


int main()
{
    int T;
    std::cin >> T;
    do
    {
        std::string s, t;
        std::cin >> t;
        bool same{ true };
        int a = t[0];
        for (int i = 0; i < t.size(); ++i)
        {
            if (t[i] != a)
            {
                same = false;
                break;
            }
        }
        for (int i = 0; i < t.size(); ++i)
        {
            s.push_back('1');
            s.push_back('0');
        }
        if (same)
            std::cout << t << std::endl;
        else
            std::cout << s << std::endl;
    } while (--T);
    return 0;
}
