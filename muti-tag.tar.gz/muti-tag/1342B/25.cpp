﻿#include <bits/stdc++.h>
using namespace std;
int a[7];
int main()
{
    int t;
    scanf("%d", &t);
    while (t--)
    {
        string s;
        cin >> s;
        int len = s.size();
        int a = 0;
        for (int i = 0; i < len; i++)
        {
            if (s[i] == '0')
            {
                a++;
            }
        }
        if (a == 0 || a == len)
        {
            cout << s;
        }
        else
        {
            for (int i = 1; i <= len; i++)
            {
                printf("01");
            }
        }
        printf("\n");
    }
    return 0;
}
