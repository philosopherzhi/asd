﻿#include <bits/stdc++.h>
using namespace std;

int main()
{
    // your code goes here
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        int p = 0, z = 0;
        ;
        map<char, int> mp;
        for (int i = 0; i < s.size(); i++)
        {
            mp[s[i]]++;
        }
        for (auto x : mp)
        {
            if (x.second == s.size())
            {
                cout << s << endl;
                z = 1;
                break;
            }
        }
        if (z == 0)
        {
            for (int i = 0; i < 2 * s.size(); i++)
            {

                if (p == 0)
                {
                    cout << "1";
                    p = 1;
                }
                else if (p == 1)
                {
                    cout << "0";
                    p = 0;
                }
            }
            cout << endl;
        }
    }
    return 0;
}