﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int z = 0, o = 0, alt = 0;
        string s;
        cin >> s;
        // either all numbers are same => k = 1
        // add alternate zeroes or ones to make k = 2 0101
        for (int i = 0; i < s.size(); i++)
        {
            if (s[i] == '0')
                z++;
            if (s[i] == '1')
                o++;
            if (z == o + 1 || z == o - 1)
                alt++;
        }
        // cout<<alt<<" "<<z<<" "<<o<<" "<<s.size()<<endl;
        if (alt == s.size() || z == s.size() || o == s.size())
            cout << s << endl;
        else
        {
            for (int i = 0; i < s.size(); i++)
            {
                cout << s[i];
                if (s[i + 1] == s[i])
                    cout << !(s[i] & 1);
            }
            cout << endl;
        }
    }
}
