﻿#include <bits/stdc++.h>
#include <string>
#define int long long
#define FOR(i, n) for (long long i = 0; i < n; i++)
using namespace std;
void check()
{
    string t;
    cin >> t;
    int x = 0, y = 0;
    FOR(i, t.size())
    if (t[i] == '0')
        x++;
    else
        y++;
    if (x == t.size() || y == t.size())
    {
        cout << t << "\n";
        return;
    }
    string s;
    s.push_back(t[0]);
    for (int i = 1; i < t.size();)
    {

        if (s[s.size() - 1] == t[i])
            if (t[i] == '0')
                s.push_back('1');
            else
                s.push_back('0');
        else
        {
            s.push_back(t[i]);
            i++;
        }
    }
    cout << s << "\n";
}
signed main()
{
    long long t;
    cin >> t;
    while (t--)
        check();
    return 0;
}
