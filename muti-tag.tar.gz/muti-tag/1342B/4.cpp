﻿#include <bits/stdc++.h>
#define ll long long
using namespace std;


int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        char a[101];
        cin >> a;
        if (strchr(a, '1') == 0)
        {
            cout << a << "\n";
            continue;
        }
        if (strchr(a, '0') == 0)
        {
            cout << a << "\n";
            continue;
        }
        for (int i = 0; a[i]; ++i)
        {
            cout << a[i];
            if (a[i] == '1' && a[i + 1] == '1')
                cout << '0';
            if (a[i] == '0' && a[i + 1] == '0')
                cout << '1';
        }
        cout << "\n";
    }
    return 0;
}
