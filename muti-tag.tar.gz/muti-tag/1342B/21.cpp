﻿#include <bits/stdc++.h>
#define FAST                                                                                       \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(NULL);
#define cerr                                                                                       \
    if (1)                                                                                         \
    cerr
#define ll long long
#define fp cout << fixed << setprecision(9);
#define loop(var, s, n) for (ll var = s; var < n; var++)
#define rloop(var, s, n) for (ll var = s; var >= n; var--)
#define pb push_back
#define mk make_pair
#define all(x) x.begin(), x.end()
#define mod 1000000007
#define ipair pair<ll, pair<ll, ll> >
using namespace std;
bool comp(pair<pair<ll, ll>, ll> p1, pair<pair<ll, ll>, ll> p2)
{
    return p1.first.first < p2.first.first;
}
int main()
{
#ifdef KEVIN
    freopen("ingoing3.txt", "r", stdin);
    freopen("outgoing3.txt", "w", stdout);
    freopen("err3.txt", "w", stderr);
#endif
    FAST int t = 1;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        if (s.size() <= 2)
        {
            cout << s << endl;
            continue;
        }
        if (count(all(s), '0') == s.size() || count(all(s), '1') == s.size())
        {
            cout << s << endl;
            continue;
        }

        loop(i, 0, s.size())
        {
            cout << "10";
        }

        cout << endl;
    }
}