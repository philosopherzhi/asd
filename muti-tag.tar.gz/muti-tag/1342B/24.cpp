﻿#include <iostream>
#include <string.h>
#include <algorithm>
using namespace std;
int main()
{
    int n;
    cin >> n;
    getchar();
    while (n--)
    {
        char s[101];
        int i;
        cin >> s;
        int sim = 0;
        for (i = 0; i < strlen(s) - 1; i++)
        {
            if (s[i] != s[i + 1])
            {
                sim = 1;
                break;
            }
        }
        if (sim == 0)
        {
            cout << s << endl;
        }
        else
        {
            for (i = 0; i < strlen(s); i++)
            {
                cout << "10";
            }
            cout << endl;
        }
    }
    return 0;
}
