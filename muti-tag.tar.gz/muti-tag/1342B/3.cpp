﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        int n = s.length();
        if (count(s.begin(), s.end(), '0') == n || count(s.begin(), s.end(), '1') == n)
        {
            cout << s << endl;
            continue;
        }
        else
        {
            for (int i = 0; i < n; i++)
            {
                if (i == 0)
                {
                    cout << s[i];
                }
                else
                {
                    if (s[i] != s[i - 1])
                    {
                        cout << s[i];
                    }
                    else
                    {
                        if (s[i] == '1')
                        {
                            cout << "0" << s[i];
                        }
                        else
                        {
                            cout << "1" << s[i];
                        }
                    }
                }
            }
        }
        cout << endl;
    }
}
