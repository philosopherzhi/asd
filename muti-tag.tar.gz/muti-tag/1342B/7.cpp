﻿#include <iostream>
#include <algorithm>
#include <string>
#include <map>

using namespace std;

int main()
{
    int t;
    cin >> t;
    string s;
    while (t--)
    {
        map<char, int> mp;
        mp['1'] = 0;
        mp['0'] = 0;
        cin >> s;
        for (auto& i : s)
            mp[i]++;
        if (mp['1'] == 0 || mp['0'] == 0)
            cout << s << endl;
        else
            for (int i = 0; i < s.length(); i++)
                cout << "01";
        cout << endl;
    }
    return 0;
}
