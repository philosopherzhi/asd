﻿#include <bits/stdc++.h>
using namespace std;
#define LL long long
#define pa pair<int, int>
const int Maxn = 510;
const int inf = 2147483647;
const double pi = acos(-1.0);
int read()
{
    int x = 0, f = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9')
    {
        if (ch == '-')
            f = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9')
        x = x * 10 + ch - '0', ch = getchar();
    return x * f;
}
int n, m, ans[Maxn * Maxn], a[Maxn], b[Maxn];
struct P
{
    int x, id;
} p[Maxn];
bool cmp(P a, P b)
{
    return a.x < b.x;
}
void w(int x)
{
    ans[++m] = x;
    swap(a[x + 1], a[x + 2]);
    swap(a[x], a[x + 1]);
    swap(b[x + 1], b[x + 2]);
    swap(b[x], b[x + 1]);
}
int main()
{
    int T = read();
    while (T--)
    {
        n = read();
        for (int i = 1; i <= n; i++)
            p[i].x = read(), p[i].id = i, a[i] = p[i].x;
        sort(p + 1, p + 1 + n, cmp);
        m = 0;
        for (int i = 1; i <= n; i++)
            b[p[i].id] = i;
        for (int i = 1; i <= n - 3; i++)
        {
            if (b[i] == i)
                continue;
            for (int j = i + 1; j <= n; j++)
                if (b[j] == i)
                {
                    int t = j;
                    if ((j - i) & 1)
                    {
                        if (j == n)
                        {
                            w(n - 2);
                            w(n - 3);
                            t = n - 1;
                        }
                        else
                            w(j - 1), t++;
                    }
                    for (int k = t; k > i; k -= 2)
                        w(k - 2);
                    break;
                }
            //			printf("i=%d\n",i);
            //			for(int j=1;j<=n;j++)printf("%d ",a[j]);puts("");
        }
        //		printf("%d\n",m);
        //		return 0;
        //		for(int i=1;i<=n;i++)printf("%d ",a[i]);puts("");
        //		for(int i=1;i<=n;i++)printf("%d ",b[i]);puts("");
        //		while(b[n-2]!=n-2)w(n-2);
        if (a[n] <= a[n - 2] && a[n - 2] <= a[n - 1])
            w(n - 2);
        else if (a[n - 1] <= a[n] && a[n] <= a[n - 2])
            w(n - 2), w(n - 2);
        else if (!(a[n - 2] <= a[n - 1] && a[n - 1] <= a[n]))
        {
            while (a[n - 2] > a[n - 1] || a[n - 2] > a[n])
                w(n - 2);
        }
        if (a[n - 1] > a[n])
        {
            int p = -1;
            for (int i = n - 2; i > 1; i--)
                if (a[i] == a[i - 1])
                {
                    p = i;
                    break;
                }
            if (p == -1)
                m = -1;
            else
            {
                for (int i = n - 2; i > p; i--)
                    w(i), w(i);
                w(p), w(p - 1);
                for (int i = p + 1; i < n - 1; i++)
                    w(i);
            }
        }
        if (m == -1)
        {
            puts("-1");
            continue;
        }
        //		for(int i=1;i<=n;i++)printf("%d ",a[i]);puts("");
        printf("%d\n", m);
        for (int i = 1; i <= m; i++)
            printf("%d ", ans[i]);
        puts("");
    }
}
