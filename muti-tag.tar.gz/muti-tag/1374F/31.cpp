﻿#define _CRT_SECURE_NO_WARNINGS
#include <bits/stdc++.h>

int find_min(std::vector<std::pair<int, int>>& v, int pos_i)
{
    int n = v.size();
    std::pair<int, int> min_p = { INT_MAX, INT_MAX };
    int i_p = -1;
    for (int i = pos_i; i < n; i++)
    {
        if (min_p > v[i])
        {
            min_p = v[i];
            i_p = i;
        }
    }
    return i_p;
}

int num_inv(std::vector<std::pair<int, int>>& v)
{
    int n = v.size();
    int count = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            count += v[i] > v[j];
        }
    }
    return count;
}

int main()
{
#ifdef _DEBUG
    freopen("in.txt", "r", stdin);
//	freopen("output.txt", "w", stdout);
#endif

    auto shift_segment = [](std::vector<std::pair<int, int>>& v, int p)
    {
        std::swap(v[p], v[p + 2]);
        std::swap(v[p + 1], v[p + 2]);
    };

    int t;
    std::cin >> t;
    while (t--)
    {
        int n;
        std::cin >> n;
        std::vector<int> a(n);
        std::vector<std::pair<int, int>> p(n);
        for (int i = 0; i < n; i++)
        {
            std::cin >> a[i];
            p[i] = { a[i], i };
        }


        int n_inv = num_inv(p);

        if (n_inv % 2)
        {
            for (int i = 0; i < n; i++)
                for (int j = i + 1; j < n; j++)
                    if (p[i].first == p[j].first)
                    {
                        std::swap(p[i].second, p[j].second);
                        goto cnt;
                    }
        }

    cnt:

        std::list<int> sol;

        for (int i = 0; i < n - 2; i++)
        {
            int pos_min = find_min(p, i);
            while (i != pos_min)
            {
                int pos_mov = pos_min - 2;
                if (pos_mov < i)
                {
                    pos_mov = i;
                    pos_min += 1;
                }
                else
                {
                    pos_min -= 2;
                }
                shift_segment(p, pos_mov);
                sol.push_back(pos_mov);
            }
        }
        if (std::is_sorted(p.begin(), p.end()))
        {
            std::cout << sol.size() << '\n';
            while (!sol.empty())
            {
                std::cout << sol.front() + 1 << ' ';
                sol.pop_front();
            }
            std::cout << '\n';
        }
        else
        {
            std::cout << "-1\n";
        }
    }

    return 0;
}