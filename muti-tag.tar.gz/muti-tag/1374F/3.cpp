﻿#include <bits/stdc++.h>
#define IOS                                                                                        \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(0);                                                                                    \
    cout.tie(0);
#define pb push_back
#define int long long
#define swap(x, y) (x ^= y ^= x ^= y)

#define debug1(a) cerr << #a << " = " << (a) << "\n";
#define debug2(a, b) cerr << #a << " = " << (a) << ", " << #b << " = " << (b) << "\n";
#define debug3(a, b, c)                                                                            \
    cerr << #a << " = " << (a) << ", " << #b << " = " << (b) << ", " << #c << " = " << (c) << "\n";
#define debug4(a, b, c, d)                                                                         \
    cerr << #a << " = " << (a) << ", " << #b << " = " << (b) << ", " << #c << " = " << (c) << ", " \
         << #d << " = " << (d) << "\n";

using namespace std;

#define mod 1000000007

long long modexpo(long long x, long long p)
{
    int res = 1;
    x = x % mod;
    while (p)
    {
        if (p % 2)
            res = res * x;
        p >>= 1;
        x = x * x % mod;
        res %= mod;
    }
    return res;
}

struct compare
{
    bool operator()(const pair<int, int> a, const pair<int, int> b) const
    {
        return a.first < b.first;
    }
};

int n;
vector<int> arr;
vector<pair<int, int>> res;

void shift(int i)
{
    if ((i < n) && (i + 1 < n) && (i + 2 < n))
    {
        swap(arr[i + 2], arr[i + 1]);
        swap(arr[i + 1], arr[i]);
    }
}

void __solve__(int testCase)
{
    cin >> n;
    arr.clear();
    res.clear();
    arr.assign(n, 0);
    res.assign(n, { 0, 0 });
    vector<int> ans;
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
        res[i] = { arr[i], i };
    }

    sort(res.begin(), res.end());
    for (int i = 0; i < n; i++)
    {
        arr[res[i].second] = i;
    }
    int cnt = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (arr[j] < arr[i])
            {
                cnt++;
            }
        }
    }

    if (cnt & 1)
    {
        for (int i = 0; i < n - 1; i++)
        {
            if (res[i].first == res[i + 1].first)
            {
                swap(arr[res[i].second], arr[res[i + 1].second]);
                break;
            }
        }
    }

    for (int i = 0; i < n - 2; i++)
    {
        int pos = min_element(arr.begin() + i, arr.end()) - arr.begin();
        while (pos > i + 1)
        {
            shift(pos - 2);
            ans.pb(pos - 2);
            pos -= 2;
        }
        if (pos != i)
        {
            shift(pos - 1);
            shift(pos - 1);
            ans.pb(pos - 1);
            ans.pb(pos - 1);
            pos--;
        }
    }
    for (int i = 0; i < 3; i++)
    {
        if (is_sorted(arr.begin(), arr.end()))
        {
            break;
        }
        shift(n - 3);
        ans.pb(n - 3);
    }
    if (!is_sorted(arr.begin(), arr.end()))
    {
        cout << -1 << "\n";
    }
    else
    {
        cout << ans.size() << "\n";
        for (int i : ans)
        {
            cout << i + 1 << " ";
        }
        cout << "\n";
    }
}

int32_t main()
{

    IOS int testCase = 1;
    cin >> testCase;
    for (int tc = 1; tc <= testCase; tc++)
    {
        // cout << "Case#" << tc << ": ";
        __solve__(tc);
    }
}