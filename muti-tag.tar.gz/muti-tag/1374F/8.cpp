﻿#include <iostream>
#include <map>
#include <set>
using namespace std;
int num[505];
int ans[250005];

set<int> S;
map<int, int> M;

void mov(int i)
{
    int tmp = num[i];
    num[i] = num[i + 2], num[i + 2] = num[i + 1], num[i + 1] = tmp;
}

int main()
{
    // freopen("in.txt", "r", stdin);
    std::ios::sync_with_stdio(false);
    cin.tie(0);
    int cishu;
    cin >> cishu;
    while (cishu--)
    {

        int n;
        cin >> n;
        for (int i = 1; i <= n; i++)
        {
            cin >> num[i];
        }

        int cnt = 0;
        for (int i = 1; i <= n - 2; i++)
        {
            int min_value = 1e9, min_id = 1;
            for (int j = i; j <= n; j++)
            {
                if (num[j] < min_value)
                {
                    min_value = num[j];
                    min_id = j;
                }
            }

            while (i + 2 <= min_id)
            {
                ans[cnt++] = min_id - 2;
                mov(min_id - 2);
                min_id -= 2;
            }

            if (min_id == i + 1)
            {
                mov(min_id - 1), mov(min_id - 1);
                ans[cnt++] = min_id - 1, ans[cnt++] = min_id - 1;
            }
        }

        for (int i = n; i >= 3; i--)
        {
            int max_value = -1, max_id = 1;
            for (int j = i; j >= 1; j--)
            {
                if (num[j] > max_value)
                {
                    max_value = num[j];
                    max_id = j;
                }
            }

            while (max_id + 2 <= i)
            {
                ans[cnt++] = max_id;
                ans[cnt++] = max_id;
                mov(max_id);
                mov(max_id);
                max_id += 2;
            }

            if (max_id + 1 == i)
            {
                mov(max_id - 1);
                ans[cnt++] = max_id - 1;
            }
        }

        bool flag = 1;
        for (int i = 2; i <= n && flag; i++)
        {
            if (num[i] < num[i - 1])
                flag = 0;
        }

        if (!flag)
            cout << -1 << "\n";
        else
        {
            cout << cnt << "\n";
            for (int i = 0; i < cnt; i++)
            {
                cout << ans[i] << " ";
            }
            cout << "\n";
        }
    }
    return 0;
}