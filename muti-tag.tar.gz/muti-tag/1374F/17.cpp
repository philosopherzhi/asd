﻿#include <bits/stdc++.h>
using namespace std;
const int maxn = 505;
int a[maxn];
int t;
int n;
int tot = 0;
vector<int> ans;
void R(int u)
{
    //旋转以u为起点的三元组
    ans.push_back(u);
    tot++;
    int t1 = a[u];
    int t2 = a[u + 1];
    int t3 = a[u + 2];
    a[u] = t3;
    a[u + 1] = t1;
    a[u + 2] = t2;
}
int main()
{
    scanf("%d", &t);
    while (t--)
    {
        ans.clear();
        tot = 0;
        scanf("%d", &n);
        for (int i = 1; i <= n; i++)
            scanf("%d", &a[i]);
        for (int i = 1; i <= n - 2; i++)
        {
            int u;
            int Min = 1e9;
            for (int j = i; j <= n; j++)
            {
                if (a[j] <= Min)
                    Min = a[j], u = j;
            }
            while (u >= i + 2)
                R(u - 2), u -= 2;
            if (u == i + 1)
            {
                R(i);
                R(i);
                continue;
            }
        }
        for (int i = n; i >= 3; i--)
        {
            int u;
            int Max = -1;
            for (int j = i; j >= 1; j--)
            {
                if (a[j] > Max)
                    Max = a[j], u = j;
            }
            while (u <= i - 2)
                R(u), R(u), u += 2;
            if (u == i - 1)
            {
                R(i - 2);
                continue;
            }
        }
        for (int i = 1; i < n; i++)
            if (a[i] > a[i + 1])
                tot = -1;
        printf("%d\n", tot);
        if (tot != -1)
        {
            for (int i = 0; i < ans.size(); i++)
                printf("%d ", ans[i]);
            printf("\n");
        }
    }
}
