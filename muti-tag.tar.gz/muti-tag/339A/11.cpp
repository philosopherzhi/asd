﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    int a[101], n = 0;
    cin >> s;
    for (int i = 0; i < s.size(); i++)
    {
        if (s[i] != '+')
        {
            a[n++] = (s[i] - 48);
        }
    }
    sort(a, a + n);
    cout << a[0];
    for (int i = 1; i < n; i++)
    {
        cout << "+" << a[i];
    }
    return 0;
}
/*
1 0 0 0 0
0 0 0 0 0
0 0 0 0 0
0 0 0 0 0
0 0 0 0 0
*/