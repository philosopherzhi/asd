﻿#include "bits/stdc++.h"
using namespace std;

int main()
{
    string s1;
    cin >> s1;

    vector<char> v;

    for (int i = 0; i < s1.length(); i += 2)
    {
        v.push_back(s1[i]);
    }
    sort(v.begin(), v.end());

    for (int i = 0; i < v.size() - 1; i++)
        cout << v[i] << "+";
    cout << v[v.size() - 1];
    cout << endl;

en:;
}
