﻿#include <bits/stdc++.h>
using namespace std;

int main()
{
    string s;
    getline(cin, s);


    int size = s.length();
    int arr[(size / 2) + 1];
    int count = 0;

    for (int i = 0; i < size; i += 2)
    {
        string s1 = s.substr(i, 1);
        int x = stoi(s1);
        arr[count] = x;
        count++;
    }

    // for(int i=0;i<count;i++)
    // {
    //     cout<<arr[i];
    // }

    for (int i = 0; i < count - 1; i++)
    {
        for (int j = i + 1; j < count; j++)
        {
            if (arr[j] < arr[i])
            {
                int temp = arr[j];
                arr[j] = arr[i];
                arr[i] = temp;
            }
        }
    }


    for (int i = 0; i < count - 1; i++)
    {
        cout << arr[i] << "+";
    }
    cout << arr[count - 1];
    return 0;
}