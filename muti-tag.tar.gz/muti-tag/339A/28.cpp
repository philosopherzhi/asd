﻿#include <iostream>
#include <string>
#include <bits/stdc++.h>
using namespace std;
int main()
{
    string st;
    cin >> st;
    vector<int> tab;
    int j = 0;
    for (int i = 0; i < st.size(); i = i + 2)
    {
        tab.push_back((int)st.at(i) - 48);
        j++;
    }
    sort(tab.begin(), tab.end());
    for (int i = 0; i < tab.size(); i++)
    {
        if (i != tab.size() - 1)
        {
            cout << tab[i] << "+";
        }
        else
        {
            cout << tab[i] << endl;
        }
    }
}
