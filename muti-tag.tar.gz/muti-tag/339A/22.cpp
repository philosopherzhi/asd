﻿#include <stdio.h>
#include <string.h>

void swap(int* xp, int* yp)
{
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}
void bubblesort(int* arr, int n)
{
    int i, j;
    for (i = 0; i < n - 1; i++)
    {
        for (j = 0; j < n - i - 1; j++)
        {
            if (arr[j] > arr[j + 1])
                swap(&arr[j], &arr[j + 1]);
        }
    }
}
int main()
{
    char string[101];

    scanf("%s", string);
    int len = strlen(string);
    int a[(len + 1) / 2];
    for (int i = 0; i < ((len + 1) / 2) && string[(2 * i)] != '\0'; i++)
    {
        a[i] = (string[(2 * i)] - '0');
    }
    bubblesort(a, ((len + 1) / 2));
    for (int i = 0; i < ((len + 1) / 2) && string[(2 * i)] != '\0'; i++)
    {
        (string[(2 * i)] = (char)a[i] + '0');
    }
    printf("%s\n", string);
}