﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define mx 1000005
#define IOS                                                                                        \
    ios::sync_with_stdio(0);                                                                       \
    cin.tie(0);                                                                                    \
    cout.tie(0);
ll a[mx];
ll b[mx];

int main()

{

    string s;
    cin >> s;
    ll l = s.size();
    vector<ll> v;
    for (ll i = 0; i < l; i++)
    {
        if (s[i] != '+')
        {
            ll x = s[i] - '0';
            v.push_back(x);
        }
    }
    sort(v.begin(), v.end());
    for (ll i = 0; i < v.size() - 1; i++)
        cout << v[i] << "+";
    cout << v[v.size() - 1];
}
