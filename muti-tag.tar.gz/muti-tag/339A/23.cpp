﻿#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define rep(i, a, n) for (ll i = a; i < n; i++)
#define pb push_back
#define ppb pop_back()
#define sz(x) (ll)(x.size());
#define mp make_pair
#define ss second
#define ff first
#define all(a) a.begin(), a.end()
#define flush fflush(stdout)
#define endl "\n"
#define mem(a, b) memset(a, b, sizeof(a))
#define maxx 100005
#define mod 1000000007
#define INF 2000000000000000
#define ro return 0;

template <typename T, typename U>
static inline void amin(T& x, U y)
{
    if (y < x)
        x = y;
}
template <typename T, typename U>
static inline void amax(T& x, U y)

{
    if (x < y)
        x = y;
}

ll cdiv(ll a, ll b)
{
    return a / b + ((a ^ b) > 0 && a % b);
} // divide a by b rounded up
ll fdiv(ll a, ll b)
{
    return a / b - ((a ^ b) < 0 && a % b);
} // divide a by b rounded down
ll max(ll a, ll b, ll c)
{
    return max(a, max(b, c));
}
ll min(ll a, ll b, ll c)
{
    return min(a, min(b, c));
}

ll gcd(ll a, ll b)
{
    if (b == 0)
        return (a);
    else
        return (gcd(b, a % b));
}
ll inverseMod(ll a, ll b)
{
    ll r = 1; // decrement the mod by 2
    while (b > 0)
    {
        if (b & 1)
            r = r * a % mod;
        a = a * a % mod;
        b /= 2;
    }
    return r;
}
ll comb(ll m, ll k) // comb val
{
    ll r = 1;
    ll d;
    for (d = 1; d <= k; d++)
    {
        r *= m--;
        r /= d;
    }
    return r;
}

//#define runSieve
bool prime[10000005];
ll hah[10000005];
void sieve(ll n = 10000002)
{
    mem(prime, true);
    mem(hah, 0);
    for (ll p = 2; p * p <= n; p++)
    {
        if (prime[p] == true)
        {
            hah[p] = p;
            for (ll i = p * p; i <= n; i += p)
            {
                prime[i] = false;
                if (hah[i] == 0)
                    hah[i] = p;
            }
        }
    }
}

// THE ACTUAL CODE BEGINS FROM HERE ONWARDS :

// long double pi = 3.1415927535897932384626433;
//#define NCR
// ll dp[1000005];

void _good_for_nothing_()
{
    string s;
    cin >> s;
    ll l = s.length();
    vector<ll> v;
    rep(i, 0, l)
    {
        v.pb(s[i] - '0');
        i++;
    }
    sort(all(v));
    rep(i, 0, v.size() - 1)
    {
        cout << v[i] << '+';
    }
    cout << v.back();
}

signed main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
#ifdef runSieve
    sieve();
#endif
#ifdef NCR
    initialize();
#endif
    ll TESTS = 1;
    // cin >> TESTS;
    while (TESTS--)
        _good_for_nothing_();

    return 0;
}