﻿
#include <iostream>
#include <bits/stdc++.h>
using namespace std;

int main()
{
    string s, w;
    cin >> s;
    w.clear();
    for (int i = 0; i < s.length(); i++)
        if (s[i] != '+')
        {
            w = w + s[i];
        }
    sort(w.begin(), w.end());
    for (int i = 0; i < w.length(); i++)
    {
        cout << w[i];
        if (i == w.length() - 1)
            cout << endl;
        else
            cout << "+";
    }

    return 0;
}