﻿#include <stdio.h>
#include <stdlib.h>

int Compare(int* a, int* b)
{
    return *a - *b;
}

int main(void)
{
    int numbers[50];
    int numOfN = 0;
    char c;

    while ((c = getchar()) != '\n')
        if (c != '+')
            numbers[numOfN++] = c - '0';

    qsort(numbers, numOfN, sizeof(int), (int (*)(const void*, const void*))Compare);
    printf("%i", numbers[0]);
    for (int i = 1; i < numOfN; i++)
        printf("+%i", numbers[i]);
    return 0;
}
