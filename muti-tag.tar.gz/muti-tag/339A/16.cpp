﻿#include <iostream>
#include <iomanip>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#define IO                                                                                         \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0);                                                                                    \
    cout.tie(0);
using namespace std;
int main()
{
    IO string s;
    cin >> s;
    sort(s.begin(), s.end());
    for (int i = 0; i < s.size(); i++)
    {
        if (s[i] == '+')
        {
            continue;
        }
        else
        {
            cout << s[i];
        }
        if (i != s.size() - 1)
        {
            cout << '+';
        }
    }
}
