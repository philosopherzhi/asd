﻿#include <bits/stdc++.h>
using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int n, m;
    string s, num = "";
    cin >> s;
    n = s.size();
    for (int i = 0; i < n; i++)
    {
        if (s[i] >= 48 && s[i] <= 57)
            num += s[i];
    }
    sort(num.begin(), num.end());
    m = num.size();
    for (int i = 0; i < m; i++)
    {
        cout << num[i];
        if (i < m - 1)
            cout << '+';
    }

    return 0;
}