﻿#include <bits/stdc++.h>
using namespace std;

int main()
{
    string a;
    vector<int> b;
    cin >> a;
    int num;
    for (int i = 0; i < (int)a.size(); i++)
    {
        if (a[i] != '+')

        {
            stringstream ss;
            ss << a[i];
            ss >> num;
            b.push_back(num);
        }
    }
    sort(b.begin(), b.end());
    for (int i = 0; i < (int)b.size() - 1; i++)
    {
        cout << b[i] << "+";
    }
    cout << b[b.size() - 1] << "\n";
    return 0;
}
