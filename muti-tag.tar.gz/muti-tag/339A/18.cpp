﻿// solution for codeforces A. Helpful Maths problem
#include <bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    cin >> s;
    // create string
    vector<char> c;
    // create char vector
    for (int i = 0; i < s.length(); i += 2)
    {
        c.push_back(s[i]);
    }
    sort(c.begin(), c.end());
    for (int i = 0; i < c.size(); i++)
    {
        if (i == 0)
        {
            cout << c[i];
        }
        else
        {
            cout << "+" << c[i];
        }
    }
    return 0;
}