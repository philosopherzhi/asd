﻿#include <iostream>
#include <algorithm>
#include <string>
#include <array>
using namespace std;

int main(int argc, char* argv[])
{
    string s;
    char a[1000];
    cin >> s;
    int k = 0;
    for (int i = 0; i < s.size(); i++)
    {

        if (s[i] != '+')
        {

            a[k] = { s[i] };
            k++;
        }
    }
    sort(a, a + k);
    for (int o = 0; o < k; o++)
    {
        if (o == k - 1)
            cout << a[o] << endl;
        else
            cout << a[o] << "+";
    }
}
