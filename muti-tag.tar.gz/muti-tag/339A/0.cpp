﻿#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int tc;
    tc = 1;
    while (tc--)
    {
        string s;
        cin >> s;
        int n = s.size();
        int l = (n + 1) / 2;
        vector<int> v(l);
        int k = 0;
        for (int i = 0; i < n; i = i + 2)
        {
            int x = (int)s[i];
            x = x - 48;
            v[k] = x;
            k++;
        }
        sort(v.begin(), v.end());
        vector<char> r;
        for (int i = 0; i < l; i++)
            v[i] += 48;
        for (int i = 0; i < l; i++)
        {
            char op = (char)v[i];
            r.push_back(op);
            r.push_back('+');
        }
        r.pop_back();
        int d = r.size();
        for (int i = 0; i < d; i++)
        {
            cout << r[i];
        }
        cout << endl;
    }
}
