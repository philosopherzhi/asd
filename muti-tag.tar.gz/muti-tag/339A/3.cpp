﻿#include <iostream>
#include <cstring>
using namespace std;

int main()
{
    int l, tmp1, tmp2;
    char s[101];

    cin >> s;

    l = strlen(s);
    int i, j;
    for (i = 0; i < l - 2; i += 2)
    {
        for (j = 0; j < l - 2; j += 2)
        {
            tmp1 = s[j];
            tmp2 = s[j + 2];
            if (s[j] > s[j + 2])
            {
                s[j] = tmp2;
                s[j + 2] = tmp1;
            }
        }
    }
    cout << s;

    return 0;
}
