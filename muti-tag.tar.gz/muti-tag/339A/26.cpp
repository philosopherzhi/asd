﻿#include <bits/stdc++.h>
using namespace std;

// cntr + shft + B

int main()
{
    string s;
    cin >> s;
    int l = s.length();
    for (int j = 0; j < l; j += 2)
    {
        for (int i = 0; i < l - j - 2; i += 2)
        {
            if (s[i] > s[i + 2])
            {
                swap(s[i], s[i + 2]);
            }
        }
    }
    cout << s << endl;
    return 0;
}
