﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    int j[1000], k = 1;
    scanf("%d", &j[0]);
    while (cin >> j[k])
        k++;
    sort(j, j + k);
    cout << j[0];
    for (int i = 1; i < k; i++)
    {
        cout << "+" << j[i];
    }
}