﻿#include <stdio.h>
#include <string.h>
void insertionsort(char S[], int len)
{
    int i, j;
    for (i = 2; i < len; i += 2)
    {
        char key = S[i];
        j = i - 2;
        while (j > -1 && S[j] > key)
        {
            S[j + 2] = S[j];
            j -= 2;
        }
        S[j + 2] = key;
    }
}
int main()
{
    char S[100];
    scanf("%s", S);
    int len = strlen(S);
    insertionsort(&S[0], len);
    printf("%s", S);
}
