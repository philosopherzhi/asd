﻿#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <list>
#include <time.h>
#include <stdlib.h>
#include <map>
#include <fstream>
#include <math.h>
#include <algorithm>
#include <iterator>
#include <queue>
#include <stack>
using namespace std;
int main()
{
    string r;
    cin >> r;
    vector<char> vec;
    for (int i = 0; i < size(r); i += 2)
    {
        vec.push_back(r[i]);
    }
    sort(vec.begin(), vec.end());
    if (vec.size() == 1)
        cout << vec[0];
    else
    {
        cout << vec[0];
        for (int i = 1; i < vec.size(); i++)
        {
            cout << "+" << vec[i];
        }
    }
}