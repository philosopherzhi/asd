﻿#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <bits/stdc++.h>


using namespace std;


int main()
{
    string inp;
    cin >> inp;
    vector<int> v;
    int i;
    char ch;
    stringstream ss(inp);
    while (ss >> i)
    {
        v.push_back(i);
        ss >> ch;
    }

    sort(v.begin(), v.end());
    int n = v.size();

    int c = 0;

    for (auto x : v)
    {
        cout << x;
        c++;
        if (c != n)
        {
            cout << '+';
        }
    }


    return 0;
}