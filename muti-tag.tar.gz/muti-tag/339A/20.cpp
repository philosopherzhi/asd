﻿#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
bool prime[10 ^ 6 + 1];
void Sieve(ll n)
{
    for (ll p = 2; p * p <= n; p++)
    {
        if (prime[p] == true)
        {
            for (ll i = p * p; i <= n; i += p)
                prime[i] = false;
        }
    }
}
void nn()
{
    cout << endl;
}
void solve()
{
    string s;
    cin >> s;
    vector<ll> v;
    for (auto x : s)
    {
        if (x != '+')
            v.push_back((int)x);
    }
    sort(v.begin(), v.end());
    for (ll i = 0; i < v.size(); i++)
    {
        if (i != v.size() - 1)
            cout << (char)v[i] << '+';
        else
            cout << (char)v[i];
    }
}

int main()
{
    // memset(prime, true, sizeof(prime));
    solve();
}