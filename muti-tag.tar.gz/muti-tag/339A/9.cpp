﻿#include <iostream>

using namespace std;

long long n, i, k;
string s;
long long a[5];

int main()
{
    cin >> s;
    k = 1;

    n = s.size();
    for (i = 0; i < n; i++)
    {
        if (i % 2 == 0)
        {
            if (s[i] == '1')
                a[1]++;
            if (s[i] == '2')
                a[2]++;
            if (s[i] == '3')
                a[3]++;
        }
    }
    if (n == 1)
    {
        if (a[1] > 0)
            cout << 1 << endl;
        else if (a[2] > 0)
            cout << 2 << endl;
        else
            cout << 3 << endl;
    }

    else if (a[3] > 0)
    {
        for (i = 1; i <= a[1]; i++)
            cout << 1 << "+";
        for (i = 1; i <= a[2]; i++)
            cout << 2 << "+";
        for (i = 1; i < a[3]; i++)
            cout << 3 << "+";
        cout << 3 << endl;
    }

    else if (a[2] > 0)
    {
        for (i = 1; i <= a[1]; i++)
            cout << 1 << "+";
        for (i = 1; i < a[2]; i++)
            cout << 2 << "+";
        cout << 2 << endl;
    }

    else
    {
        for (i = 1; i < a[1]; i++)
            cout << 1 << "+";
        cout << 1 << endl;
    }

    return 0;
}
