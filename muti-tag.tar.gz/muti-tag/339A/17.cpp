﻿#include <bits/stdc++.h>
using namespace std;

void helpfulMaths(string expression)
{
    string ex;

    for (int i = 0; i < expression.length(); i++)
    {
        if (expression[i] != '+')
        {
            ex.push_back(expression[i]);
        }
    }
    sort(ex.begin(), ex.end());
    for (int k = 0; k < ex.length(); k++)
    {
        cout << ex[k];
        if (k != ex.length() - 1)
        {
            cout << "+";
        }
    }
}

int main()
{

    string expression;
    cin >> expression;
    helpfulMaths(expression);
    return 0;
}