﻿#include <bits/stdc++.h>
using namespace std;
int const N = 5e5 + 5, mod = 1e9 + 7, oo = 1e5 + 10;
typedef long long ll;
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    /***/
    ll t, cnt1 = 0, cnt2 = 0, cnt3 = 0, check;
    string s;
    cin >> s;
    for (int i = 0; i < s.size(); i += 2)
    {
        if (s[i] == '1')
            cnt1++;
        else if (s[i] == '2')
            cnt2++;
        else
            cnt3++;
    }
    check = cnt1 + cnt2 + cnt3;
    for (int i = 0; i < check; i++)
    {
        if (cnt1 && (cnt2 || cnt3 || !(cnt1 == 1)))
        {
            cout << 1 << "+";
            cnt1--;
            continue;
        }
        else if (cnt1)
        {
            cout << 1 << "";
            cnt1--;
            continue;
        }
        if (cnt2 && (cnt3 || !(cnt2 == 1)))
        {
            cout << 2 << "+";
            cnt2--;
            continue;
        }
        else if (cnt2)
        {
            cout << 2 << "";
            cnt2--;
            continue;
        }
        if (cnt3 && cnt3 == 1)
        {
            cout << 3 << "";
            cnt3--;
            continue;
        }
        else if (cnt3)
        {
            cout << 3 << "+";
            cnt3--;
            continue;
        }
    }
    return 0;
}
