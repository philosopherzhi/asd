﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    string n;
    cin >> n;
    for (int i = 0; i < n.size(); i = i + 2)
    {
        for (int j = i; j < n.size(); j = j + 2)
        {
            if (n[i] > n[j])
            {
                swap(n[i], n[j]);
            }
        }
    }
    cout << n;
    return 0;
}
