﻿#include <iostream>
using namespace std;
int main()
{
    int num1 = 0, num2 = 0, num3 = 0;
    string a;
    cin >> a;
    for (int i = 0; i < a.length(); i++)
    {
        if (a[i] == '1')
            num1++;
        if (a[i] == '2')
            num2++;
        if (a[i] == '3')
            num3++;
    }
    while (num1--)
    {
        cout << "1";
        if (!(num1 + num2 + num3))
            continue;
        cout << "+";
    }
    while (num2--)
    {
        cout << "2";
        if (!(num2 + num3))
            continue;
        cout << "+";
    }
    while (num3--)
    {
        cout << '3';
        if (!(num3))
            continue;
        cout << "+";
    }
    return 0;
}