﻿#include <bits/stdc++.h>
using namespace std;

int main()
{
    string s;
    cin >> s;

    int one = 0, two = 0, three = 0;
    int plus = 0;

    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] == '+')
        {
            plus++;
        }
        if (s[i] == '1')
        {
            one++;
        }
        if (s[i] == '2')
        {
            two++;
        }
        if (s[i] == '3')
        {
            three++;
        }
    }

    while (one != 0)
    {
        cout << '1';
        one--;
        if (plus != 0)
        {
            cout << '+';
            plus--;
        }
    }
    while (two != 0)
    {
        cout << '2';
        two--;
        if (plus != 0)
        {
            cout << '+';
            plus--;
        }
    }
    while (three != 0)
    {
        cout << '3';
        three--;
        if (plus != 0)
        {
            cout << '+';
            plus--;
        }
    }
}