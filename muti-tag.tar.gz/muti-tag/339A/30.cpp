﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main()
{
    string s;
    cin >> s;
    int ones, two, three;
    ones = two = three = 0;
    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] == '1')
            ones++;
        if (s[i] == '2')
            two++;
        if (s[i] == '3')
            three++;
    }
    string out = "";
    while (ones)
    {
        out += "1+";
        ones--;
    }
    while (two)
    {
        out += "2+";
        two--;
    }
    while (three)
    {
        out += "3+";
        three--;
    }
    out.erase(out.length() - 1);
    cout << out << endl;
}