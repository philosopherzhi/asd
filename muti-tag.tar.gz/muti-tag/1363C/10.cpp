﻿#include <bits/stdc++.h>
#define ll long long
#define ld long double
using namespace std;
bool isprime(ll x)
{
    if (x == 2)
        return true;
    if (x == 3)
        return true;
    for (ll i = 2; i * i <= x; i++)
    {
        if (x % i == 0)
            return false;
    }
    return true;
}
bool issort(ll a[], ll n)
{
    for (ll i = 1; i < n; i++)
    {
        if (a[i - 1] >= a[i])
        {
            return false;
        }
    }
    return true;
}
ll gcd(ll a, ll b)
{
    if (b == 0)
        return a;
    return gcd(b, a % b);
}
void solve()
{
    ll n, x, u, v, c = 0;
    cin >> n >> x;
    for (ll i = 1; i < n; i++)
    {
        cin >> u >> v;
        if (u == x || v == x)
        {
            c++;
        }
    }
    if (c < 2 || n % 2 == 0)
    {
        cout << "Ayush\n";
    }
    else
    {
        cout << "Ashish\n";
    }
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    ll t;
    t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
    return 0;
}
