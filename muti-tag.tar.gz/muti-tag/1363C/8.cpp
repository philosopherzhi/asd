﻿#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;


int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int t, n, x, u, v;
    cin >> t;
    while (t--)
    {
        cin >> n >> x;
        int inDegreex = 0;
        for (int i = 0; i < n - 1; i++)
        {
            cin >> u >> v;
            if (u == x)
                inDegreex++;
            if (v == x)
                inDegreex++;
        }
        if (inDegreex <= 1)
        {
            cout << "Ayush" << endl;
        }
        else
        {
            if (n & 1)
            {
                cout << "Ashish" << endl;
            }
            else
            {
                cout << "Ayush" << endl;
            }
        }
    }
    return 0;
}