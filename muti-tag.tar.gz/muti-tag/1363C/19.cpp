﻿#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define fr(i, x, y) for (int i = (int)x; i < (int)y; ++i)
#define frr(i, x, y) for (int i = (int)x; i >= (int)y; --i)
#define all(x) x.begin(), x.end()
#define sortall(x) sort(all(x))
#define null NULL
#define endl "\n"
#define m_p(x, y) make_pair(x, y)
#define fs first
#define se second
#define pb push_back
#define eb emplace_back
#define sz(x) x.size()
#define bits(x) __builtin_popcountll(x)

#define newline cout << "\n"
#define debug(x) cout << #x << ':' << x << endl
#define debugArr(A)                                                                                \
    cout << #A << ':';                                                                             \
    for (auto x : A)                                                                               \
        cout << x << ' ';                                                                          \
    cout << endl

typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ll> vl;
typedef vector<vl> vvl;
typedef vector<string> vs;
typedef vector<bool> vb;
typedef set<int> si;
typedef set<ll> sl;
typedef map<int, int> mii;
typedef map<ll, ll> mll;
typedef unordered_set<int> usi;
typedef unordered_set<ll> usl;
typedef unordered_map<int, int> umii;
typedef unordered_map<ll, ll> umll;

void read()
{
    return;
}
void print()
{
    return;
}
template <typename T1, typename... T2>
void read(T1& x, T2&... args)
{
    ((cin >> x), read(args...));
}
template <typename T1, typename... T2>
void print(T1 x, T2... args)
{
    ((cout << x << ' '), print(args...));
}
template <typename T>
void readArr(T& lst, int x, int y)
{
    fr(i, x, y) cin >> lst[i];
}
template <typename T>
void printArr(T& lst, int x, int y)
{
    fr(i, x, y) cout << lst[i] << ' ';
}

const int N = 1e6;
const int INF = 1e9;
const int MOD = 1e9 + 7;

int countBits(ll number)
{
    return (int)log2(number) + 1;
}
ll add(ll x, ll y)
{
    return (x + y) % MOD;
}
ll sub(ll x, ll y)
{
    return (x - y + MOD) % MOD;
}
ll mul(ll x, ll y)
{
    return (x * 1ll * y) % MOD;
}
ll inv(ll p, ll q)
{
    ll expo = MOD - 2;
    while (expo)
    {
        if (expo & 1)
            p = mul(p, q);
        q = mul(q, q), expo >>= 1;
    }
    return p;
}
ll power(ll x, ll y)
{
    if (y == 0)
        return 1;
    else if (y % 2 == 0)
    {
        ll tmp = power(x, y / 2);
        return mul(tmp, tmp);
    }
    else
        return mul(x, power(x, y - 1));
}
ll gcd(ll a, ll b)
{
    if (b == 0)
        return a;
    return gcd(b, a %= b);
}

//=========================CODE IS HERE======================//

void solveTestCase()
{
    int n, x;
    read(n, x);
    vi cnt(n + 1, 0);
    int u, v;
    fr(i, 0, n - 1)
    {
        read(u, v);
        cnt[u]++, cnt[v]++;
    }
    if (cnt[x] == 1 || n == 1 || n % 2 == 0)
        print("Ayush");
    else
        print("Ashish");
    newline;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);
    int t = 1;
    cin >> t;
    while (t--)
        solveTestCase();
    return 0;
}