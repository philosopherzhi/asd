﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, k;
        cin >> n >> k;
        int ans = 0;
        for (int i = 0; i < n - 1; i++)
        {
            int u, v;
            cin >> u >> v;
            if (u == k || v == k)
                ans++;
        }
        if (ans == 1 || n == 1)
            cout << "Ayush" << endl;
        else if ((n - 1) % 2 == 1)
            cout << "Ayush" << endl;
        else
            cout << "Ashish" << endl;
    }
}