﻿#include <bits/stdc++.h>
using namespace std;
#define int long long
#define fi first
#define se second
#define pi pair<int, int>
#define pb push_back
#define all(a) (a).begin(), (a).end()
#define sz(x) (int)((x).size())
#define de(x)                                                                                      \
    {                                                                                              \
        cout << #x << " = " << x << endl;                                                          \
    }
#define fix(prec)                                                                                  \
    {                                                                                              \
        cout << setprecision(prec) << fixed;                                                       \
    }
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define Speed_and_Power_is_the_answer                                                              \
    std::ios_base::sync_with_stdio(0);                                                             \
    std::cin.tie(NULL);
#define readgraph(list, edges)                                                                     \
    for (int i = 0; i < edges; i++)                                                                \
    {                                                                                              \
        int a, b;                                                                                  \
        cin >> a >> b;                                                                             \
        a--;                                                                                       \
        b--;                                                                                       \
        list[a].pb(b);                                                                             \
        list[b].pb(a);                                                                             \
    }
void yesNo(int n, int x = 0)
{
    if (x == 0)
        cout << (n ? "YES\n" : "NO\n");
    else
    {
        cout << (n ? "Yes\n" : "No\n");
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
template <typename A>
ostream& operator<<(ostream& cout, vector<A> const& v);
template <typename A, typename B>
ostream& operator<<(ostream& cout, pair<A, B> const& p)
{
    return cout << "(" << p.fi << ", " << p.se << ")";
}
template <typename A>
ostream& operator<<(ostream& cout, vector<A> const& v)
{
    cout << "[";
    for (int i = 0; i < v.size(); i++)
    {
        if (i)
            cout << ", ";
        cout << v[i];
    }
    return cout << "]";
}
template <typename A, typename B>
istream& operator>>(istream& cin, pair<A, B>& p)
{
    cin >> p.first;
    return cin >> p.second;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const int mod = 1e9 + 7;
const int N = 1e5 + 5;
const int MAX = 1e18;
std::vector<int> dx = { 1, 0, -1, 0 };
std::vector<int> dy = { 0, 1, 0, -1 };
int f, n, m, k, q, l, r, x, y, z, ans;
std::vector<int> adl[1005];
std::vector<int> vis(1005);
void dfs(int u)
{
    vis[u] = 1;
    for (auto i : adl[u])
    {
        if (!vis[i])
            dfs(i);
    }
}
void dfsUtil()
{
    vis[x] = 1;
    for (auto i : adl[x])
    {
        dfs(i);
    }
}
std::vector<int> a(N), b(N), v;
void solve()
{
    f = 0;
    ans = 0;
    cin >> n >> x;

    for (int i = 0; i < 1005; i++)
    {
        adl[i].clear();
        vis[i] = 0;
    }

    readgraph(adl, n - 1);

    x--;
    if (sz(adl[x]) == 1 or sz(adl[x]) == 0)
    {
        cout << "Ayush\n";
        return;
    }
    // dfsUtil();
    // //bde(vis);
    // for (int i = 0; i < 1005; i++){
    //     ans+=vis[i];
    // }

    // //de(ans);
    // ans-=3;
    // de(ans);

    ans = n - 3;
    if (ans & 1)
    {
        cout << "Ayush\n";
    }
    else
    {
        cout << "Ashish\n";
    }
}
main()
{
    Speed_and_Power_is_the_answer
#ifndef ONLINE_JUDGE
        freopen("input.txt", "r", stdin);
    freopen("result.txt", "w", stdout);
#endif

    int t = 1;
    std::cin >> t;
    for (int test = 1; test <= t; test++)
    {
        // de(test);
        solve();
    }
}
