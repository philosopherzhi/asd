﻿#include <iostream>
using namespace std;
int nodes, sp_node;
int node_u, node_v;
int degree = 0;

int main()
{

    int test_cases;
    cin >> test_cases;
    while (test_cases--)
    {
        int degree = 0;
        cin >> nodes >> sp_node;
        int counter = nodes;

        while (counter != 1)
        {
            cin >> node_u >> node_v;
            if (node_u == sp_node || node_v == sp_node)
                degree++;
            counter--;
        }

        if (degree <= 1)
        {
            cout << "Ayush" << endl;
            continue;
        }

        if (nodes % 2 == 0)
        {
            cout << "Ayush" << endl;
            continue;
        }
        else
        {
            cout << "Ashish" << endl;
            continue;
        }
    }

    return 0;
}
