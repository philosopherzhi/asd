﻿// If you're hacking me, at least subscribe to my channel at:
// https://www.youtube.com/user/ivanvlahov922

#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int MOD = 1e9 + 7;
const double DEG2RAD = 0.017453292;
const double RAD2DEG = 57.29578049;

int main()
{

#ifdef DEBUG
    freopen("..\\input.txt", "r", stdin);
    clock_t tStart = clock();
#endif

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int TEST;
    cin >> TEST;

    for (; TEST; TEST--)
    {
        // Don't forget to clear global variables if you use them
        int n, x;
        cin >> n >> x;

        vector<vector<int>> tree(n + 1);

        for (int i = 0; i < n - 1; i++)
        {
            int a, b;
            cin >> a >> b;
            tree[a].push_back(b);
            tree[b].push_back(a);
        }

        bool ayushFirst = true;

        if (tree[x].size() <= 1)
        {
            cout << "Ayush";
        }
        else
        {
            ayushFirst = ((n - tree[x].size() - 1) % 2 == 0);
            ayushFirst ^= ((tree[x].size() - 2) % 2 != 0);

            if (ayushFirst)
            {
                cout << "Ashish";
            }
            else
            {
                cout << "Ayush";
            }
        }

        // if(tree[x].size() > 1 && (n - tree[x].size() - 1) % 2 == 0) {
        //     cout << "Ashish";
        // } else {
        //     cout << "Ayush";
        // }

        cout << "\n";
    }

// Use formatted output if the result is float or double

#ifdef DEBUG
    printf("Time taken: %.2fs\n", (double)(clock() - tStart) / CLOCKS_PER_SEC);
#endif

    return 0;
}