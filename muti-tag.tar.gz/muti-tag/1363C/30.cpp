﻿#include <bits/stdc++.h>
using namespace std;
const int N = 2050;
#define ll long long
int a[N];
int main()
{
    int t, n, m;
    cin >> t;
    while (t--)
    {
        cin >> m >> n;
        fill(a, a + 2050, 0);
        for (int i = 1, k, kk; i < m; i++)
            cin >> k >> kk, a[k]++, a[kk]++;
        if (a[n] == 0 || a[n] == 1)
            cout << "Ayush" << endl;
        else if (m % 2 == 1)
            cout << "Ashish" << endl;
        else
            cout << "Ayush" << endl;
    }


    return 0;
}
