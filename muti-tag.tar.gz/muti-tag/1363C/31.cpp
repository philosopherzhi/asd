﻿#include <bits/stdc++.h>
using namespace std;
const int maxn = 20009;
int in[maxn];
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, x;
        cin >> n >> x;
        memset(in, 0, sizeof(in));
        for (int i = 1; i < n; i++)
        {
            int l, r;
            cin >> l >> r;
            in[l]++, in[r]++;
        }
        if (in[x] == 1 || in[x] == 0)
            cout << "Ayush" << endl;
        else if ((n - 1) % 2 == 1)
            cout << "Ayush" << endl;
        else
            cout << "Ashish" << endl;
    }
}
