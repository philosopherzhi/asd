﻿#include <bits/stdc++.h>

using namespace std;
#define rep(i, l, r) for (auto i = (l); i <= (r); ++i)
#define per(i, r, l) for (auto i = (r); i >= (l); --i)
#define N 2000020
#define ll long long
int n, a[N], x, ct[N];

inline void solve()
{
    scanf("%d%d", &n, &x);
    rep(i, 1, n) ct[i] = 0;
    rep(i, 1, n - 1)
    {
        int u, v;
        scanf("%d%d", &u, &v);
        ++ct[u], ++ct[v];
    }
    if (ct[x] == 1 || n <= 2)
    {
        puts("Ayush");
        return;
    }
    puts(((n - 3) & 1) ? "Ayush" : "Ashish");
}

int main()
{
    int T = 1;
    scanf("%d", &T);
    while (T--)
        solve();
}
