﻿/*
    # Enjoy the journey #
*/
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pb push_back
#define forq(i, a, b) for (int i = (a); i <= (b); ++i)
#define qrof(i, b, a) for (int i = (a); i >= (b); --i)
#define forr(i, b) forq(i, 0, b - 1)
#define F first
#define S second
#define IF ->first
#define IS ->second
#define endl '\n'
#define qqmemset(array, val) memset(array, val, sizeof(array))
#define ALLV(vect) vect.begin(), vect.end()
#define mid (st + en) / 2
#define mid1 (2 * st + en) / 3
#define mid2 (2 * en + st) / 3
#define lef 2 * Node
#define rig lef + 1
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
#define Ran(a, b) rng() % ((b) - (a) + 1) + (a)

ll R = 7 + 1e9, R1 = 19491001, R2 = 236, NUMTESTCASE;
const ll NN = 10 + 1e6;
const double pi = acos(-1.0);
int di[8] = { 1, 0, -1, 0, 1, -1, 1, -1 }, dj[8] = { 0, 1, 0, -1, 1, -1, -1, 1 };
int n, x, u, v, Size[NN], Parent[NN];
vector<int> G[NN];
void Dfs(int Ver, int Par)
{
    Parent[Ver] = Par;
    Size[Ver] = 1;
    for (int u : G[Ver])
        if (u ^ Par)
            Dfs(u, Ver), Size[Ver] += Size[u];
}
int main()
{
    // ios_base::sync_with_stdio(false); cin.tie(NULL);cout.tie(NULL) ;
    for (cin >> NUMTESTCASE; NUMTESTCASE; NUMTESTCASE--)
    {
        scanf("%d%d", &n, &x);
        forq(i, 1, n) G[i].clear();

        forq(i, 2, n)
        {
            scanf("%d%d", &u, &v);
            G[u].pb(v);
            G[v].pb(u);
        }

        if (G[x].size() <= 1)
        {
            printf("Ayush\n");
            continue;
        }
        if (n % 2 == 0)
            printf("Ayush\n");
        else
            printf("Ashish\n");
    }
    return 0;
}
