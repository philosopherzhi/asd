﻿#include <iostream>

int main()
{
    int n, x, a, b, deg, t;

    std::cin >> t;

    for (int i = 0; i < t; i++)
    {
        std::cin >> n >> x;
        deg = 0;

        for (int j = 0; j < n - 1; j++)
        {
            std::cin >> a >> b;

            if (a == x || b == x)
                deg++;
        }

        (deg < 2) ? std::cout << "Ayush\n" : (n & 1) ? std::cout << "Ashish\n" : std::cout
                    << "Ayush\n";
    }

    return 0;
}