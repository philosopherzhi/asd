﻿#include <bits/stdc++.h>

using namespace std;

void testCase()
{
    int n, x;
    cin >> n >> x;
    vector<int> degree(n + 1);
    for (int i = 1; i < n; i++)
    {
        int u, v;
        cin >> u >> v;
        degree[u]++;
        degree[v]++;
    }
    if (degree[x] <= 1)
        cout << "Ayush\n";
    else
    {
        if (n & 1)
            cout << "Ashish\n";
        else
            cout << "Ayush\n";
    }
}

signed main()
{
    cin.tie(0)->sync_with_stdio(0);
    cin.exceptions(cin.failbit);
    int t;
    cin >> t;
    while (t--)
        testCase();
}
