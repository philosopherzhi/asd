﻿#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <cstring>

#define x first
#define y second

using namespace std;

typedef long long LL;

const int N = 1010;

int n, x;
int d[N];

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> n >> x;
        memset(d, 0, sizeof d);
        for (int i = 0; i < n - 1; i++)
        {
            int u, v;
            cin >> u >> v;
            d[u]++, d[v]++;
        }

        if (d[x] <= 1)
        {
            cout << "Ayush" << endl;
            continue;
        }

        if (n % 2)
            cout << "Ashish" << endl;
        else
            cout << "Ayush" << endl;
    }
    return 0;
}
