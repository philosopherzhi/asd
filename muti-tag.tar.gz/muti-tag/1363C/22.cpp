﻿#include <bits/stdc++.h>
#define mod 1000000007
#define pb push_back
#define ___                                                                                        \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0);
typedef long long int lli;
using namespace std;
const int N = 1005;
lli n, m, i, j, k;
lli mini = 1000000100, maxi = -1, res, sum = 0;
int main()
{
    ___
        //	freopen("C:\\Users\\harsh\\Documents\\Competitive Coding\\in.txt","r",stdin);
        int t;
    cin >> t;
    while (t--)
    {
        cin >> n >> k;
        vector<int> g[N];
        int deg[N], a, b;
        memset(deg, 0, sizeof deg);
        for (i = 0; i < n - 1; i++)
            cin >> a >> b, deg[a]++, deg[b]++;
        if (deg[k] <= 1)
            cout << "Ayush\n";
        else
        {
            if (n % 2)
                cout << "Ashish\n";
            else
                cout << "Ayush\n";
        }
    }
    return 0;
}
