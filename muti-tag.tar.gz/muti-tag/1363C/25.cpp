﻿//#pragma GCC optimize("O3")
#include <bits/stdc++.h>
#include <complex>
#define ll long long
#define inf 1e18
#define sinf 1e9 + 500
#define ld long double
#define ull unsigned long long
#define poll complex<double>
#define line pair<poll, poll>
#define pi acos(-1)
#define lp(a, b, c, d) for (ll a = b; a < c; a += d)
#define endl '\n'
#define EPS 1e-12
#define IO                                                                                         \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(NULL);                                                                                 \
    cout.tie(NULL);                                                                                \
// freopen("sum.in", "r", stdin);
#define mod 998244353
using namespace std;
const ll N = 1e3 + 5, SEG = (1 << 19);
int n, x;
vector<int> graph[N];
string res;
void init()
{
    cin >> n >> x;
    x--;
    int a, b;
    for (int i = 0; i < N; i++)
    {
        graph[i].clear();
    }
    for (int i = 0; i < n - 1; i++)
    {
        cin >> a >> b;
        a--;
        b--;
        graph[a].push_back(b);
        graph[b].push_back(a);
    }
}
int cnt(int cur, int par, int dpth)
{
    int c = 0;
    if (dpth >= 1)
        c++;

    for (auto v : graph[cur])
    {
        if (v != par)
            c += cnt(v, cur, dpth + 1);
    }
    return c;
}
void solve()
{
    if (graph[x].size() <= 1)
    {
        res = "Ayush";
        return;
    }
    int gg = cnt(x, x, 0);
    if (gg % 2 == 0)
    {
        res = "Ashish";
    }
    else
        res = "Ayush";
}
int main()
{
    IO int t;
    cin >> t;
    while (t--)
    {
        init();
        solve();
        cout << res << endl;
    }

    return 0;
}