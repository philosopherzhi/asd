﻿#include <iostream>
#include <cstdio>
using namespace std;
int T, n, x, cnt[1005];
int main()
{
    int u, v;
    scanf("%d", &T);
    while (T--)
    {
        scanf("%d%d", &n, &x);
        for (int i = 1; i < n; ++i)
        {
            scanf("%d%d", &u, &v);
            cnt[u]++;
            cnt[v]++;
        }
        if (cnt[x] <= 1 || n % 2 == 0)
            printf("Ayush\n");
        else
            printf("Ashish\n");
        for (int i = 1; i <= n; ++i)
            cnt[i] = 0;
    }
    return 0;
}
