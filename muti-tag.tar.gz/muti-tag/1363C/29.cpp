﻿#include <bits/stdc++.h>
using namespace std;

// Shortcuts for "common" data types in contests
typedef long long ll;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef pair<char, char> pcc;
typedef pair<char, int> pci;
typedef pair<int, char> pic;
typedef vector<pii> vpii;
typedef set<int> si;
typedef set<ll> sll;
typedef map<int, int> mii;
typedef map<ll, ll> mll;
#define ff first
#define ss second
#define endl '\n'
#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define rep(i, a, b) for (int i = a; i < b; i++)
#define repv(c, it)                                                                                \
    \
for(vll::iterator it = (c).begin(); it != (c).end(); it++)
#define repm(c, it)                                                                                \
    \
for(mll::iterator it = (c).begin(); it != (c).end(); it++)


int main()
{
    // decreases the time taken by cin,cout.
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(0);

    ll t;
    cin >> t;

    while (t--)
    {
        int n, x;
        cin >> n >> x;
        vector<vi> v(n);
        rep(i, 0, n - 1)
        {
            int z, y;
            cin >> z >> y;
            v[z - 1].push_back(y - 1);
            v[y - 1].push_back(z - 1);
        }
        if (n == 1)
        {
            cout << "Ayush" << endl;
        }
        else
        {
            if (v[x - 1].size() == 1)
            {
                cout << "Ayush" << endl;
            }
            else
            {
                if (n % 2 == 0)
                {
                    cout << "Ayush" << endl;
                }
                else
                {
                    cout << "Ashish" << endl;
                }
            }
        }
    }


    return 0;
}
