﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define F first
#define S second
const ll N = 3e5 + 2;
const ll MOD = 1e9 + 7;
const ll Inf = MOD * MOD;
const long double eps = 1e-7;
const ll dx[] = { 1, -1, 0, 0 };
const ll dy[] = { 0, 0, 1, -1 };
ll n, m, x, u, v, timer, t = 1;
vector<int> adj[N];
void Solve()
{
    scanf("%lld%lld", &n, &x);
    for (int i = 1; i < n; ++i)
    {
        scanf("%lld%lld", &u, &v);
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    int m = (n - 1);
    if (adj[x].size() <= 1)
        m = 1;
    printf("%s", m % 2 == 0 ? "Ashish" : "Ayush");
    for (int i = 1; i <= n; ++i)
        adj[i].clear();
}
int main()
{
    scanf("%lld", &t);
    while (t--)
    {
        ++timer;
        Solve();
        puts("");
    }
}
// Section Time : 0;
