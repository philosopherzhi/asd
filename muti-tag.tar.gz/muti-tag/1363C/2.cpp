﻿#include <bits/stdc++.h>

#define int long long

using namespace std;

void solve()
{
    int n, x, cnt = 0;
    cin >> n >> x;
    int m = n - 1;
    while (m--)
    {
        int u, v;
        scanf("%lld%lld", &u, &v);
        if (u == x || v == x)
            cnt++;
    }
    if (cnt == 1 || !cnt)
    {
        puts("Ayush");
        return;
    }
    if ((n - 1) & 1)
    {
        puts("Ayush");
    }
    else
    {
        puts("Ashish");
    }
}

signed main()
{
    int t;
    cin >> t;
    while (t--)
    {
        solve();
    }
    return 0;
}
