﻿#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define mod 1000000007

struct custom_hash
{
    static uint64_t splitmix64(uint64_t x)
    {
        x += 0x9e3779b97f4a7c15;
        x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;
        x = (x ^ (x >> 27)) * 0x94d049bb133111eb;
        return x ^ (x >> 31);
    }

    size_t operator()(uint64_t x) const
    {
        static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();
        return splitmix64(x + FIXED_RANDOM);
    }
};

bool isPrime(ll n)
{
    if (n <= 1)
        return false;
    if (n <= 3)
        return true;
    if (n % 2 == 0 || n % 3 == 0)
        return false;
    for (ll i = 5; i * i <= n; i = i + 6)
        if (n % i == 0 || n % (i + 2) == 0)
            return false;
    return true;
}
ll nextPrime(ll N)
{
    if (N <= 1)
        return 2;
    ll prime = N;
    bool found = false;
    while (!found)
    {
        prime++;
        if (isPrime(prime))
            found = true;
    }
    return prime;
}
ll fact(ll n)
{
    if (n == 1)
        return 1;
    return n * fact(n - 1);
}
ll cl(ll n, ll d)
{
    return (n + d - 1) / d;
}
ll gcd(ll a, ll b)
{
    if (b == 0)
        return a;
    return gcd(b, a % b);
}
ll lcm(ll a, ll b)
{
    return (a * b) / (gcd(a, b));
}


void solve()
{
    ll n, x, i;
    cin >> n >> x;

    vector<ll> deg(n + 1);
    for (i = 0; i < n - 1; i++)
    {
        ll x, y;
        cin >> x >> y;

        deg[x]++, deg[y]++;
    }
    if (deg[x] == 1 || n == 1)
    {
        cout << "Ayush\n";
        return;
    }
    // dfs(x);
    if (n % 2 == 0)
    {
        cout << "Ayush\n";
        return;
    }
    cout << "Ashish\n";
}


int main()
{

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    ll t;
    // SieveOfEratosthenes(1000000);
    cin >> t;
    // t=1;

    while (t--)
    {
        // y++;
        solve();
    }

    return 0;
}