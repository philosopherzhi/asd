﻿#include <bits/stdc++.h>
#define int long long int
#define pb push_back
#define fr first
#define sc second
#define vi vector<int>
#define MxN 100010
#define MOD 1000000007
#define INF 1000000000000000 // 10^15
#define all(x) (x).begin(), (x).end()
#define mkp make_pair
#define pii pair<int, int>
using namespace std;
const int N = 100000 + 5;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
vector<int> a[N];
void solve()
{
    for (int i = 0; i < N; i++)
        a[i].clear();
    int n, xx;
    cin >> n >> xx;
    for (int i = 1; i <= n - 1; i++)
    {
        int x, y;
        cin >> x >> y;
        a[x].pb(y);
        a[y].pb(x);
    }
    if (a[xx].size() >= 2)
    {
        if ((n - 3) % 2 == 0)
        {
            cout << "Ashish\n";
        }
        else
        {
            cout << "Ayush\n";
        }
    }
    else
    {
        cout << "Ayush\n";
    }
}
main()
{

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int t = 1;
    cin >> t;
    for (int i = 1; i <= t; i++)
    { // cout<<"Case #"<<i<<": ";
        solve();
        // cout<<"\n";
    }
}
