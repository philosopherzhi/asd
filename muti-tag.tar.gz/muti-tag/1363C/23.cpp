﻿#include <iostream>
using namespace std;

int n, x, a, b;


int adj[1001][1001], frunze[1001];

int main()
{
    int t;
    cin >> t;
    while (t--)
    {

        cin >> n >> x;

        if (n == 1 && x == 1)
        {
            cout << "Ayush\n";
            continue;
        }


        for (int i = 0; i < n - 1; i++)
        {
            cin >> a >> b;
            adj[a][b] = 1;
            adj[b][a] = 1;
        }

        int coun = 0;
        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= n; j++)
            {
                if (adj[i][j] > 0)
                    coun++;
            }
            if (coun == 1)
                frunze[i] = 1;
            coun = 0;
        }

        if (frunze[x] >= 1)
        {
            printf("Ayush \n");
        }
        else
        {
            if (n % 2)
                printf("Ashish\n");
            else
                printf("Ayush\n");
        }

        for (int i = 0; i <= 1000; i++)
        {
            frunze[i] = 0;
        }

        for (int i = 1; i <= 1000; i++)
        {
            for (int j = 1; j <= 1000; j++)

                adj[i][j] = 0;
        }
    }
}