﻿#include <bits/stdc++.h>
using namespace std;
#define int long long

int32_t main()
{

    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--)
    {
        int n, x;
        cin >> n >> x;
        int add = 0;
        for (int i = 1; i < n; i++)
        {
            int a, b;
            cin >> a >> b;
            if (a == x || b == x)
                add++;
        }
        if (add == 1 || n == 1)
        {
            cout << "Ayush\n";
            continue;
        }
        add = n - 1;
        if (add % 2 == 1)
        {
            cout << "Ayush\n";
        }
        else
        {
            cout << "Ashish\n";
        }
    }

    return 0;
}