﻿#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <queue>
#include <string>
#include <functional>
#include <cmath>
#include <limits>
#include <string.h>
#include <set>

#define ull unsigned long long
#define ll long long

const ull max_num = 10e18;

std::string C()
{
    ll n, x;
    std::cin >> n >> x;

    std::vector<ll> deg(n, 0);
    deg[0]--;
    std::vector<std::vector<ll>> adj_list(n);

    for (ll i = 0; i < n - 1; i++)
    {
        ll u, v;
        std::cin >> u >> v;
        u--;
        v--;

        adj_list[u].push_back(v);
        adj_list[v].push_back(u);
    }

    std::vector<bool> color(n, false);
    std::queue<ll> q;
    std::vector<std::vector<ll>> adj_list_child(n);
    q.push(0);

    while (q.size())
    {
        ll index = q.front();
        q.pop();

        ll degree = 0;
        for (ll i = 0; i < adj_list[index].size(); i++)
        {
            if (!color[adj_list[index][i]])
            {
                adj_list_child[index].push_back(adj_list[index][i]);
                q.push(adj_list[index][i]);
                degree++;
            }
        }

        color[index] = true;
        deg[index] += degree + 1;
    }

    x--;

    if (n == 1 || deg[x] < 2)
    {
        return "Ayush";
    }

    return (n % 2 == 0) ? "Ayush" : "Ashish";
}

int main()
{
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    ll t;
    std::cin >> t;

    while (t--)
    {
        std::cout << C() << '\n';
    }

    return 0;
}