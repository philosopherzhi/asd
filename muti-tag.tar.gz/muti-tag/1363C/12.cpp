﻿#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, x;
        cin >> n >> x;
        vector<vector<int> > tree(n + 1, vector<int>(0, 0));
        vector<int> deg(n + 1, 0);
        for (int i = 0; i < n - 1; i++)
        {
            int u, v;
            cin >> u >> v;
            tree[u].push_back(v);
            tree[v].push_back(u);
            deg[u]++;
            deg[v]++;
        }
        if (deg[x] <= 1)
        {
            cout << "Ayush" << endl;
            continue;
        }

        if (n % 2 == 1)
        {
            cout << "Ashish" << endl;
        }
        else
        {
            cout << "Ayush" << endl;
        }
    }
}
