﻿#include <iostream>
#include <bits/stdc++.h>
using namespace std;
vector<vector<int>> v(1001);
int d[10001];
int vis[1001];
int dfs(int node)
{
    int cur_size = 1;
    vis[node] = 1;
    for (int x : v[node])
    {
        if (!vis[x])
        {

            cur_size += dfs(x);
        }
    }
    d[node] = cur_size;

    return cur_size;
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, x;
        cin >> n >> x;
        for (int i = 0; i <= n; i++)
            d[i] = 0;
        for (int i = 0; i <= n; i++)
            v[i].clear();
        for (int i = 0; i <= n; i++)
            vis[i] = 0;
        for (int i = 0; i < n - 1; i++)
        {
            int a, b;
            cin >> a >> b;
            v[a].push_back(b);
            v[b].push_back(a);
        }
        if (v[x].size() == 1)
        {
            cout << "Ayush " << endl;
            continue;
        }
        int k = dfs(x);
        if (k == 1 || k == 2)
        {
            cout << "Ayush" << endl;
        }
        else
        {
            if (k % 2 == 0)
            {
                cout << "Ayush" << endl;
            }
            else
                cout << "Ashish" << endl;
        }
    }
}