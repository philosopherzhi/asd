﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long
ll n, x, ans, a, b, t;
int main()
{
    scanf("%lld", &t);
    for (int i = 1; i <= t; i++)
    {
        scanf("%lld %lld", &n, &x);
        for (int j = 1; j <= n - 1; j++)
        {
            scanf("%lld %lld", &a, &b);
            if (a == x or b == x)
                ans++;
        }
        if (ans <= 1 or n % 2 == 0)
            printf("Ayush\n");
        else
            printf("Ashish\n");
        ans = 0;
    }
    return 0;
}
