﻿#include <bits/stdc++.h>

using namespace std;

long long calc(list<int>* adj, int x, int previous = -1)
{
    long long sum = 0;

    for (auto& other : adj[x])
        if (other != previous)
            sum += calc(adj, other, x);

    return sum + 1;
}

int main()
{
    int t, n, i, j, k, l, m, x;

    cin >> t;

    while (t--)
    {
        cin >> n >> x;

        int leaf = 0;

        for (i = 0; i < n - 1; i++)
        {
            cin >> k >> l;

            if (k == x || l == x)
            {
                if (leaf == 0)
                    leaf = 1;
                else if (leaf == 1)
                    leaf = 2;
            }
        }

        if (leaf <= 1)
        {
            cout << "Ayush" << '\n';
        }
        else
        {
            if (n % 2 == 0)
                cout << "Ayush\n";
            else
                cout << "Ashish\n";
        }
    }

    return 0;
}