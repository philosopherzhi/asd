﻿#include <bits/stdc++.h>
using namespace std;
#define ss second
#define ll long long
#define ff first
#define ins insert
#define vt vector
#define ull unsigned long long
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
#define sz(a) (int) a.size()
#define pii pair<int, int>
#define pll pair<ll, ll>
#define vi vector<int>
#define vl vector<ll>
#define pb push_back
#define NDEBUG
const int MOD = 1e9 + 7; // 1073741824;
const int N = 2e6 + 1;
const ll INF = 9e18;
const int M = 505;
void DBG()
{
    cerr << "]" << endl;
}
template <class H, class... T>
void DBG(H h, T... t)
{
    cerr << to_string(h);
    if (sizeof...(t))
        cerr << ", ";
    DBG(t...);
}
#ifdef _DEBUG
#define dbg(i...)                                                                                  \
    cerr << "LINE(" << __LINE__ << ") -> [" << #__VA_ARGS__ << "]: [", DBG(__VA_ARGS__)
#else
#define dbg(...) 0
#endif

void solve()
{
    int n, m;
    cin >> n >> m;
    vt<int> cnt(n + 1);
    for (int i = 1; i < n; ++i)
    {
        int l, r;
        cin >> l >> r;
        cnt[l]++, cnt[r]++;
    }
    if (cnt[m] <= 1)
        cout << "Ayush\n";
    else
    {
        if (n % 2 == 0)
            cout << "Ayush\n";
        else
            cout << "Ashish\n";
    }
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int t = 1;
    cin >> t;
    while (t--)
        solve();
    return 0;
}
