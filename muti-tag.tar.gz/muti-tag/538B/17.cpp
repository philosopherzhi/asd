﻿#include <bits/stdc++.h>
#include <set>
#define ll long long
#include <string>
#define pb push_back
#define mp make_pair
#define all(v) v.begin(), v.end()
#define pi 3.14159265358979323846
#define mod 1000000007
#define rep(i, n) for (i = 0; i < n; i++)
#define repk(i, k, n) for (i = k; i < n; i++)
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
#define oset                                                                                       \
    tree<pair<ll int, ll int>, null_type, less<pair<ll int, ll int> >, rb_tree_tag,                \
        tree_order_statistics_node_update>
using namespace std;
#define see(args...)                                                                               \
    {                                                                                              \
        cerr << "LINE " << __LINE__;                                                               \
        string _s = #args;                                                                         \
        replace(_s.begin(), _s.end(), ',', ' ');                                                   \
        stringstream _ss(_s);                                                                      \
        istream_iterator<string> _it(_ss);                                                         \
        err(_it, args);                                                                            \
        cerr << endl;                                                                              \
    }
void err(istream_iterator<string> it)
{
}
template <typename T, typename... Args>
void err(istream_iterator<string> it, T a, Args... args)
{
    cerr << ' ' << *it << " = " << a;
    err(++it, args...);
}
void fastio()
{
#ifndef ONLINE_JUDGE
    // for getting input from input.txt
    freopen("input.txt", "r", stdin);
    // for writing output to output.txt
    freopen("output.txt", "w", stdout);
#endif
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
}
vector<ll> v;
bool ok(ll int n)
{
    while (n > 0)
    {
        ll int d = n % 10;
        if (d > 1)
            return false;
        n = n / 10;
    }
    return true;
}
ll int dp[1000001];
void helper()
{
    ll int i;
    rep(i, 1000001)
    {
        if (ok(i))
            v.pb(i);
    }
    rep(i, 1000001) dp[i] = 1e10;
    dp[0] = 0;
    rep(i, 1000001)
    {
        for (ll j = 0; j < v.size(); j++)
        {
            if (i - v[j] < 0)
                continue;
            dp[i] = min(dp[i], dp[i - v[j]] + 1);
        }
    }
}


void solve()
{

    ll int n, i;
    cin >> n;
    vector<ll> ans;


    // cout<<dp[n]<<endl;
    while (n > 0)
    {
        ll int c = 1e10, num;
        for (ll j = 0; j < v.size(); j++)
        {
            if (n - v[j] >= 0)
                if (dp[n - v[j]] < c)
                {
                    num = v[j];
                    c = min(c, dp[n - v[j]]);
                }
        }
        n -= num;
        // cout<<num<<endl;

        ans.pb(num);
    }
    cout << ans.size() << endl;
    rep(i, ans.size()) cout << ans[i] << ' ';
    cout << endl;
}
int main()
{
    helper();
    fastio();
    ll int t;
    // cin>>t;
    t = 1;
    while (t--)
    {
        solve();
    }
}
