﻿#include <bits/stdc++.h>
#define ll long long int
using namespace std;
int main()
{

    ll n, d;
    ll mx = 0, k = 1;
    ll ar[10] = { 0 };
    cin >> n;

    while (n)
    {
        d = n % 10;
        mx = max(mx, d);

        for (ll i = 0; i < d; i++)
        {
            ar[i] += k;
        }

        k *= 10;
        n /= 10;
    }


    cout << mx << endl;
    for (ll i = 0; i < mx; i++)
    {
        cout << ar[i] << " ";
    }
    cout << endl;
    return 0;
}
