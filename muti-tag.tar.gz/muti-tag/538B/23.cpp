﻿#include <bits/stdc++.h>
using namespace std;
#define R register
typedef long long ll;
const int MAXN = 10;
int dp[MAXN];
int main()
{
    int n;
    scanf("%d", &n);
    int cnt = 0;
    int maxn = 0;
    while (n)
    {
        dp[++cnt] = n % 10;
        maxn = max(maxn, dp[cnt]);
        n /= 10;
    }
    printf("%d\n", maxn);
    int ans = 0;
    while (1)
    {
        bool flag = true;
        int k = 1;
        int now = 0;
        for (R int i = 1; i <= cnt; i++)
        {
            if (dp[i] != 0)
            {
                now += k;
                flag = false;
            }
            k = k * 10;
        }
        for (R int i = 1; i <= cnt; i++)
            if (dp[i] != 0)
                dp[i]--;
        if (flag)
            break;
        printf("%d ", now);
    }
    return 0;
}