﻿#include <bits/stdc++.h>
using namespace std;

#define kuramaa ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0)
#define ll long long
#define pb push_back
#define ins insert
#define pf push_front
#define r return
#define br break
#define len length()
#define ndl cout << "\n"
#define cyes cout << "YES\n"
#define cno cout << "NO\n"
#define cn cout << "Naruto\n"
#define M 1000000007

vector<ll> dp(10000005);


ll gcd(ll a, ll b)
{
    if (b == 0)
        r a;
    else
        r gcd(b, a % b);
}

bool check_prime(ll n)
{
    if (n < 2)
        r false;
    if (n < 4)
        r true;
    if (n % 2 == 0 || n % 3 == 0)
        r false;

    for (ll i = 5; i * i <= n; i += 6)
    {
        if (n % i == 0 || n % (i + 2) == 0)
            r false;
    }

    r true;
}

bool check_pwr(ll n)
{
    double f = log2((n)*1.0);
    ll f1 = log2(n);

    r(f == f1);
}

ll resolve(string s)
{
    ll i;
    for (i = 0; i < s.len; i++)
        if (s[i] >= '1')
            s[i] = '1';

    r(stoi(s));
}


void solve()
{
    ll n, i, m, tmp;
    cin >> n;
    vector<ll> arr;

    while (n > 0)
    {
        m = resolve(to_string(n));
        arr.pb(m);
        n -= m;
    }

    cout << arr.size() << endl;
    for (auto a : arr)
        cout << a << " ";
}

int main()
{
    kuramaa;
    int t = 1;
    while (t--)
        solve();
    r 0;
}