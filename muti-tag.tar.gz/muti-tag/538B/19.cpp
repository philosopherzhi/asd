﻿#include <bits/stdc++.h>

using namespace std;

#define fastio                                                                                     \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(NULL);
#define ifs freopen("aa.in", "r", stdin);
#define ofs freopen("aa.out", "w", stdout);
#define iof ifs ofs
#define ll long long
#define ld long double
#define da(x, i) cout << #x << "[" << i << "]=" << x[i] << "\n";
#define da2(x, i, y, j)                                                                            \
    cout << #x << "[" << i << "]=" << x[i] << " ! " << #y << "[" << j << "]=" << y[j] << "\n";
#define d2a(x, i, j) cout << #x << "[" << i << "][" << j << "]=" << x[i][j] << "\n";
#define db(x) cout << #x << "=" << (x) << "\n";
#define db2(x, y) cout << #x << "=" << (x) << " ! " << #y << "=" << (y) << "\n";
#define db3(x, y, z)                                                                               \
    cout << #x << "=" << (x) << " ! " << #y << "=" << (y) << " ! " << #z << "=" << (z) << "\n";
#define db4(w, x, y, z)                                                                            \
    cout << #w << "=" << (w) << " ! " << #x << "=" << (x) << " ! " << #y << "=" << (y) << " ! "    \
         << #z << "=" << (z) << "\n";
#define inf LLONG_MAX
#define fr first
#define sc second
#define all(a) a.begin(), a.end()


const ll N = 11e5 + 7;
ll n, ok = 1, i, j;
vector<ll> v, V, q, f(N, inf), p(N);

bool chk(ll i)
{
    for (; i; i /= 10)
        if (i % 10 > 1)
            return 0;
    return 1;
}

int main()
{
    for (i = 1; i < N; i++)
        if (chk(i))
            q.push_back(i);
    cin >> n;
    f[0] = 0;
    for (i = 1; i <= n; i++)
    {
        for (j = 0; q[j] <= i; j++)
        {
            if (f[i - q[j]] + 1 < f[i])
            {
                f[i] = f[i - q[j]] + 1;
                p[i] = i - q[j];
            }
        }
    }
    cout << f[n] << "\n";
    for (i = n; i; i = p[i])
        cout << i - p[i] << " ";
    cout << "\n";
}
