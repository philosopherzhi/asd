﻿// Qul-hu Allah-hu Ahad
#include <bits/stdc++.h>
#define ll long long
#define clr(a, x) memset(a, x, sizeof a);
#define rev(a) reverse(a.begin(), a.end())
#define pb push_back
#define em emplace_back
#define lb lower_bound
#define ub upper_bound
#define mp make_pair
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define pll pair<ll, ll>
#define endl "\n"
#define fast()                                                                                     \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie();                                                                                     \
    cout.tie();
#define time()                                                                                     \
    cerr << endl << "time taken : " << (float)clock() / CLOCKS_PER_SEC << " secs" << endl;
// const int fx[]= {+1,-1,+0,+0};
// const int fy[]= {+0,+0,+1,-1};
// const int fx[]={+0,+0,+1,-1,-1,+1,-1,+1};   // Kings Move
// const int fy[]={-1,+1,+0,+0,+1,+1,-1,-1};  // Kings Move
// const int fx[]={-2, -2, -1, -1,  1,  1,  2,  2};  // Knights Move
// const int fy[]={-1,  1, -2,  2, -2,  2, -1,  1}; // Knights Move
using namespace std;
ll getValue(string s)
{
    ll temp = 0;
    for (auto& c : s)
        temp = temp * 10 + (c - '0');
    return temp;
}
void solve()
{
    ll n;
    cin >> n;
    set<string, greater<string>> s;
    for (ll len = 1; len <= 7; len++)
    {
        for (ll i = 0; i <= len; i++)
        {
            string temp = string(i, '0') + string(len - i, '1');
            do
            {
                s.insert(temp);
            } while (next_permutation(all(temp)));
        }
    }
    set<ll, greater<ll>> d;
    for (auto& it : s)
    {
        d.insert(getValue(it));
    }
    auto it = s.end();
    it--;
    s.erase(it);
    vector<ll> v;
    while (n)
    {
        if (n < *d.begin())
        {
            d.erase(d.begin());
            continue;
        }
        string temp1 = to_string(n);
        string temp2 = to_string(*d.begin());
        for (ll i = 0; i < temp2.size(); i++)
        {
            if (temp1[i] == '0' and temp2[i] != '0')
            {
                d.erase(d.begin());
                goto label;
            }
        }
        n -= *d.begin();
        v.push_back(*d.begin());
    label:;
    }
    cout << v.size() << endl;
    for (auto i : v)
        cout << i << " ";
    cout << endl;
}

int main()
{
    fast();
    cout.precision(10);
    cout << fixed;
    int kse = 1;
    //    cin >> kse;
    while (kse--)
    {
        solve();
    }
}