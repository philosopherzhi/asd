﻿#include <bits/stdc++.h>
#include <iostream>
#include <vector>
#define pii pair<int, int>
#define ps(x, y) fixed << setprecision(y) << x
#define pb push_back
#define loopi(mp) for (auto i = mp.begin(); i != mp.end(); i++)
#define ff first
#define ss second
#define rep(i, k, n) for (int i = k; i < n; i++)
typedef long long ll;

using namespace std;
const ll mx = (1e5) + 1;
const ll mod = 1000000007;

int32_t main()
{
    int n;
    cin >> n;
    vector<int> v;
    v.clear();
    while (n > 0)
    {
        int temp = n, m = 0, p = 1;
        while (temp)
        {
            int r = temp % 10;
            temp /= 10;
            if (r != 0)
            {
                m += p;
            }
            p *= 10;
        }
        v.pb(m);
        n -= m;
    }
    cout << v.size() << endl;
    for (int i = 0; i < v.size(); i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
    return 0;
}