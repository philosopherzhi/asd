﻿#include <bits/stdc++.h>
#define ll long long
#define pb push_back
#define mp make_pair
#define all(p) p.begin(), p.end()
#define test(t)                                                                                    \
    int t;                                                                                         \
    cin >> t;                                                                                      \
    while (t--)
using namespace std;
#define IOS                                                                                        \
    ios::sync_with_stdio(0);                                                                       \
    cin.tie(0);                                                                                    \
    cout.tie(0);
#define mod 1000000007
#define MAXN 1000006
#define pii pair<ll, ll>
#define F first
#define S second
signed main()
{
    IOS ll n;
    cin >> n;
    ll temp = n;
    ll max_dig = -1;
    ll cnt = 0;
    while (temp > 0)
    {
        max_dig = max(max_dig, temp % 10);
        temp /= 10;
        cnt++;
    }
    ll mat[max_dig + 1][cnt + 1];
    for (int i = 1; i <= max_dig; i++)
    {
        for (int j = 1; j <= cnt; j++)
            mat[i][j] = 0;
    }
    int i, j = cnt;
    while (n > 0)
    {
        ll val = n % 10;
        i = 1;
        while (val > 0)
        {
            mat[i++][j] = 1;
            val -= 1;
        }
        j--;
        n /= 10;
    }
    cout << max_dig << "\n";
    ll flag = 0;
    for (int i = 1; i <= max_dig; i++)
    {
        flag = 0;
        for (int j = 1; j <= cnt; j++)
        {
            if (mat[i][j] == 0 && flag == 0)
                continue;
            else if (mat[i][j] != 0)
                flag = 1;
            if (flag)
                cout << mat[i][j];
        }
        cout << " ";
    }
    cout << "\n";
    return 0;
}