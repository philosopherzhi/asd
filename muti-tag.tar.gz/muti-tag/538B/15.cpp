﻿#include <bits/stdc++.h>
using namespace std;
const int N = 1e6 + 6;
int n;
vector<int> v[8];
int soma;
int num;
int b;
vector<int> vs;

int main()
{
    int a;
    scanf(" %d", &n);
    b = n;

    while (b > 0)
    {
        a = floor(log10(b));
        v[a].push_back(pow(10, a));
        b = b - pow(10, a);
    }
    while (1)
    {
        for (int i = 0; i < 7; i++)
        {
            if (v[i].size() > 0)
            {
                soma = soma + v[i][0];
                v[i].pop_back();
            }
        }
        num = num + soma;
        vs.push_back(soma);
        soma = 0;
        if (num == n)
            break;
    }
    printf("%d\n", vs.size());
    for (int i = 0; i < vs.size(); i++)
    {
        printf("%d ", vs[i]);
    }
}