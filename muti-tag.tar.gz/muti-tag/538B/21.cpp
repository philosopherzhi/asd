﻿#include <bits/stdc++.h>
using namespace std;
#define int long long

const int inf = 1e18 + 9;
const int mod = 1e9 + 7;
const int maxn = 2e5 + 8;

int n, m, a[8];

void solve()
{
    int i = 7, j, mx = 0;
    cin >> n;
    vector<int> vi[12];
    while (n)
        a[i--] = n % 10, n /= 10;
    for (i = 1; i <= 7; i++)
        mx = max(mx, a[i]);
    for (i = 1; i <= mx; i++)
    {
        int flag = 0;
        for (j = 1; j <= 7; j++)
        {
            if (a[j])
                flag = 1, a[j]--, vi[i].push_back(1);
            else if (flag)
                vi[i].push_back(0);
        }
    }
    cout << mx << endl;
    for (i = 1; i <= mx; i++)
    {
        for (auto x : vi[i])
            cout << x;
        if (i != mx)
            cout << " ";
    }
    cout << endl;
}

signed main()
{
    ios_base::sync_with_stdio(false), cin.tie(0), cout.tie(0); // cout.precision(2);
    int t = 1; // cin >> t;
    while (t--)
        solve();
    return 0;
}
