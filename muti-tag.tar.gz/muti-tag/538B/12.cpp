﻿#include <bits/stdc++.h>

#define nl "\n"
#define io                                                                                         \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(NULL);
#define ll long long
const int MAX = 1e6;
using namespace std;


void solve()
{
    int g[10];
    for (int i = 0; i < 10; i++)
        g[i] = 0;
    int t = 1;
    int m = 0;
    int a;
    cin >> a;
    int b;
    while (a)
    {
        b = a % 10;
        for (int i = 9; i > 9 - b; i--)
            g[i] += t;
        if (b > m)
            m = b;
        t *= 10;
        a /= 10;
    }
    cout << m << nl;
    for (int i = 0; i < 10; i++)
        if (g[i])
            cout << g[i] << " ";
}

int main()
{
    io;
#ifdef LOCAL42
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    //    int t;cin>>t;
    //    while (t--)
    solve();
    return 0;
}
