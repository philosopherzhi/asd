﻿#include <bits/stdc++.h>
using namespace std;
int a[10], n, ans[12];

int main()
{
    int x, mx = 0;
    scanf("%d", &x);
    while (x)
        a[++n] = x % 10, x /= 10;
    for (int i = 1; i <= n; i++)
        mx = max(mx, a[i]);
    printf("%d\n", mx);
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= a[i]; j++)
            ans[j] += pow(10, i - 1);
    for (int i = 1; i <= mx; i++)
        printf("%d ", ans[i]);
    return 0;
}