﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
#define f first
#define s second
#define all(v) (v).begin(), (v).end()
#define rall(v) (v).rbegin(), (v).rend()

const int inf = 1e9;
const ll infll = 1e18;
const int M = 1000000007;
const int N = 200;

void testCase()
{
    int n;
    scanf("%d", &n);
    vector<int> ans;
    int cnt = 1;
    while (n)
    {
        int d = n % 10;
        n /= 10;
        for (int i = 0; i < d; ++i)
        {
            if (i == ans.size())
                ans.pb(cnt);
            else
                ans[i] += cnt;
        }
        cnt *= 10;
    }
    printf("%d\n", ans.size());
    for (auto x : ans)
        printf("%d ", x);
    puts("");
}
int main()
{
    int T = 1;
    // scanf("%d", &T);
    while (T--)
    {
        testCase();
    }
}