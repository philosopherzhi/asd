﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin >> n;
    int n1 = n;
    int mx = INT_MIN;
    while (n1)
    {
        mx = max(mx, n1 % 10);
        n1 /= 10;
    }
    cout << mx << endl;
    vector<int> v;
    while (n)
    {
        int n1 = n;
        int k = 0, c = 1;
        while (n1)
        {
            int r = n1 % 10;
            n1 /= 10;
            if (r == 0)
            {
                c *= 10;
                ;
                continue;
            }
            k = 1 * c + k;
            c *= 10;
        }
        // cout<<"1" ;
        n -= k;
        v.push_back(k);
    }
    for (int i = 0; i < v.size(); i++)
        cout << v[i] << " ";
}