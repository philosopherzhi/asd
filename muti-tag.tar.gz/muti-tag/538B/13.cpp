﻿#include <iostream>
#include <algorithm>
#include <vector>
#include <math.h>
#include <string>
#include <string.h>
#include <array>
#include <list>
#include <iomanip>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <cstring>
#include <utility>
#include <set>
#include <cstdio>
#include <climits>
#include <sstream>
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define pf push_front
#define in insert
#define all(v) v.begin(), v.end()
#define infinity (1 << 30)
#define fast                                                                                       \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0);                                                                                    \
    cout.tie(0)
typedef long long ll;
typedef double lf;
typedef unsigned long long ull;

using namespace std;
/*freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);*/

void test()
{
    ll i, t, k, j, m, x, c, d, l, mina, maxa, h, w, y, p, sb, ans = 0, q, idx, val, cur, r, s, a, b,
                                                              u, n;
    {
        string s;
        cin >> s;
        vector<string> a(10);
        for (i = 0; i < 10; i++)
            a[i] = "";
        for (i = 0; i < s.size(); i++)
        {
            p = s[i] - '0';
            j = 0;
            while (p--)
            {
                a[j++] += '1';
            }
            while (j < 10)
                a[j++] += '0';
        }
        c = 0;
        for (i = 0; i < 10; i++)
        {
            if (count(all(a[i]), '0') != a[i].size())
                c++;
        }
        cout << c << endl;
        for (i = 0; i < c; i++)
        {
            // string p=a[i];
            j = 0;
            while (j < a[i].size() && a[i][j] == '0')
                j++;
            while (j < a[i].size())
                cout << a[i][j++];
            cout << " ";
        }
    }
}

// r l-1
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie();
    ll i, t, k, j, m, x, c, d, l, mina, maxa, h, w, y, p, sb, ans = 0, q, idx, val, cur, r, s, a, b,
                                                              u, n;

    t = 1;
    //  cin>>t;
    while (t--)
    {
        test();
    }
}