﻿#include <bits/stdc++.h>
using namespace std;
int d[74], zz = 1;
bool check()
{
    for (int i = zz - 1; i >= 1; i--)
    {
        if (d[i])
        {
            return true;
        }
        else
        {
            zz--;
        }
    }
    return false;
}
int tot;
int main()
{
    int n;
    cin >> n;
    while (n)
    {
        d[zz] = n % 10;
        tot = max(tot, d[zz]);
        n /= 10;
        zz++;
    }
    cout << tot << endl;
    while (check())
    {
        for (int i = zz - 1; i >= 1; i--)
        {
            if (d[i])
            {
                cout << 1;
                d[i]--;
            }
            else
            {
                cout << 0;
            }
        }
        cout << " ";
        // system("pause");
    }
}