﻿#include <set>
#include <map>
#include <queue>
#include <string>
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <math.h>
using namespace std;
typedef long long ll;
typedef pair<ll, ll> pii;
typedef unsigned long long ull;

#define x first
#define y second
#define sf scanf
#define pf printf
#define inf 0x3f3f3f3f
#define mem(a, x) memset(a, x, sizeof(a))
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repi(i, a, b) for (int i = int(a); i <= (b); ++i)
#define repr(i, b, a) for (int i = int(b); i >= (a); --i)
#define debug(x) cout << #x << ": " << x << endl;

const int MOD = 10007;
const int mod = 998244353;
const int maxn = 2e5 + 1010;
const int dx[] = { 1, 1, 1, 0, 0, -1, -1, -1 };
const int dy[] = { 1, 0, -1, -1, 1, -1, 1, 0 };

ll a[maxn], b[maxn], c[maxn];
ll ans, n, m, len, k;
string s;
void solve()
{
    a[1] = 1;
    for (int i = 2; i <= 10; i++)
    {
        a[i] = a[i - 1] * 10;
    }
    cin >> n;

    ll cnt = 0;
    while (n)
    {
        b[++cnt] = n % 10;
        n = n / 10;
    }
    ll p = 0;
    for (int i = cnt; i >= 1; i--)
    {
        if (b[i])
        {
            while (b[i])
            {
                ++p;
                for (int j = i; j >= 1; j--)
                {
                    if (b[j])
                    {
                        b[j]--;
                        c[p] += a[j];
                    }
                }
            }
        }
    }
    cout << p << endl;
    for (int i = 1; i <= p; i++)
    {
        cout << c[i] << " ";
    }
}

int main()
{
    solve();
    return 0;
}