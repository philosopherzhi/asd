﻿#include <bits/stdc++.h>
using namespace std;
const int N = 1e6 + 5;
char ch[N];
vector<int> ans;
int main()
{
    scanf("%s", ch + 1);
    int len = strlen(ch + 1);
    while (1)
    {
        int s = 0;
        for (int i = 1; i <= len; i++)
        {
            s *= 10;
            if (ch[i] > '0')
            {
                s++;
                ch[i]--;
            }
        }
        if (!s)
            break;
        ans.push_back(s);
    }
    printf("%d\n", ans.size());
    for (int i = 0; i < ans.size(); i++)
        printf("%d ", ans[i]);
}