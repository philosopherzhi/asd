﻿#include <bits/stdc++.h>

using namespace std;

#define endl "\n"
#define pb push_back

typedef long long ll;


void test_case()
{

    int n;
    cin >> n;
    vector<int> a;
    while (n)
    {
        int N = n, m = 0, p = 1;
        while (N)
        {
            if (N % 10)
                m += p;
            N /= 10, p *= 10;
        }
        a.pb(m);
        n -= m;
    }
    cout << a.size() << endl;
    sort(a.begin(), a.end());
    for (int i = 0; i < a.size(); i++)
    {
        cout << a[i] << " ";
    }
    cout << endl;
}


int main()
{

    int t = 1;
    // cin>>t;
    for (int i = 0; i < t; i++)
    {
        test_case();
    }
}
