﻿#include <bits/stdc++.h>
#define lli int
#define loop(i, x, n) for (lli i = x; i < n; i++)
#define primeloop(i, x, n) for (lli i = x; i * i <= n; i++)
#define loopr(i, x, n) for (lli i = n - 1; i >= x; i--)
#define st set<lli>
#define ve vector<lli>
#define um unordered_map<lli, lli>
#define vpl vector<pair<lli, lli> >
#define llu long long unsigned
#define ms multiset<lli>
#define ums unordered_map<string, lli>
#define pb push_back
#define time                                                                                       \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(NULL);                                                                                 \
    cout.tie(NULL);                                                                                \
    cout.setf(ios::fixed);                                                                         \
    cout.setf(ios::showpoint);
#define test                                                                                       \
    lli t;                                                                                         \
    cin >> t;                                                                                      \
    while (t--)
#define mod 1000000007
using namespace std;
int main()
{
    time
    // test
    {
        lli n;
        cin >> n;
        lli a[9] = { 0 };
        string s = to_string(n);
        n = s.size();
        lli maxi = 0;
        loop(i, 0, n)
        {
            lli cur = s[i] - '0';
            maxi = max(maxi, cur);
            loop(j, 0, cur) a[j] *= 10, a[j]++;
            loop(j, cur, maxi) a[j] *= 10;
        }
        vector<lli> ans;
        loop(i, 0, 9)
        {
            if (a[i])
                ans.pb(a[i]);
        }
        cout << ans.size() << endl;
        for (lli x : ans)
            cout << x << " ";
    }
    return 0;
}