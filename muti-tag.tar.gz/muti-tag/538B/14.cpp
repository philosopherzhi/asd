﻿// Author: __saanto_
// Time : 2021-03-29 14:34:17


#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define deb(x) cout << #x << "=" << x << endl
#define deb2(x, y) cout << #x << "=" << x << " , " << #y << "=" << y << endl
#define _                                                                                          \
    ios::sync_with_stdio(false);                                                                   \
    cin.tie(0);                                                                                    \
    cout.tie(0);
#define ff first
#define ss second


void solve()
{
    ll n, m, d = 0, mx = 0;
    cin >> n;
    m = n;

    while (m > 0)
    {
        mx = max(mx, m % 10);
        m /= 10;
        d++;
    }

    ll res[mx][d], pos = d - 1;

    while (n > 0 && pos >= 0)
    {
        ll x = n % 10;
        for (ll i = 0; i < mx; i++)
        {
            if (x > 0)
                res[i][pos] = 1, --x;
            else
                res[i][pos] = 0;
        }
        --pos;
        n /= 10;
    }
    cout << mx << '\n';
    for (ll i = 0; i < mx; i++)
    {
        ll num = 0;
        for (ll j = 0; j < d; j++)
        {
            num *= 10;
            num += res[i][j];
        }
        cout << num << ' ';
    }
    cout << '\n';
}


int main()
{
    _ int t = 1;

    // cin >> t;

    while (t--)
    {
        solve();
    }

    return 0;
}