﻿#include <bits/stdc++.h>
using namespace std;

#define pii pair<int, int>
#define ld long double
#define ll long long
#define mp make_pair
#define pb push_back
#define in insert
#define ers erase
#define S second
#define F first

int main()
{
    ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
    int n, ans = 0;
    cin >> n;
    string s = to_string(n);
    for (char c : s)
        ans = max(ans, c - '0');
    cout << ans << '\n';
    vector<int> v[15];
    for (char c : s)
    {
        int x = c - '0';
        for (int i = 0; i < ans; i++)
            v[i].pb(i <= x - 1 ? 1 : 0);
    }
    for (int i = 0; i < ans; i++)
    {
        int k = false;
        for (int x : v[i])
            if (x)
                k = true, cout << x;
            else if (k)
                cout << x;
        cout << ' ';
    }
    cout << '\n';
    return 0;
}
