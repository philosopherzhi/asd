﻿#include <bits/stdc++.h>
using namespace std;


int main()
{
    int n;
    cin >> n;
    vector<int> v;
    int m = 0;
    while (n > 0)
    {
        m = max(n % 10, m);
        v.push_back(n % 10);
        n /= 10;
    }
    char s[m][v.size()];
    for (int j = 0; j < v.size(); j++)
    {
        for (int i = 0; i < m; i++)
            s[i][j] = '0';
    }

    int j = 0;
    for (int i = v.size() - 1; i >= 0; i--)
    {
        int k = 0;
        while (v[i] > 0)
        {
            s[k][j] = '1';
            v[i]--;
            k++;
        }
        j++;
    }

    cout << m << endl;
    j = 0;
    while (j < m)
    {
        bool r = 0;
        for (int i = 0; i < v.size(); i++)
        {
            if (r == 1)
                cout << s[j][i];
            else if (s[j][i] != '0')
            {
                cout << s[j][i];
                r = 1;
            }
        }
        cout << " ";
        j++;
    }
}
