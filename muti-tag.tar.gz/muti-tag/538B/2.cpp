﻿//    ŦĦ€Ř€'Ş ŇØŦĦƗŇǤ ĦØŁĐƗ'Ň Μ€ βΔĆҜ ΔŁŴΔ¥Ş ΔŇĐ ₣ØŘ€V€Ř
//    😈🤩😇😈💪🤜👊🤛🤟😉🤩:

#pragma GCC optimize("Ofast")
#pragma GCC target("avx,avx2,fma")
#pragma GCC optimization("unroll-loops")

#include <bits/stdc++.h>

#define mod 1000003
#define ll long long
#define vll vector<ll>
#define vi vector<int>
#define vp vector<pair<ll, ll> >
#define vs vector<string>
#define mll map<ll, ll>
#define mi map<int, int>
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define B(a) a.begin()
#define E(a) a.end()
#define For(i, a, b) for (ll i = a; i < b; i++)
#define Forr(i, a, b) for (ll i = a; i >= b; i--)
#define Itr(it, a) for (auto it = a.begin(); it != a.end(); it++)
#define F first
#define S second
#define M_P make_pair
#define P_B push_back
#define add(x, y) P_B(M_P(x, y))
#define endd "\n"

using namespace std;

/////////////////////////////////////////////"SUIT
///YOURSELF"/////////////////////////////////////////////

vector<ll> zeus(ll n)
{
    vll a(n);

    For(i, 0, n) cin >> a[i];

    return a;
}

///////////////////////////////////////////////"ASSEMBLE"////////////////////////////////////////////////

void Shazam()
{
    ll n;
    cin >> n;
    string mid = to_string(n);
    vll ans;

    while (mid.size() != 1)
    {
        ll on = 0, ze = 0;
        ll lm = mid.size();
        string help = "";

        For(i, 0, lm)
        {
            if (mid[i] == '1')
                on++;

            else if (mid[i] == '0')
                ze++;

            if (mid[i] != '0')
                help += '1';

            else
                help += '0';
        }

        if (on + ze == lm)
        {
            ans.P_B(n);
            n = 0;
            mid = to_string(n);
            break;
        }

        ll luci = stoll(help);
        n -= luci;

        ans.P_B(luci);

        mid = to_string(n);
    }

    For(i, 0, n)
    {
        ans.P_B(1);
    }

    cout << ans.size() << endd;

    for (auto x : ans)
        cout << x << " ";

    cout << endd;
}

//////////////////////////////////////////"WHATEVER IT
///TAKES"////////////////////////////////////////////

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);

    ll t = 1;

    while (t--)
    {
        Shazam();
    }


    return 0;
}
