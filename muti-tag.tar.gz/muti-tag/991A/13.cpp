﻿#include <bits/stdc++.h>
#define int long long
using namespace std;

int32_t main()
{
    int a, b, c, n;
    cin >> a >> b >> c >> n;
    if ((a + b - c >= n) || c > a || c > b)
        cout << -1 << endl;
    else
        cout << n - (a + b - c) << endl;
}