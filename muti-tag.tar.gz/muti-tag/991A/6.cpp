﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    int a, b, c, n, x;
    cin >> a >> b >> c >> n;
    x = n - (a + b - c);
    if (a >= n || b >= n || c >= n || c > a || c > b || x <= 0 || n - x < a || n - x < b
        || n - x < c || x > n)
        cout << "-1";
    else
        cout << x;
    return 0;
}