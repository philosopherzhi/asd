﻿#include <bits/stdc++.h>
using namespace std;
typedef long long Long;

// const Long MX = ;

void solve()
{
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    cout.precision(10);
    cout << fixed;

    Long a, b, c, n;
    cin >> a >> b >> c >> n;

    Long falta = n - (a + b - c);

    if (a >= c && b >= c && falta >= 1)
    {
        cout << falta << "\n";
    }
    else
    {
        cout << -1 << "\n";
    }

    return 0;
}
