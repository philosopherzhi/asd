﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long int
int main(void)
{
    ll i, j, k, t, n, a, b, c;
    cin >> a >> b >> c >> n;
    if ((a >= c) && (b >= c))
    {
        a = a - c;
        b = b - c;
        k = n - a - b - c;
        if (k > 0)
        {
            cout << k << endl;
        }
        else
        {
            cout << -1 << endl;
        }
    }
    else
    {
        cout << -1 << endl;
    }
}