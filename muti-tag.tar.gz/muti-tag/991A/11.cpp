﻿#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n, a, b, c, ans;
    cin >> a >> b >> c >> n;
    ans = (n - (a + b - c));
    if (ans < 1 || a < c || b < c)
        ans = -1;
    cout << ans;
}