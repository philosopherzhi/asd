﻿#include <bits/stdc++.h>
using namespace std;

int main()
{
    int A, B, C, N;
    cin >> A >> B >> C >> N;

    int x = A - C + B - C + C;
    if (x < N && A >= C && B >= C)
        cout << N - x;

    else
        cout << -1;


    return 0;
}