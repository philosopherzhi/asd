﻿#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
#define m4a                                                                                        \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0);                                                                                    \
    cout.tie(0)
#define tst                                                                                        \
    ll t;                                                                                          \
    cin >> t;                                                                                      \
    while (t--)
#define endl "\n"
#define loop(i, st, en) for (ll i = st; i < en; i++)
#define loope(i, st, en) for (ll i = st; i <= en; i++)
#define rloop(i, en, st) for (ll i = en; i > st; i--)
#define rloope(i, en, st) for (ll i = en; i >= st; i--)
#define srt(a) sort(a.begin(), a.end())
#define srtg(a) sort(a.begin(), a.end(), greater<ll>())
#define rev(a) reverse(a.begin(), a.end())
#define pb push_back
const int mxvl = 1e6 + 123;
int main()
{
    ll a, b, c, d;
    cin >> a >> b >> c >> d;
    ll sm = d - (a + b - c);
    if (a - c < 0 or b - c < 0 or sm < 1)
        cout << "-1";
    else
        cout << sm;
}