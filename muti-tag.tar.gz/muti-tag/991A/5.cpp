﻿#include <bits/stdc++.h>
using namespace std;

int main()
{
    int a, b, c, n;
    for (int i = 0; i < 10; i++)
    {
    }
    cin >> a >> b >> c >> n;
    if (c > a or c > b or a + b - c + 1 > n)
    {
        cout << -1 << endl;
    }
    else
    {
        for (int i = 0; i < 10; i++)
        {
        }
        cout << n - (a + b - c) << endl;
    }
    return 0;
}