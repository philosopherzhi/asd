﻿/*

/////////////              //\\   			////////////////////   \\	       //
//    					  //  \\			//
\\        //
//						 //    \\			//
\\      //
//						//      \\			//
\\    //
//					   //        \\			//
\\  //
//					  //		  \\		//
\\//
////////////		 //////////////\\       ////////////////////    	 //
//					//				\\
//		 //
//				   //				 \\
//    	 //
//				  //				  \\
//    	 //
// 				 //					   \\
//    	 //
// 				// 						\\
//    	 //
/////////////  //						 \\  ///////////////////    	 //

*/
#include <bits/stdc++.h>
using namespace std;

typedef long long Long;
typedef long double Double;

#define F(i, a, n) for (Long i = (Long)a; i < (Long)n; i++)
#define Rep(i, n) for (Long i = 0; i < (Long)n; i++)
#define debug(x) cout << #x << " = " << x << endl;
#define pb push_back
#define pf push_front
#define FIN                                                                                        \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(NULL);                                                                                 \
    cout.tie(NULL);
#define mayor_igual lower_bound
#define mayor upper_bound

int main()
{
    FIN

        Long a,
        b, c, n;
    cin >> a >> b >> c >> n;

    // if (a == 0 && b == 0 && c == 0) cout << n << endl;
    if (a < c || b < c)
        cout << -1 << endl;
    else if (a + b - c < n)
        cout << n - (a + b - c) << endl;
    else
        cout << -1 << endl;

    return 0;
}
