﻿#include <bits/stdc++.h>
using namespace std;
int A, B, C, N;
/*int max(int a,int b, int c){
    if(a>b){
        if(a>c)return a;
        else return c;
    }
    else{
        if(b>c)return b;
        else return c;
    }
}*/
main()
{
    cin >> A >> B >> C >> N;
    A -= C;
    B -= C;
    N -= C;
    C = 0;
    N -= (A + B);
    if (N <= 0)
        cout << -1;
    else if ((A < 0) || (B < 0))
        cout << -1;
    else
        cout << N;
}