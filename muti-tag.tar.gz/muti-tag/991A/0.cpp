﻿#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <queue>
#include <map>
#include <stack>
#include <set>
#define iss ios::sync_with_stdio(false)
using namespace std;
typedef long long ll;
using namespace std;
typedef long long ll;
const int maxn = 1e6 + 7;
const int mod = 998244353;
const int rr = 233;
int a, b, c, n;
int main()
{
    cin >> a >> b >> c >> n;
    if (a + b - c >= n || c > a || c > b || a >= n || b >= n || c >= n)
    {
        printf("-1\n");
        return 0;
    }
    printf("%d\n", n - (a + b - c));
}
