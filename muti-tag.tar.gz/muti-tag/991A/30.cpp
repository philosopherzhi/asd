﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    int a, b, c, n;
    cin >> a >> b >> c >> n;
    int s;
    s = n - a - b + c;

    if (s == 0 || s < 0 || a < c || b < c)
        cout << "-1";
    else
        cout << s;
}
