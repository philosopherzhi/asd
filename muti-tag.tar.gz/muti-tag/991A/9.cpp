﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
int main()
{
    int a, b, c, n, r, d;
    cin >> a >> b >> c >> n;

    r = (a - c) + (b - c) + c;
    d = n - r;

    if (c > a || c > b)
    {
        cout << -1 << endl;
        return 0;
    }
    if (d > 0)
    {
        cout << d << endl;
    }
    else
    {
        cout << -1 << endl;
    }
    return 0;
}
