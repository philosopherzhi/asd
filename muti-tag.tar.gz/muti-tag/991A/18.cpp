﻿/*
        بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيْمِ
        أعوذُ بِٱللَّهِ مِنَ ٱلشَّيۡطَٰنِ ٱلرَّجِيمِ
        Submitted by Pooh__7__
        Author : Poorva Shinde
        Pune University, India , Pune
        created 31.03.2021
*/

#include <bits/stdc++.h>
// #include <ext/pb_ds/assoc_container.hpp>
// #include <ext/pb_ds/tree_policy.hpp>
using namespace std;
// using namespace __gnu_pbds;

#define loop(i, a, b) for (int i = (a); i < (b); i++)
#define loop_last(i, a, b) for (int i = (a); i <= (b); i++)
#define loopRev(i, b, a) for (int i = (b - 1); i >= (a); i--)
#define rl(i, arr)                                                                                 \
    for (int i : arr)                                                                              \
        cout << i;
#define rl_space(i, arr)                                                                           \
    for (int i : arr)                                                                              \
        cout << i << " ";
#define dub double
#define mod 1000000007
#define ll long long
#define MAX INT_MAX
#define inf 1e18
#define vi vector<ll>
#define vvi vector<vector<int> >
#define pb push_back
#define ump unordered_map
#define mp map
#define str string
#define sff(n, m) scanf("%d%d", &n, &m)
#define sf(n) scanf("%d", &n)
#define sfld(t) scanf("%lld", &t)
#define sfc(t) scanf("%c", &t)
#define sfs(t) scanf("%s", t)
#define pf(n) printf("%d \n", n)
#define pfld(n) printf("%lld \n", n)
#define pfc(t) printf("%c", t)
#define pfs(s) printf("%s \n", s)
#define all(a) a.begin(), a.end()
#define w(t)                                                                                       \
    int t;                                                                                         \
    cin >> t;                                                                                      \
    while (t--)

void file_i_o()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
}


int main()
{
    int a, b, c, n;
    cin >> a >> b >> c >> n;
    a -= c;
    b -= c;
    if (a < 0 or b < 0)
    {
        cout << -1 << endl;
    }
    else
    {
        n = n - (a + b + c);
        if (n <= 0)
        {
            cout << -1 << endl;
        }
        else
        {
            cout << n << endl;
        }
    }
    return 0;
}