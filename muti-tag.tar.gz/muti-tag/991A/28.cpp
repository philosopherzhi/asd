﻿#include <iostream>
using namespace std;

int main()
{
    int A, B, C, N, total;

    cin >> A >> B >> C >> N;

    total = N - ((A - C) + (B - C) + C);
    if (total <= 0 || A < C || B < C)
    {
        cout << -1;
    }
    else
    {
        cout << total;
    }

    return 0;
}