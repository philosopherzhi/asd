﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back


int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int T = 1;
    // cin>>T;
    while (T--)
    {
        ll a, b, c, n;
        cin >> a >> b >> c >> n;
        if (c <= a && c <= b && (a + b - c) >= 0 && (a + b - c) < n)
        {
            cout << (n - (a + b - c));
        }
        else
            cout << -1;
        cout << endl;
    }
    return 0;
}
