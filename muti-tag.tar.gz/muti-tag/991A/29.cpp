﻿#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define rep(i, srt, end) for (long long i = (srt); i < (long long)(end); i++)

void solve()
{
    ll a, b, c, n;
    cin >> a >> b >> c >> n;
    if (c > a || c > b || a + b - c > n - 1)
        cout << "-1\n";
    else
        cout << n - (a + b - c) << "\n";
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    solve();
    return 0;
}
