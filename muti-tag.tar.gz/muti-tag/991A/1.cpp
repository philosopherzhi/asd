﻿#include <bits/stdc++.h>
#define debug(x) cout << #x << " = " << x << endl
#define REP(i, n) for (Long i = 0; i < (Long)n; i++)
using namespace std;

typedef long long Long;

void solve()
{
    Long a, b, c, n;
    cin >> a >> b >> c >> n;
    Long x = n - a - b + c;
    if (x > n || x <= 0 || a > n || b > n || c > n || c > a || c > b)
    {
        cout << "-1\n";
    }
    else
    {
        cout << x << "\n";
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    Long T = 1;
    REP(t, T)
    {
        solve();
    }

    return 0;
}
