﻿#include <iostream>
#include <cstring>
#include <cstdio>

using namespace std;

int main(int argc, char* argv[])
{
    int A, B, C, N;
    scanf("%d %d %d %d", &A, &B, &C, &N);
    if (A < C || B < C)
        cout << -1;
    else
    {
        if (A + B - C >= N)
            cout << -1;
        else
            cout << N - (A + B - C);
    }
    // system("pause");
    return 0;
}