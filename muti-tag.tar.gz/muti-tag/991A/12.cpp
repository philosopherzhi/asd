﻿#include <bits/stdc++.h>
#define setIO                                                                                      \
    ios::sync_with_stdio(0);                                                                       \
    cin.tie(0);                                                                                    \
    cout.tie(0);
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<string, int> psi;
typedef pair<long long, long long> pll;
typedef pair<char, int> pci;
typedef pair<int, char> pic;
typedef pair<double, double> pdd;
typedef pair<int, string> pis;
int main()
{
    setIO;
    // freopen("input.txt", "r", stdin);freopen("output.txt", "w", stdout);
    int a, b, c, d;
    cin >> a >> b >> c >> d;
    int A = a - c, B = b - c, C = c, D = d - A - B - C;
    if (A >= 0 && B >= 0 && C >= 0 && D > 0)
    {
        cout << D;
    }
    else
        cout << -1;
}