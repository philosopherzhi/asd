﻿#include <iostream>
using namespace std;
// A人访问Bug，B人访问Beaver，C人都访问
int main()
{
    int A, B, C, N;
    cin >> A >> B >> C >> N;
    if (C > min(A, B))
        return cout << -1, 0;
    if (N - (A + B - C) < 1)
        return cout << -1, 0;
    cout << N - (A + B - C);
    return 0;
}
