﻿#include <bits/stdc++.h>
#include <iostream>
#include <vector>
#define pii pair<int, int>
#define ps(x, y) fixed << setprecision(y) << x
#define pb push_back
#define loopi(mp) for (auto i = mp.begin(); i != mp.end(); i++)
#define ff first
#define ss second
#define rep(i, k, n) for (int i = k; i < n; i++)
typedef long long ll;

using namespace std;
const int mx = 1e5 + 5;

int32_t main()
{
    int a, b, c, n;
    cin >> a >> b >> c >> n;
    int sum = (a + b) - c;
    if (sum >= n || a < c || b < c)
    {
        cout << -1 << endl;
        return 0;
    }
    else
    {
        cout << n - sum << endl;
    }
    return 0;
}