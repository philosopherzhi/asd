﻿#include <iostream>
#include <bits/stdc++.h>
using namespace std;


int main()
{
    int a, b, c, n;
    cin >> a >> b >> c >> n;
    if (a < c || b < c)
    {
        cout << -1 << "\n";
    }
    else if ((a + b - c) >= n)
    {
        cout << -1 << "\n";
    }
    else
    {
        cout << n - (a + b - c) << "\n";
    }
    return 0;
}
