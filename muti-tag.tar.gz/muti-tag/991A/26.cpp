﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define endl "\n"
#define mod 1000000007


int main()
{
#ifndef ONLINE_JUDGE
    // for getting input from input.txt
    freopen("input.txt", "r", stdin);
    // for writing output to output.txt
    freopen("output.txt", "w", stdout);
#endif
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    ll a, b, c, n;
    cin >> a >> b >> c >> n;
    ll v = a + b - c;
    if (v >= n || c > a || c > b)
        cout << "-1" << endl;
    else
        cout << n - v << endl;
    return 0;
}