﻿#include <bits/stdc++.h>
#define PI 3.141592653589793238462
#define eps 1e-20
using namespace std;
typedef long long ll;
typedef long double db;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef pair<db, db> pdd;
int main()
{
    ll a, b, c, n;
    cin >> a >> b >> c >> n;
    ll d = n - (a + b - c);
    if (a + b < c || a < c || b < c)
    {
        cout << -1 << endl;
        return 0;
    }
    if (d >= 1 && d <= n)
        cout << d << endl;
    else
        cout << -1 << endl;
}
