﻿#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main()
{

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int a, b, c, n;
    cin >> a >> b >> c >> n;

    bool truth = true;
    if (n < a or n < b or n < c or c > (a + b))
        truth = false;
    if (a < c or b < c)
        truth = false;
    if (n - (a + b - c) < 1)
        truth = false;
    if ((a == 0 or b == 0) and c != 0)
        truth = false;


    if (truth)
        cout << n - (a + b - c) << endl;
    else
        cout << -1 << endl;

    return 0;
}


/*


    */
