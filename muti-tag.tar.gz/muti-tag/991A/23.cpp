﻿#include <bits/stdc++.h>
#define fi first
#define se second
#define debug cout << "I AM HERE" << endl;
using namespace std;
typedef long long ll;
const int maxn = 1e5 + 5, inf = 0x3f3f3f3f, mod = 1e9 + 7;
const double eps = 1e-6;
typedef pair<int, int> pii;
const ll INF = 0x3f3f3f3f3f3f3f3f;
int a, b, c, n;
signed main()
{
    scanf("%d%d%d%d", &a, &b, &c, &n);
    int ans1 = c;
    int ans2 = a - c;
    int ans3 = b - c;
    if (ans2 < 0 || ans3 < 0 || n - ans1 - ans2 - ans3 <= 0)
    {
        printf("-1");
    }
    else
    {
        printf("%d", n - ans1 - ans2 - ans3);
    }

    return 0;
}
