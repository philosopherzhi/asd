﻿//			തഥാസ്തു

/**********************************************
           O         O
                O   O   O
                 OOOOOOO

         OOOOO
        O 	  O  OOOOO
                  O	O	  O
          OOOOO O     O
                  O
        O	  O
     OOOOO

**********************************************/

#include <bits/stdc++.h>

using namespace std;
using ll = long long;

#define endl "\n"
#define deb(x) cout << #x << " : " << x << "\n";
#define ar array

const ll Mxn = 1e5;
const ll MOD = 1e9 + 7;

vector<ar<ll, 2>> g[Mxn];
ll d[Mxn];
ll dp[1000][1000];

bool comp(string a, string b)
{
    return a.size() < b.size();
}

ll mp(ll a, ll b)
{
    ll res = 1;
    a %= MOD;

    while (b)
    {
        if (b & 1)
            res = res * a % MOD;
        a = a * a % MOD;
        b >>= 1;
        //(res);
    }
    return res % MOD;
}

bool prime(ll x)
{
    if (x == 1)
        return false;
    if (x == 2)
        return true;
    for (ll i = 2; i * i <= x; ++i)
        if (x % i == 0)
            return false;
    return true;
}

void solve()
{
    ll n, k;
    cin >> n >> k;
    ll a[n];
    for (ll i = 0; i < n; ++i)
        cin >> a[i];
    sort(a, a + n);
    ll ans = 0;
    for (ll i = 1; i < n; ++i)
    {
        while (a[i] + a[0] <= k)
        {
            a[i] += a[0];
            ++ans;
        }
    }
    cout << ans << "\n";
}


int main()
{
#ifndef ONLINE_JUDGE
    freopen("inp.txt", "r", stdin);
    freopen("op.txt", "w", stdout);
#endif

    int t = 1, m = 1;
    cin >> t;
    while (t--)
    {
        // cout << "Case #" << m++ << ": " ;
        solve();
    }
    return 0;
}