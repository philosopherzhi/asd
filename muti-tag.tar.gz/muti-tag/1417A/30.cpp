﻿// Nikhil Jain
// DA-IICT
#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define ff first
#define ss second
#define mp make_pair
#define pb push_back
#define vll vector<ll>
#define pll pair<ll, ll>
#define vpll vector<pll>
#define all(x) (x).begin(), (x).end()
#define fast                                                                                       \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0);                                                                                    \
    cout.tie(0)
#define endl "\n"

const ll mod = 1e9 + 7;

bool sortbysec(const pair<int, int>& a, const pair<int, int>& b)
{
    return (a.second < b.second);
}

void solve()
{
    ll n, k;
    cin >> n >> k;
    vll v(n);
    for (ll i = 0; i < n; i++)
        cin >> v[i];
    sort(all(v));
    ll x = v.front();
    v.erase(v.begin());
    ll sum = 0;
    for (ll j = 0; j < v.size(); j++)
        sum += (k - v[j]) / x;
    cout << sum << endl;
}

int main()
{
    fast;
    ll t;
    cin >> t;
    while (t--)
    {
        solve();
    }
    return 0;
}