﻿#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <vector>
#include <set>
#include <queue>
#include <stack>
#define pi acos(-1);
#define IOS                                                                                        \
    cin.tie(0);                                                                                    \
    cout.tie(0);                                                                                   \
    ios::sync_with_stdio(false);

using namespace std;
typedef long long ll;
const int N = 1010;
int a[N];

int main()
{
    IOS

        int t;
    cin >> t;
    while (t--)
    {
        int n, k;
        cin >> n >> k;
        for (int i = 0; i < n; i++)
            cin >> a[i];
        sort(a, a + n);
        int ans = 0;
        for (int i = 1; i < n; i++)
        {
            ans += (k - a[i]) / a[0];
        }
        cout << ans << endl;
    }

    return 0;
}
