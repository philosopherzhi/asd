﻿#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod = 1e9 + 7;
#define all(x) (x).begin(), (x).end()
#define fr first
#define sc second
#define nl "\n"

void solve()
{

    int n, k;
    cin >> n >> k;
    vector<int> a(n);
    for (int i = 0; i < n; i++)
        cin >> a[i];
    sort(all(a));
    ll ans = 0;
    for (int i = 1; i < n; i++)
    {
        if (a[i] >= k)
        {
            break;
            if (a[i] == k || (i != 1 && (k - a[i - 1]) % a[0] != 0))
                ans++;
        }
        ans += (k - a[i]) / a[0];
    }
    cout << ans << nl;
}

int main()
{

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);


    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }

    return 0;
}
