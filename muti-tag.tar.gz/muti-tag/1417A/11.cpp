﻿#include <bits/stdc++.h>

using namespace std;

using ll = long long;

#define all(x) begin(x), end(x)
#define fillc(p, t, v) fill_n((t*)p, sizeof(p) / sizeof(t), v)
#define pb push_back

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    for (int cid = 1; cid <= T; cid++)
    {
        int n, k;
        cin >> n >> k;
        vector<int> p(n);
        for (int i = 0; i < n; i++)
            cin >> p[i];
        vector<int> Q;
        int j = min_element(all(p)) - p.begin();
        for (int i = 0; i < n; i++)
            if (i != j)
                Q.pb(k - p[i]);
        ll ans = 0;
        for (int w : Q)
            ans += w / p[j];
        cout << ans << '\n';
    }
    return 0;
}
