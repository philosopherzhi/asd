﻿/************************************************************
            *            ***       ***     *         *                  *
            *            *   *   *   *     *         *                  *
            *            *     *     *     ***********                  *
            *            *           *     ***********                  *
            *            *           *  ** *         *                  *
            *            *           *  ** *         *                  *
            ************************************************************/

/*---------------------------------------MEHEDI----------------------------------------*/

#include <bits/stdc++.h>
#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, k, ans = 0;
        cin >> n >> k;
        int a[n];
        for (int i = 0; i < n; i++)
        {
            cin >> a[i];
        }
        int i;
        sort(a, a + n);
        for (i = 1; i < n; i++)
        {
            if (a[i] >= k)
            {
                continue;
            }
            else
            {
                ans = ans + (k - a[i]) / a[0];
            }
        }
        cout << ans << endl;
    }
    return 0;
}