﻿#include <iostream>
#include <algorithm>
#include <cmath>
#include <string>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, k;
        cin >> n >> k;
        int a[n];
        for (int i = 0; i < n; i++)
        {
            cin >> a[i];
        }
        int cnt = 0;
        sort(a, a + n, greater<int>());
        for (int i = 0; i < n - 1; i++)
        {
            int sum = a[i];
            if (a[i] + a[n - 1] > k)
                continue;
            while (sum <= k && i < n - 1)
            {
                sum += a[n - 1];
                cnt++;
            }
            cnt--;
        }
        cout << cnt << "\n";
    }
}