﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long int
int main()
{
    ll t, n, k, i, j;
    cin >> t;
    while (t--)
    {
        cin >> n >> k;
        int a[n + 1];
        ll mi = INT_MAX;
        for (i = 1; i <= n; i++)
        {
            cin >> a[i];
        }
        sort(a + 1, a + (n + 1));
        ll ans = 0;
        for (i = 2; i <= n; i++)
        {
            ll z = k - a[i];
            ans = ans + z / a[1];
        }
        cout << ans << endl;
    }
}