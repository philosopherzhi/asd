﻿#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main()
{
    int T;
    cin >> T;
    while (T--)
    {
        int n, m;
        cin >> n >> m;
        vector<int> a(n);
        int num = INT_MAX, spa;
        for (int i = 0; i < n; i++)
        {
            cin >> a[i];
            if (a[i] < num)
                num = a[i], spa = i;
        }
        int res = 0;
        for (int i = 0; i < n; i++)
        {
            if (i == spa)
                continue;
            res += (m - a[i]) / num;
        }
        cout << res << endl;
    }
    return 0;
}