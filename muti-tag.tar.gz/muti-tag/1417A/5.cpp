﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    ll t;
    cin >> t;
    while (t--)
    {
        ll n, c = 0, k, sum = 0, mina = INT_MAX, maxa = INT_MIN;
        cin >> n >> k;
        ll a[n];
        map<ll, ll> mp;
        vector<ll> vec;
        for (ll i = 0; i < n; i++)
            cin >> a[i];
        sort(a, a + n);
        mina = a[0];
        for (ll i = 1; i < n; i++)
            sum += (k - a[i]) / mina;
        cout << sum << endl;
    }
    return 0;
}