﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define loopf(i, a, b) for (ll i = a; i < b; i++)
#define loopb(i, a, b) for (ll i = a; i > b; i--)
#define pb push_back
#define fast                                                                                       \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(NULL);
#define ff first
#define ss second
#define vc vector
#define pii pair<int, int>
#define pll pair<ll, ll>
// General defs
#define umap unordered_map
#define uset unordered_set
// Along with data types
#define mapii map<int, int>
#define mapll map<ll, ll>
#define seti set<int>
#define setll set<ll>
#define umapii unordered_map<int, int>
#define useti unordered_set<int>
#define umapll unordered_map<ll, ll>
#define usetll unordered_set<ll>
#define all(x) x.begin(), x.end()
#define endl "\n"
#define ld long double
const ll M = 1e9 + 7;
bool comparator(pair<ll, ll> a, pair<ll, ll> b)
{
    if (a.ss - a.ff < b.ss - b.ff)
        return 1;
    else
        return 0;
}
void solve()
{
    int n, k;
    cin >> n >> k;
    int a[n];
    loopf(i, 0, n) cin >> a[i];
    sort(a, a + n);
    ll ans = 0;
    loopf(i, 1, n) ans += (k - a[i]) / a[0];
    cout << ans << endl;
}

int main()
{
    fast int t = 1;
    cin >> t;
    // int cnt=t;
    while (t--)
        solve();
}