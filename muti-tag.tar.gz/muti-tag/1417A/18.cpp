﻿#include <stdio.h>
#include <stdlib.h>
int cmp(const void* a, const void* b)
{
    return *(int*)a - *(int*)b;
}
int main()
{
    int t, n, k;
    scanf("%d", &t);
    while (t--)
    {
        scanf("%d%d", &n, &k);
        int candy[n], ans = 0;
        for (int i = 0; i < n; i++)
            scanf("%d", &candy[i]);
        qsort(candy, n, 4, cmp);
        for (int i = n - 1; i >= 1; i--)
            ans += (k - candy[i]) / candy[0];
        printf("%d\n", ans);
    }
    return 0;
}
