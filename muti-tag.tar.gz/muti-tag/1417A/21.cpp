﻿#include <algorithm>
#include <iostream>
using namespace std;
using ll = long long;

inline int ceildiv(int n, int d)
{
    return (n + d - 1) / d;
}

void solve()
{
    int N, K;
    cin >> N >> K;
    int a[N];
    for (int& n : a)
        cin >> n;
    sort(a, a + N);

    ll S = 0;
    for (int i = N - 1; i; --i)
        S += (K - a[i]) / a[0];
    cout << S << '\n';
}

int main()
{
    int T;
    cin >> T;
    while (T--)
        solve();
}