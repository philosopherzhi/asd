﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, k;
        cin >> n >> k;
        int arra[n + 5];
        int dp[100000] = { 0 };
        for (int i = 0; i < n; i++)
        {
            cin >> arra[i];
        }
        sort(arra, arra + n);
        int cnt = 0;
        for (int i = 1; i < n; i++)
        {
            int x = k - arra[i];
            if (x > 0)
            {
                cnt += (x / arra[0]);
            }
        }
        cout << cnt << endl;
    }
}
