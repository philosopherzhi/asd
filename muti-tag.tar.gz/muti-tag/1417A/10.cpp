﻿#pragma optimization_level 3
#pragma GCC optimize("Ofast")
#pragma GCC optimization("unroll-loops")
#include <bits/stdc++.h>

using namespace std;

#define fastio                                                                                     \
    ios::sync_with_stdio(0);                                                                       \
    cin.tie(0);                                                                                    \
    cout.tie(0);                                                                                   \
    cout << fixed;                                                                                 \
    cout << setprecision(10);
#define randomINIT mt19937 rnd(chrono::steady_clock::now().time_since_epoch().count());
#define ll long long
#define all(x) (x).begin(), (x).end()
#define rep for (ll i = 0; i < n; i++)
#define fori(a, b, c) for (ll i = a; i <= b; i = i + c)
#define pr(val) cout << val << endl

int main()
{
    ll t;
    cin >> t;
    while (t--)
    {
        ll n, k;
        cin >> n >> k;
        ll a[n], mini = INT64_MAX, ans = 0;
        rep
        {
            cin >> a[i];
        }
        sort(a, a + n);

        for (int i = 1; i < n; i++)
        {
            ans += -1 * (a[i] - k) / a[0];
        }

        pr(ans);
    }
}
