﻿#include <bits/stdc++.h>
using namespace std;
int t;
int n, k;
int a[200001], b[200001];
int mi;
int key;
int ans[200001];
int main()
{
    scanf("%d", &t);
    for (int x = 1; x <= t; x++)
    {
        ans[x] = 0;
        scanf("%d %d", &n, &k);
        for (int y = 1; y <= n; y++)
        {
            scanf("%d", &a[y]);
            b[y] = k - a[y];
        }
        mi = a[1];
        key = 1;
        for (int y = 1; y <= n; y++)
            if (mi > a[y])
            {
                mi = a[y];
                key = y;
            }
        for (int y = 1; y <= n; y++)
        {
            if (key != y)
                ans[x] += b[y] / mi;
        }
    }
    for (int x = 1; x <= t; x++)
        printf("%d\n", ans[x]);
    return 0;
}