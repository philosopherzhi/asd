﻿#include <bits/stdc++.h>

#define int long long
#define ff first
#define ss second
#define mod 1000000007
#define sz(a) (long long)((a).size())
#define pb push_back
#define all(c) c.begin(), c.end()
#define rall(c) c.rbegin(), c.rend()
#define tr(c, i) for (typeof(c).begin() i = c.begin(); i != c.end(); i++)
#define present(c, x) (c.find(x) != c.end())
#define cpresent(c, x) (find(all(c), x) != c.end())
#define fo(i, a) for (int i = 0; i < a; i++)
#define rep(i, a, b) for (int i = a; i < b; i++)
#define rev(i, a, b) for (int i = a - 1; i >= b; i--)
#define bharo(a, n) fo(i, n) cin >> a[i]
#define setd(n) fixed << setprecision(n)
using namespace std;
typedef long long ll;
typedef vector<ll> vi;
typedef vector<vi> vvi;
typedef pair<ll, ll> pii;
/////////////////////////////////////////////////Basic Temp
///Over//////////////////////////////////////////

const ll N = 0;

//////////////////////////////////////////////Dep////////////////////////////////////////////////////////


void solve()
{
    int n, k;
    cin >> n >> k;
    vi v(n);
    bharo(v, n);
    sort(all(v));
    int mi = v[0];
    int ans = 0;
    rep(i, 1, n)
    {
        int dif = k - v[i];
        ans += dif / mi;
    }
    cout << ans << "\n";
}

signed main()
{

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);


    ll t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}