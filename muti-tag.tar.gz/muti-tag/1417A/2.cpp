﻿#include <iostream>

using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, k;
        cin >> n >> k;
        int m = 1000000;
        int idx = -1, a[1005];
        for (int i = 0; i < n; ++i)
        {
            cin >> a[i];
            if (a[i] < m)
            {
                idx = i;
                m = a[i];
            }
        }
        int ans = 0;
        for (int i = 0; i < n; ++i)
        {
            if (i == idx)
                continue;
            ans += (k - a[i]) / m;
        }
        cout << ans << '\n';
    }
}