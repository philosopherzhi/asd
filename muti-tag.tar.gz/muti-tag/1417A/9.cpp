﻿#include <bits/stdc++.h>
#include <iostream>
#include <math.h>
#include <memory.h>
#include <algorithm>
using namespace std;
int main()
{
    int t;
    cin >> t;
    int n, k;
    int a[1005];

    while (t--)
    {
        cin >> n >> k;
        int f = 1;
        for (int i = 1; i <= n; i++)
            cin >> a[i];
        sort(a + 1, a + 1 + n);
        for (int i = 2; i <= n; i++)
        {
            while (a[i] + a[1] <= k)
            {
                f++;
                a[i] += a[1];
            }
        }
        cout << f - 1 << endl;
    }
    return 0;
}