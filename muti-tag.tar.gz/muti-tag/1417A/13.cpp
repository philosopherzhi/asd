﻿#include <bits/stdc++.h>
#define ll long long int
#define llu long long unsigned int
#define min3(a, b, c) min(a, min(b, c))
#define max3(a, b, c) max(a, max(b, c))
using namespace std;

int main()
{
    ll t;
    cin >> t;
    while (t--)
    {
        ll n, k;
        cin >> n >> k;
        ll a[n];
        for (ll i = 0; i < n; i++)
        {
            cin >> a[i];
        }
        sort(a, a + n);
        ll cnt = 0;
        for (ll i = 1; i < n; i++)
        {
            if (a[i] < k)
            {
                cnt = cnt + (k - a[i]) / a[0];
            }
        }
        cout << cnt << endl;
    }
    return 0;
}