﻿#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int tt;
    cin >> tt;
    while (tt--)
    {
        int n, k;
        cin >> n >> k;
        priority_queue<int, vector<int>, greater<int>> pq;
        for (int i = 1; i <= n; ++i)
        {
            int x;
            cin >> x;
            pq.push(x);
        }
        int ans = 0;
        int minn = pq.top();
        pq.pop();
        while (minn + pq.top() <= k)
        {
            int t = minn + pq.top();
            pq.pop();
            pq.push(t);
            ans++;
        }
        cout << ans << '\n';
    }
    return 0;
}
