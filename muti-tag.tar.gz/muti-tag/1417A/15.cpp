﻿#include <bits/stdc++.h>
#define ll long long
#define For(i, a, b) for (int i = a; i < b; i++)
#define rFor(i, a, b) for (int i = a; i >= b; i--)
#define mFor(it, m) for (auto it = m.begin(); it != m.end(); it++)
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, k, sum = 0;
        cin >> n >> k;
        int a[n];
        For(i, 0, n) cin >> a[i];
        sort(a, a + n);
        For(i, 1, n)
        {
            sum += (k - a[i]) / a[0];
        }
        cout << sum << "\n";
    }

    return 0;
}
