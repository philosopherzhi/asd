﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, k;
        cin >> n >> k;
        int a[n];
        for (int i = 0; i < n; i++)
            cin >> a[i];
        sort(a, a + n);
        int m = a[0];
        int ans = 0;
        for (int i = 1; i < n; i++)
            ans += (k - a[i]) / m;
        cout << ans << "\n";
    }
}
