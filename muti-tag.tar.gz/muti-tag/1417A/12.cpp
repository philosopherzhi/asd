﻿#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define FOR(n, k) for (ll f = 0; f < n; f += k)

//   Variables / declarations
ll t = 0, n = 0, m = 0, k = 0, a = 0, b = 0, c = 0, d = 0, i = 0, j = 0, x = -1, y = -2, z = -3;
ll cnt = 0, sum = 0, prod = 1, maxx = 0, minn = 0;
bool alter = false, check = false;
char sign = '+', test = '0';

//   Functions
ll fact(int i)
{
    return (i == 1) ? 1 : (i * fact(i - 1));
}
// for gcd, __gcd(m,n)  where m,n are any int but not double!!!

//   Main

main()
{
    cin >> t;
    while (t--)
    {
        cin >> n >> k;
        cnt = 0;
        ll arr[n];
        FOR(n, 1) cin >> arr[f];
        sort(arr, arr + n);
        FOR(n, 1)
        {
            if (f == 0)
                f = 1;
            while (true)
            {
                arr[f] += arr[0];
                cnt++;
                if (arr[f] > k)
                {
                    cnt--;
                    break;
                }
            }
        }
        cout << cnt << endl;
    }
}