﻿/*
 * CM 	= March
 * M 	= May
 * IM 	= July
 * GM 	= September
 * IGM	= December
*/

#include <bits/stdc++.h>

#define F first
#define S second

#define pb push_back
#define mp make_pair

typedef long long int lli;

#define pll pair<lli, lli>
#define pil pair<int, lli>
#define pli pair<lli, int>
#define pii pair<int, int>
#define pdd pair<double, double>

#define vi vector<int>
#define vl vector<lli>
#define pq priority_queue

#define end end
#define beg begin
#define lb lower_bound
#define ub upper_bound

#define dmx(x, y) x = max(x, y)
#define dmn(x, y) x = min(x, y)

using namespace std;

void setIO(string str, bool dbg)
{
    ios_base::sync_with_stdio(0);

    cin.tie(nullptr);
    cout.tie(nullptr);

    if (!dbg)
    {
        freopen((str + ".in").c_str(), "r", stdin);
        freopen((str + ".out").c_str(), "w", stdout);
    }
}

const int MAX = 5e5 + 5;
const int LEN = 1e6 + 5;
const int LVL = 2e1 + 0;
const lli MOD = 1e9 + 7;
const lli INF = 2e9;

int xyz = 1; // test cases

int n, k;

int arr[MAX];

void run()
{
    cin >> n >> k;

    for (int i = 0; i < n; i++)
        cin >> arr[i];

    sort(arr, arr + n);

    int ans = 0;
    for (int i = 1; i < n; i++)
        ans += (k - arr[i]) / arr[0];

    cout << ans << "\n";
}

int main()
{
    setIO("", 1);

    cin >> xyz;
    while (xyz--)
        run();

    return 0;
}