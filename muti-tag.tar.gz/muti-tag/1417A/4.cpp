﻿#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
#define fastio                                                                                     \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(NULL);                                                                                 \
    cout.tie(NULL);
#define pb push_back
#define mk make_pair
int main()
{
    fastio;
    ll t;
    cin >> t;
    while (t--)
    {
        ll n, i, j, k;
        cin >> n >> k;
        string s;
        vector<int> a(n);
        for (i = 0; i < n; i++)
            cin >> a[i];
        sort(a.begin(), a.end());
        ll sum = 0;
        for (i = 1; i < n; i++)
        {
            sum = sum + (k - a[i]) / a[0];
        }
        cout << sum << "\n";
    }
}
