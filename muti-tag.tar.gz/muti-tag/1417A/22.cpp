﻿#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<ll, ll> pll;
typedef pair<ll, pair<ll, ll>> plll;
#define dbg cout << "I Am Here" << endl
#define vll(v) v.begin(), v.end()
#define all(x) x.rbegin(), x.rend()
#define min3(a, b, c) min(a, min(b, c))
#define max3(a, b, c) max(a, max(b, c))
#define pb push_back
#define eb emplace_back
#define ff first
#define ss second
int main()
{


    ll t;

    cin >> t;


    while (t--)
    {
        ll n, k;

        cin >> n >> k;

        ll ara[n + 1];

        for (ll i = 0; i < n; i++)
            cin >> ara[i];


        sort(ara, ara + n);

        ll mn = ara[0], sum = 0;

        for (ll i = 1; i < n; i++)
        {
            sum += ((k - ara[i]) / mn);
        }


        cout << sum << endl;
    }
}
