﻿#include <set>
#include <map>
#include <cmath>
#include <queue>
#include <stack>
#include <stdio.h>
#include <iostream>
#include <sstream>
#include <cstring>
#include <vector>
#include <algorithm>
#include <bitset>
#include <unordered_set>
#include <unordered_map>
#define fi first
#define se second
#define pb push_back
#define fr freopen("in.txt", "r", stdin);
#define fw freopen("out.txt", "w", stdout);
#define mst0(d) memset(d, 0, sizeof d);
#define mstinf(d) memset(d, 0x3f, sizeof d);
#define IOS ios::sync_with_stdio(false), cin.tie(0), cout.tie(0)
#define dbg(x) cout << #x << " = " << (x) << endl
#define dbg2(x1, x2) cout << #x1 << " = " << x1 << "  " << #x2 << " = " << x2 << endl
#define dbg3(x1, x2, x3)                                                                           \
    cout << #x1 << " = " << x1 << "  " << #x2 << " = " << x2 << "  " << #x3 << " = " << x3 << endl
//#pragma GCC optimize(3, "Ofast", "inline")
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<double, double> pdd;
ll qpow(ll a, ll b, ll mod)
{
    ll res = 1;
    while (b)
    {
        if (b & 1)
            res = res * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return res;
}
ll inv(ll a, ll mod)
{
    return qpow(a, mod - 2, mod);
}
ll gcd(ll a, ll b)
{
    return b ? gcd(b, a % b) : a;
}
ll lcm(ll a, ll b)
{
    return a * b / gcd(a, b);
}
template <typename T>
inline void read(T& x)
{
    x = 0;
    T f = 1;
    char c = getchar();
    for (; !isdigit(c); c = getchar())
        if (c == '-')
            f = -1;
    for (; isdigit(c); c = getchar())
        x = (x << 1) + (x << 3) + (c ^ 48);
    x *= f;
}
template <typename T>
inline void write(T x)
{
    if (x < 0)
    {
        putchar('-');
        x = -x;
    }
    if (x > 9)
        write(x / 10);
    putchar(x % 10 + '0');
}
const double epx = 1e-6;
const ll inf = 0x3f3f3f3f;
const ll mod = 1e9 + 7;
const int N = 1e3 + 5, M = 3e5 + 5, S = 1e6 + 5;
ll f[N], p[N];
void solve()
{
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
        scanf("%lld", &p[i]);
    for (int i = 2; i <= n + 1; i++)
    {
        f[i] = (2 * f[i - 1] - f[p[i - 1]] + 2 + mod) % mod;
    }
    cout << f[n + 1] << endl;
}
int main()
{
    int T;
    T = 1;
    while (T--)
    {
        solve();
    }
    return 0;
}
