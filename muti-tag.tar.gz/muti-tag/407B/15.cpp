﻿#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main()
{
    ll n;
    cin >> n;
    ll p[n + 1], dp[n + 1];
    for (ll i = 1; i <= n; i++)
    {
        cin >> p[i];
    }
    for (int i = 1; i <= n; i++)
    {
        ll total_moves_back_to_i = 1;
        for (int P = p[i]; P <= i - 1; P++)
        {
            total_moves_back_to_i += (1 + dp[P]) % 1000000007;
        }
        dp[i] = (total_moves_back_to_i % 1000000007);
    }

    ll total_moves = 0;

    for (int i = 1; i <= n; i++)
        total_moves += dp[i] % 1000000007;

    total_moves = (total_moves + n) % 1000000007;

    cout << total_moves << '\n';
    return 0;
}
