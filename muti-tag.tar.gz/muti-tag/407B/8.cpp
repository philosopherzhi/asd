﻿#include <bits/stdc++.h>
#define ll long long int
#define pb push_back
#define vi vector<int>
#define vll vector<long long int>
#define vvi vector<vector<int> >
#define all(arr) arr.begin(), arr.end()
#define pii pair<int, int>

#define fast                                                                                       \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(0);                                                                                    \
    cout.tie(0)
#define file                                                                                       \
    freopen("input.txt", "r", stdin);                                                              \
    freopen("output.txt", "w", stdout)
using namespace std;
#define mod (ll)1000000007
void solve()
{
    ll n;
    cin >> n;
    ll dp[n + 1], prev[n + 1], presum[n + 1];
    memset(dp, 0, sizeof dp);
    memset(presum, 0, sizeof presum);
    for (int i = 1; i <= n; i++)
        cin >> prev[i];

    // dp[i] means steps needed to reach back to i from i tracing all prev path
    // dp[i]=sum(dp[prev[i]]+dp[prev[i]+1]....dp[i-1]+2)
    for (int i = 1; i <= n; i++)
    {
        dp[i] = (presum[i - 1] - presum[prev[i] - 1] + 2 + mod) % mod;
        presum[i] = (dp[i] + presum[i - 1]) % mod;
        // cout<<presum[i]<<" ";
    }
    cout << presum[n];
}
int main()
{
    fast;
    int t = 1;
    // cin>>t;
    while (t--)
        solve();
}