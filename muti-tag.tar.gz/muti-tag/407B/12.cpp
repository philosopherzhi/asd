﻿#include <bits/stdc++.h>
using namespace std;
const int N = 1005, mod = 1e9 + 7;
int f[N][N], s[N]; // f[x][y]表示从x到y的步数
int n;
int dp(int x, int y)
{
    int& v = f[x][y];
    if (x == y)
        return v = 1;
    if (f[x][y] != -1)
        return v;
    return v = (dp(x, y - 1) + dp(s[y - 1], y - 1) + 1) % mod;
}
int main()
{
    scanf("%d", &n);
    memset(f, -1, sizeof f);
    for (int i = 1; i <= n; i++)
        scanf("%d", &s[i]);
    cout << dp(1, n + 1) - 1 << endl;
    return 0;
}
