﻿#include <bits/stdc++.h>
const int mod = 1e9 + 7;
using namespace std;
#define int long long
#define deb(x) cout << #x << ": " << x << endl

int iceil(int a, int b)
{
    return (a + b - 1) / b;
}


signed main()
{
#ifdef strawberryshaker2005
    freopen("input.txt", "r", stdin);
#endif

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.precision(20);


    int n;
    cin >> n;
    int ar[n + 1];
    for (int i = 1; i <= n; i++)
        cin >> ar[i];

    int dp[n + 1];
    memset(dp, 0, sizeof(dp));

    for (int i = 1; i <= n; i++)
    {
        dp[i] = 1;
        for (int j = ar[i]; j <= i - 1; j++)
        {
            (dp[i] += (1 + dp[j])) %= mod;
        }
    }
    int ans = 0;
    for (int i = 1; i <= n; i++)
        (ans += dp[i]) %= mod;
    (ans += n) %= mod;
    cout << ans << endl;


    return (0);
}