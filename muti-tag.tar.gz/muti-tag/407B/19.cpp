﻿#include <bits/stdc++.h>
using namespace std;
const int N = 2e5 + 5, mod = 1e9 + 7;
int main()
{
    int n;
    cin >> n;
    int a[n];
    for (int i = 0; i < n; i++)
        cin >> a[i];
    int dp[n + 1];
    memset(dp, 0, sizeof(dp));
    for (int i = 0; i < n; i++)
    {
        dp[i] = 1;
        for (int j = a[i] - 1; j < i; j++)
        {
            dp[i] = (dp[i] + dp[j] + 1) % mod;
        }
    }
    int ans = 0;
    for (int i = 0; i < n; i++)
    {
        ans = (ans + dp[i] + 1) % mod;
    }
    cout << ans << endl;
}