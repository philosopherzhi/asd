﻿#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> pi;

const int MOD = 1000000007;

long long int dp[1005];

int main()
{
    int n;
    cin >> n;
    vector<int> p(n);
    for (int i = 0; i < n; i++)
    {
        cin >> p[i];
    }
    for (int i = 1; i <= n; i++)
    {
        dp[i + 1] = (2 * dp[i] + 2 - dp[p[i - 1]] + MOD) % MOD;
    }
    cout << dp[n + 1];
    return 0;
}