﻿
// Problem: B. Long Path
// Contest: Codeforces - Codeforces Round #239 (Div. 1)
// URL: https://codeforces.com/problemset/problem/407/B
// Memory Limit: 256 MB
// Time Limit: 1000 ms
// Powered by CP Editor (https://github.com/cpeditor/cpeditor)

#include <bits/stdc++.h>
typedef long long int ll;
#define pb push_back
#define pi 3.141592653589793238462643383279
#define int long long
#define lld long double
#define ff first
#define ss second
#define endl '\n'
#define all(x) (x).begin(), (x).end()
#define rep(i, x, y) for (int i = (int)x; i < y; i++)
#define VI vector<int>
#define VVI vector<VI>
#define pii pair<int, int>
#define ppi pair<pii, int>
#define mii map<int, int>
#define mci map<char, int>
#define miv map<int, VI>
#define mis map<int, set<int> >
#define high_functioning_sociopath                                                                 \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(NULL);                                                                                 \
    cout.tie(NULL);
using namespace std;
const unsigned int M = 998244353;
const long long mod = 1000000007;
/*_____________________________THE GAME IS ON_____________________________*/
void solve()
{
    int n;
    cin >> n;
    vector<int> v(n + 1);
    vector<int> dp(n + 1);
    for (int i = 1; i <= n; i++)
        cin >> v[i];
    dp[1] = 2;
    for (int i = 2; i <= n; i++)
    {
        dp[i] += 2;
        for (int j = v[i]; j < i; j++)
        {
            dp[i] = ((dp[i] % mod) + (dp[j] % mod)) % mod;
        }
    }
    int ans = 0;
    for (int i = 1; i <= n; i++)
        ans = ((dp[i] % mod) + (ans % mod)) % mod;
    cout << ans << endl;
}
int32_t main()
{
    high_functioning_sociopath
        // pre();
        int t
        = 1;
    // cin>>t;
    while (t--)
    {
        solve();
    }
}