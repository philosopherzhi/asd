﻿#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <climits>
#include <queue>
#include <map>
#include <list>
#include <functional>
#include <string>
#include <numeric>
#include <deque>

#define int long long

using namespace std;
int MOD = 1000000007ll;
void solve()
{
    int n;
    cin >> n;
    vector<int> P(n + 1);
    for (int i = 1; i <= n; i++)
    {
        cin >> P[i];
    }
    vector<int> dp(n + 1);
    int ans = 0;
    for (int i = 1; i <= n; i++)
    {
        int trans = 1;
        for (int j = P[i]; j <= i - 1; j++)
        {
            trans = (trans + 1ll + dp[j]) % MOD;
        }
        dp[i] = trans;
    }
    for (int i = 1; i <= n; i++)
    {
        ans = (ans + dp[i]) % MOD;
    }
    cout << (ans + n) % MOD << endl;
}

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int t = 1;
    //  cin>>t;
    while (t--)
    {
        solve();
    }
}