﻿#include <bits/stdc++.h>
using namespace std;

#define F first
#define S second
#define int long long int
#define pb push_back
#define mp make_pair
#define pii pair<int, int>
#define vi vector<int>
#define mii map<int, int>
#define pqb priority_queue<int>
#define pqs priority_queue<int, vi, greater<int> >
#define mod 1000000007
#define endl '\n'
#define rep(i, a, b) for (int i = a; i < b; i++)
void c_p_c()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
}
void solve()
{
    int n;
    cin >> n;

    int p[n + 1];
    rep(i, 0, n)
    {
        int x;
        cin >> x;
        p[i + 1] = x;
    }

    int dp[n + 3] = {};
    dp[1] = 2;
    rep(i, 1, n + 1)
    {
        dp[i + 1] = ((2 * dp[i]) % mod + 2 - dp[p[i]] + mod) % mod;
    }
    // rep(i, 1, n + 1) {
    //     cout << dp[i] << " ";
    // }
    // cout << endl;
    cout << dp[n + 1] - 2 << endl;
}
int32_t main()
{
    c_p_c();
    solve();


    return 0;
}