﻿
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define mp(a, b) make_pair(a, b)
#define F first
#define S second
#define pb(x) push_back(x)
#define N 100005
#define MOD 1000000007


int main()
{
    int t;
    t = 1;
    for (int r = 0; r < t; r++)
    {
        ll n, m, i, x, j, y, ans = 0;
        cin >> n;

        vector<ll> a(n + 1);
        for (i = 1; i <= n; i++)
            cin >> a[i];
        vector<ll> dp(n + 1), pre(n + 1);
        dp[0] = 0;
        pre[0] = 0;
        for (i = 1; i <= n; i++)
        {
            y = (pre[i - 1] - pre[a[i] - 1]);
            if (y < 0)
            {
                y = (y + MOD);
            }
            dp[i] = (2 + y) % MOD;
            dp[i] = dp[i] % MOD;
            pre[i] = (dp[i] % MOD + (pre[i - 1]) % MOD) % MOD;
            pre[i] = pre[i] % MOD;
            ans += dp[i];
            ans = ans % MOD;
        }


        cout << ans << "\n";
    }
    return 0;
}
