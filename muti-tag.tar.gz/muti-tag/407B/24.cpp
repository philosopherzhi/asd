﻿#include <bits/stdc++.h>

using namespace std;

long long n, i, j, dp[10010], a[10010], ans;

const long long mod = 1e9 + 7;

int main()
{
    cin >> n;
    for (i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    for (i = 1; i <= n; i++)
    {
        for (j = a[i]; j < i; j++)
        {
            dp[i] = (dp[i] + dp[j]) % mod;
        }
        dp[i] = (dp[i] + 2) % mod;
    }
    for (i = 1; i <= n; i++)
    {
        ans = (ans + dp[i]) % mod;
    }
    cout << ans;
    return 0;
}
