﻿#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll N = 1e5 + 520;
const ll mod = 1e9 + 7;
ll dp[N], S[N];
int main()
{
    ll n;
    cin >> n;
    dp[2] = 2; //从1到2为2；
    S[2] = 2; //从1到2总和为2;
    for (ll i = 1; i <= n; i++)
    {
        ll x;
        cin >> x;
        if (i == 1)
            continue;
        //从i到i+1要多少步;
        dp[i + 1] = (S[i] - S[x] + 2) % mod;
        S[i + 1] = (S[i] + dp[i + 1]) % mod;
    }
    cout << (S[n + 1] % mod + mod) % mod << endl;
}