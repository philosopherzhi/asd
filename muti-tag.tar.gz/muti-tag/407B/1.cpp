﻿/*===================*\
|ID : harryPotter_421  |
|      LANG: C++       |
\*====================*/
#include <iostream>
#include <bits/stdc++.h>
#define lli long long int
#define pb push_back
#define ld double
#define f(j, m, n) for (lli j = m; j < n; j++)
#define harry                                                                                      \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(NULL);                                                                                 \
    cout.tie(NULL);
#define forn(n)                                                                                    \
    for (i = 0; i < n; i++)                                                                        \
        ;
using namespace std;
int M = 1000000000 + 7;
int main()
{
    int n;
    cin >> n;
    int p[n + 1];
    for (int i = 1; i <= n; i++)
        cin >> p[i];
    int dp[n + 1];
    dp[1] = 2;
    for (int i = 2; i <= n; i++)
    {
        if (p[i] == i)
            dp[i] = 2;
        else
        {
            int sum = 0;
            int a = p[i];
            for (int j = a; j <= i - 1; j++)
                sum = (sum % M + dp[j] % M) % M;
            dp[i] = sum + 2;
            dp[i] = dp[i] % M;
        }
    }
    int suma = 0;
    for (int i = 1; i <= n; i++)
    {
        suma = (suma % M + dp[i] % M) % M;
    }
    cout << suma;
}
