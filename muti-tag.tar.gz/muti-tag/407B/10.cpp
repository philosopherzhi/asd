﻿#include <bits //stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
// type define....
typedef long long ll;
typedef unsigned long long ull;
typedef unsigned int u_int;
typedef vector<vector<int>> mat;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> v_i;
typedef vector<ll> v_ll;
typedef vector<pair<int, int>> v_pii;
typedef vector<pair<ll, ll>> v_pll;
typedef set<int> s_i;
typedef set<ll> s_ll;
typedef map<int, int> map_ii;
typedef map<ll, ll> map_ll;
typedef priority_queue<int> max_heap_i;
typedef priority_queue<int, vector<int>, greater<int>> min_heap_i;
typedef priority_queue<ll> max_heap_ll;
typedef priority_queue<ll, vector<ll>, greater<ll>> min_heap_ll;
typedef tree<pii, null_type, less<pii>, rb_tree_tag, tree_order_statistics_node_update> pbds_set;
// END OF TYPE DEFINE

// Macros define
#define double long double
#define F first
#define S second
#define PB push_back
#define IN insert
#define RIL(i, a, b) for (int i = a; i < b; i++)
#define RIL_K(i, a, b, k) for (int i = a; i < b; i += k)
#define RDL(i, a, b) for (int i = a; i >= b; i--)
#define RDL_K(i, a, b, k) for (int i = a; i >= b; i -= k)
#define all(v) v.begin(), v.end()
#define MAX(a, b, c) (max(a, max(b, c)))
#define MIN(a, b, c) (min(a, min(b, c)))
ll mod = 1e9 + 7;
void solve()
{
    int n;
    cin >> n;
    v_i arr(n + 1);
    RIL(i, 1, n + 1)
    {
        cin >> arr[i];
    }
    v_ll dp(n + 1, 0);
    RIL(i, 1, n + 1)
    {
        int u = arr[i];
        dp[i] = dp[i - 1];
        dp[i] = (dp[i] + (dp[i] - dp[u - 1] + 2ll) + mod) % mod;
    }
    cout << dp[n] << endl;
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int t = 1;
    // cin>>t;
    RIL(i, 0, t)
    {
        solve();
    }
}
