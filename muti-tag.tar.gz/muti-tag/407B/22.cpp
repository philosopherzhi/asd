﻿#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
typedef long double ld;
ll mod = 1e9 + 7;
ll mul(ll a, ll b)
{
    return ((a % mod) * (b % mod)) % mod;
}
ll add(ll a, ll b)
{
    return ((a % mod) + (b % mod)) % mod;
}
ll sub(ll a, ll b)
{
    return ((a % mod) - (b % mod) + mod) % mod;
}
ll gcdExtended(ll a, ll b, ll* x, ll* y)
{
    if (a == 0)
    {
        *x = 0, *y = 1;
        return b;
    }

    ll x1, y1;
    ll gcd = gcdExtended(b % a, a, &x1, &y1);

    *x = y1 - (b / a) * x1;
    *y = x1;

    return gcd;
}
ll modInverse(ll b)
{
    ll x, y; // used in extended GCD algorithm
    ll g = gcdExtended(b, mod, &x, &y);

    // Return -1 if b and m are not co-prime
    if (g != 1)
        return -1;

    // m is added to handle negative x
    return (x % mod + mod) % mod;
}

// Function to compute a/b under modlo m
ll modDivide(ll a, ll b)
{
    a = a % mod;
    ll inv = modInverse(b);
    if (inv == -1)
        return -1;
    else
        return (inv * a) % mod;
}

// call modDivide(a,b) for modulo division
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    ll i, t, j, inp, n;

    cin >> n;
    vector<ll> A;
    A.push_back(0);
    for (j = 0; j < n; j++)
    {
        cin >> inp;
        A.push_back(inp);
    }
    vector<ll> dp(n + 1, 2);

    for (j = 2; j <= n; j++)
    {
        for (i = A[j]; i < j; i++)
        {
            dp[j] = add(dp[j], dp[i]);
        }
    }
    ll ans = 0;
    for (j = 1; j <= n; j++)
    {
        ans = add(ans, dp[j]);
    }
    cout << ans << '\n';
    return 0;
}
