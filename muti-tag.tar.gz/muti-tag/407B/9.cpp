﻿/*
皮卡丘冲鸭！
へ　　　　　／|
　　/＼7　　　 ∠＿/
　 /　│　　 ／　／
　│　Z ＿,＜　／　　 /`ヽ
　│　　　　　ヽ　　 /　　〉
　 Y　　　　　`　 /　　/
　ｲ●　､　●　　⊂⊃〈　　/
　()　 へ　　　　|　＼〈
　　>ｰ ､_　 ィ　 │ ／／
　 / へ　　 /　ﾉ＜| ＼＼
　 ヽ_ﾉ　　(_／　 │／／
　　7　　　　　　　|／
　　＞―r￣￣`ｰ―＿
*/
#include <iostream>
#include <bits/stdc++.h>
#define For(i, x, y) for (int i = (x); i <= (y); i++)
#define fori(i, x, y) for (int i = (x); i < (y); i++)
#define rep(i, y, x) for (int i = (y); i >= (x); i--)
#define mst(x, a) memset(x, a, sizeof(x))
#define pb push_back
#define sz(a) (int) a.size()
#define ALL(x) x.begin(), x.end()
#define mp make_pair
#define fi first
#define se second
#define db double
#define debug(a) cout << #a << ": " << a << endl
using namespace std;
typedef long long LL;
typedef long long ll;
typedef unsigned long long ULL;
const LL INF = 0x3f3f3f3f3f3f3f3f;
const int inf = 0x3f3f3f3f;
typedef pair<int, int> pa;
typedef pair<ll, ll> pai;
typedef pair<db, db> pdd;

const int N = 2e5 + 10;
const int M = 1e5;
const int maxn = 2e5 + 10;
const db eps = 1e-8;
const db pi = acos(-1.0);

template <typename T1, typename T2>
void ckmin(T1& a, T2 b)
{
    if (a > b)
        a = b;
}
template <typename T1, typename T2>
void ckmax(T1& a, T2 b)
{
    if (a < b)
        a = b;
}
int read()
{
    int x = 0, f = 0;
    char ch = getchar();
    while (!isdigit(ch))
        f |= ch == '-', ch = getchar();
    while (isdigit(ch))
        x = 10 * x + ch - '0', ch = getchar();
    return f ? -x : x;
}
template <typename T>
void print(T x)
{
    if (x < 0)
        putchar('-'), x = -x;
    if (x >= 10)
        print(x / 10);
    putchar(x % 10 + '0');
}
template <typename T>
void print(T x, char let)
{
    print(x), putchar(let);
}

template <class T>
bool uin(T& a, T b)
{
    return a > b ? (a = b, true) : false;
}
template <class T>
bool uax(T& a, T b)
{
    return a < b ? (a = b, true) : false;
}
const int mod = 1e9 + 7;
int dp[1100], p[1100];
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    For(i, 1, n) cin >> p[i];
    For(i, 2, n + 1)
    {
        dp[i] = 2 * (LL)dp[i - 1] % mod + 2 - dp[p[i - 1]] + mod;
        dp[i] %= mod;
    }
    cout << ((LL)dp[n + 1] + mod) % mod;
    return 0;
}
