﻿#include <cstdio>
#include <iostream>
#define MOD 1000000007
using namespace std;
long long f[1010], g[1010], s[1010];
int p[1010];
int main()
{
    int n;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
        scanf("%d", &p[i]);
    f[1] = 1; //走到第i个房间且十字架的个数为偶数所需要的次数
    g[1] = 1; // g[i]表示在第i个房间,进入p[i]房间再走回第i个房间所需要的次数
    s[1] = 1; // g[i]的前缀和
    for (int i = 2; i <= n; i++)
    {
        long long x = (s[i - 1] - s[p[i] - 1] + MOD) % MOD;
        g[i] = (x + 1 + (i - p[i])) % MOD;
        f[i] = (g[i] + f[i - 1] + 1) % MOD;
        s[i] = (s[i - 1] + g[i]) % MOD;
    }
    long long ans = (f[n] + 1) % MOD;
    cout << ans << endl;
}
