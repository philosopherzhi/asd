﻿#include <bits/stdc++.h>
using namespace std;
/*
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
#define ordered_set tree<int, null_type,less<int>, rb_tree_tag,tree_order_statistics_node_update>
*/
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
#define rep(i, a, b) for (ll i = a; i <= b; ++i)
#define rrep(i, a, b) for (ll i = a; i >= b; --i)
#define FOR(i, n) for (ll i = 0; i < n; i++)
#define pb push_back
#define mp make_pair
#define PI 3.14159265358979323846
#define fi first
#define se second
#define all(x) x.begin(), x.end()
#define IOS                                                                                        \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(NULL);                                                                                 \
    cout.tie(NULL);

const ll INF = 1e18 + 10;
const ll mod = 1e9 + 7;
const ll MAXN = 2e5 + 10;

ll poww(ll a, ll b)
{
    if (b < 0)
        return 0LL;
    ll ans = 1;
    while (b)
    {
        if (b & 1)
            ans = ans * a;
        a = a * a;
        b >>= 1;
    }
    return ans;
}
ll binpow(ll a, ll b)
{
    if (b < 0)
        return 0LL;
    if (a <= 0)
        return 0LL;
    a %= mod;

    ll ans = 1LL;
    while (b)
    {
        if (b & 1)
            ans = ans * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return ans;
}
ll modinv(ll n)
{
    return binpow(n, mod - 2);
}

void solve()
{
    ll n;
    cin >> n;
    ll p[n + 1];
    FOR(i, n) cin >> p[i + 1];

    ll dp[n + 1];
    FOR(i, n + 1) dp[i] = 2;
    for (ll i = 1; i <= n; i++)
    {
        for (ll j = p[i]; j <= i - 1; j++)
            (dp[i] += dp[j]) %= mod;
    }
    ll ans = 0;
    for (ll i = 1; i <= n; i++)
        (ans += dp[i]) %= mod;
    cout << ans;
}

int main()
{
    IOS;
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif

    // ll no_of_test_cases; cin>>no_of_test_cases;
    ll no_of_test_cases = 1;
    // cout<<fixed<<setprecision(10);

    for (ll i = 1; i <= no_of_test_cases; i++)
    {
        solve();
    }
    return 0;
}
