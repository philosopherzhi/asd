﻿#include <bits/stdc++.h>
using namespace std;
long long p[100010], a[100010];
int main()
{
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cin >> p[i];
    }
    a[1] = 0;
    for (int i = 2; i <= n + 1; i++)
    {
        a[i] = (a[i - 1] + 1 + a[i - 1] - a[p[i - 1]] + 1 + 1000000007) % 1000000007;
    }
    cout << a[n + 1];
}