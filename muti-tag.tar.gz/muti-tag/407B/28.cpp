﻿#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
#define scanvector(a, n)                                                                           \
    vector<lli> a;                                                                                 \
    for (lli i = 0; i < n; i++)                                                                    \
    {                                                                                              \
        lli x;                                                                                     \
        cin >> x;                                                                                  \
        a.push_back(x);                                                                            \
    }
#define scanmatrix(a, n, m)                                                                        \
    vector<vector<lli> > a(n, vector<lli>(m, 0));                                                  \
    for (lli i = 0; i < n; i++)                                                                    \
    {                                                                                              \
        for (int j = 0; j < m; j++)                                                                \
        {                                                                                          \
            cin >> a[i][j];                                                                        \
        }                                                                                          \
    }
#define scanstring(s)                                                                              \
    string s;                                                                                      \
    cin >> s;
#define printvector(A)                                                                             \
    for (int i = 0; i < A.size(); i++)                                                             \
    {                                                                                              \
        cout << A[i] << " ";                                                                       \
    }                                                                                              \
    cout << "\n";
#define pi 3.14159265358979
typedef long double ld;
typedef vector<int> vi;
typedef vector<lli> vlli;
typedef vector<vector<int> > mati;
typedef vector<vector<lli> > matlli;
typedef vector<vector<bool> > matb;
typedef unordered_map<lli, lli> umpl;
typedef unordered_map<lli, vlli> umpv;
typedef map<lli, lli> mpl;
typedef map<lli, vlli> mpv;
#define For(i, a, m, l) for (lli i = a; i < m; i += l)
#define all(vec) (vec.begin(), vec.end())
#define itmp(it, mp) for (auto it = mp.begin(); it != mp.end(); it++)
#define itmpr(it, mp) for (auto it = mp.rbegin(); it != mp.rend(); it++)

long long int fast_exp(long long int A, long long int B, long long int C)
{
    if (A == 0)
        return 0;
    if (C == 0)
        return 0;
    if (B == 0)
        return 1;
    if (B == 1)
        return A % C;

    long long int res = A;

    if (res > C)
        res = res % C;

    int counter = 2;
    while (counter < B)
    {
        res = res * res;
        if (res > C)
            res = res % C;
        counter *= 2;
        if (counter >= B)
            break;
    }
    counter /= 2;

    return ((res % C) * fast_exp(A, B - counter, C)) % C;
}


lli mod_add(lli a, lli b, lli m)
{
    return (a + b) % m;
}
lli subtract(lli a, lli b, lli m)
{
    return ((a - b) % m + m) % m;
}

lli multiply(lli a, lli b, lli m)
{
    return (a * b) % m;
}

lli divide(lli a, lli b, lli m)
{
    return (a * fast_exp(b, m - 2, m)) % m;
}

int main()
{

    // EXPLANATION
    // Credit- user graceoflives

    /*suppose that you are in room k the 1st time (aka the number of crosses is odd), and the number
    in room k is p[k].

    let s[k] the steps you need to go from room k to room k+1.

    in order to do that:

    you need 1 step to go from room k to room p;

    you need s[p[k]]+s[p[k]+1]+s[p[k]+2]+...+s[k-1] steps to go from room p to room k. now the
    number of crosses is even;

    you need 1 step to go from room k to room k+1.
    so

    s[k]=2+s[p[k]]+s[p[k]+1]+s[p[k]+2]+..+s[k-1]

    and of course

    answer=s[1]+s[2]+..+s[n]

    */


    lli n;
    cin >> n;
    scanvector(p, n);
    ;
    lli mod = 1000000007LL;

    vlli dp(n, 0);
    dp[0] = 2;
    For(i, 1, n, 1)
    {
        dp[i] += 2;
        dp[i] %= mod;
        For(j, p[i] - 1, i, 1)
        {
            dp[i] += dp[j];
            dp[i] %= mod;
        }
    }
    // printvector(dp);
    lli ans = 0;
    For(i, 0, n, 1)
    {
        ans += dp[i];
        ans %= mod;
    }
    cout << ans << "\n";

    return 0;
}