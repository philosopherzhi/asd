﻿#include <iostream>
using namespace std;

typedef long long ll;

const int N = 1e3 + 10;
const int M = 1e9 + 7;
ll n, a[N];
ll dp[N], psum_dp[N];
ll ans;

void input()
{
    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> a[i];
}


void _dp()
{
    dp[1] = 2;
    psum_dp[1] = 2;
    for (int i = 2; i <= n; i++)
    {
        dp[i] = psum_dp[i - 1] - psum_dp[a[i] - 1] + 2;
        dp[i] = dp[i] % M;
        psum_dp[i] = psum_dp[i - 1] + dp[i];
    }
}


void output()
{
    for (int i = 1; i <= n; i++)
    {
        ans += dp[i];
        ans = ans % M;
    }
    cout << ans << "\n";
}


int main()
{
    input();
    _dp();
    output();
}
//=)