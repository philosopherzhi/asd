﻿#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod = 1e9 + 7;
/*int e[200005],h[100005],idx,ne[200005],w[100005];
void add(int l,int r,int c)
{
    e[idx]=r,w[idx]=c,ne[idx]=h[l],h[l]=idx++;
}*/
/*int st[1000005],prime[1000005],cnt;
void init(int n)
{
    for(int i=2;i<=n;i++)
    {
        if(!st[i])
        prime[cnt++]=i;
        for(int j=0;prime[j]<=n/i;j++)
        {
            st[prime[j]*i]=1;
            if(i%prime[j]==0)
            break;
        }
    }
}*/
/*ll qpow(ll a,ll b)
{
        ll res=1;3

        while(b)
        {
                if(b&1) res=res*a%mod;
                b>>=1;
                a=a*a%mod;
        }
        return res;
}*/
ll a[1005], sum[1005];
int main()
{
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> a[i];
    for (int i = 1; i <= n; i++)
    {
        for (int j = i; j >= a[i]; j--)
            sum[i] = (sum[i] + sum[j]) % mod;
        sum[i] = (sum[i] + 2) % mod;
    }
    ll sum1 = 0;
    for (int i = 1; i <= n; i++)
        sum1 = (sum1 + sum[i]) % mod;
    cout << sum1;
    return 0;
}