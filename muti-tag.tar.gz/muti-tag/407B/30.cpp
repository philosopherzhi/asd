﻿#include <bits/stdc++.h>
#include <random>
#include <chrono>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
#define IOS                                                                                        \
    ios::sync_with_stdio(0);                                                                       \
    cin.tie(0);                                                                                    \
    cout.tie(0);
#define int long long
#define pb push_back
#define vi vector<int>
#define pii pair<int, int>
#define all(a) (a).begin(), (a).end()
#define ff first
#define ss second
#define INF 1e18
const int N = 16 + 5, K = 501, mod = 1000000007;

void solve()
{
    int n;
    cin >> n;
    vi v(n + 1);
    for (int i = 1; i <= n; i++)
        cin >> v[i];
    vi moves(n + 1), pre(n + 1);
    int tot = 2;
    pre[1] = moves[1] = 2;
    for (int i = 2; i <= n; i++)
    {
        if (v[i] == i)
        {
            moves[i] = 2;
        }
        else
        {
            moves[i] = pre[i - 1] - pre[v[i] - 1] + 2;
        }
        moves[i] = (moves[i] + mod) % mod;
        pre[i] = pre[i - 1] + moves[i];
        pre[i] %= mod;
        tot += moves[i];
        tot %= mod;
    }
    cout << tot << endl;
}

int32_t main()
{
    IOS;
    int TESTS = 1;
    // cin>>TESTS;
    while (TESTS--)
    {
        solve();
    }
    return 0;
}
