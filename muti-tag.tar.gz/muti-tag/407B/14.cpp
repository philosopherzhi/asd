﻿#include <bits/stdc++.h>
using namespace std;
#define fast                                                                                       \
    ios::sync_with_stdio(0);                                                                       \
    cin.tie(0);                                                                                    \
    cout.tie(0);
#define ll long long
#define f first
#define s second
#define all(arr) arr.begin(), arr.end()
#define MOD 1000000007

void solve()
{
    ll n;
    cin >> n;
    vector<ll> p(n + 1);
    for (ll i = 1; i <= n; i++)
        cin >> p[i];
    vector<ll> dp(n + 1, 0), prefix(n + 1, 0);
    prefix[1] = dp[1] = 2;
    for (ll i = 2; i <= n; i++)
    {
        dp[i] = (prefix[i - 1] - prefix[p[i] - 1] + 2 + MOD) % MOD;
        prefix[i] = (prefix[i - 1] + dp[i]) % MOD;
    }
    cout << prefix[n] << endl;
}
int main()
{
    fast;

    int t = 1;
    // cin>>t;
    while (t--)
    {
        solve();
    }

    return 0;
}