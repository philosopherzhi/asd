﻿#include <bits/stdc++.h>
using namespace std;
#define ar array
#define ll long long
#define debug1(x) cout << #x << " " << x << endl;
#define debug2(x, y) cout << #x << " " << x << " " << #y << " " << y << endl;
#define debug3(x, y, z)                                                                            \
    cout << #x << " " << x << " " << #y << " " << y << " " << #z << " " << z << endl;
const int MAX_N = 2e5 + 100;
const int MOD = 1e9 + 7;
const int INF = 1e9;
const ll LINF = 1e18;
void solve()
{
    int n;
    cin >> n;
    vector<int> p(n + 1);
    for (int i = 1; i <= n; ++i)
    {
        cin >> p[i];
    }
    vector<ll> dp(n + 2, 0);
    for (int i = 2; i <= n + 1; ++i)
    {
        dp[i] = (dp[i - 1] + dp[i - 1] - dp[p[i - 1]] + 2 + MOD) % MOD;
    }
    cout << dp[n + 1] << endl;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

#ifndef ONLINE_JUDGE
    freopen("input1.txt", "r", stdin);
    freopen("output1.txt", "w", stdout);
#endif
    int t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
}