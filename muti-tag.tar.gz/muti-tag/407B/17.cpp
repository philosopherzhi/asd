﻿#include <bits/stdc++.h>
#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define int long long int
#define pii pair<int, int>
const int INF = 1e15;
using namespace std;
const int MAX = 1e7 + 5;
const int MAXK = 25;
const int mod = 1e9 + 7;
int gcd(int a, int b)
{
    while (b > 0)
    {
        a = a % b;
        swap(a, b);
    }
    return a;
}
int binpow(int a, int b)
{
    int res = 1;
    while (b > 0)
    {
        if (b % 2 == 1)
            res = res * a % mod;
        a = a * a % mod;
        b /= 2;
    }
    return res % mod;
}
void solve()
{
    int n;
    cin >> n;
    int ar[n + 1];
    for (int i = 1; i <= n; i++)
    {
        cin >> ar[i];
    }
    int dp[n + 2];
    dp[1] = 0;
    for (int i = 1; i <= n; i++)
    {
        dp[i + 1] = (2 * dp[i] + 2 - dp[ar[i]] + mod) % mod;
    }
    cout << dp[n + 1] << "\n";
}
int32_t main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    int t = 1;
    // cin>>t;
    for (int i = 1; i <= t; i++)
    {
        // cout<<"Case #"<<i<<": ";
        solve();
    }
}