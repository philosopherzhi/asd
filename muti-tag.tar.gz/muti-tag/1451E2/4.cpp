﻿#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> PII;

int main()
{
    auto ask = [&](int op, int x, int y)
    {
        if (op == 1)
            printf("AND %d %d\n", x, y);
        else if (op == 2)
            printf("OR %d %d\n", x, y);
        else if (op == 3)
            printf("XOR %d %d\n", x, y);
        fflush(stdout);
        int val;
        scanf("%d", &val);
        return val;
    };

    int n;
    scanf("%d", &n);
    vector<int> ans(n + 1, -1), val(n + 1);
    vector<vector<int>> buc(n + 1);
    for (int i = 2; i <= n; i++)
    {
        val[i] = ask(3, 1, i);
        buc[val[i]].emplace_back(i);
    }
    if ((int)buc[0].size())
    {
        int res = ask(2, 1, buc[0][0]);
        ans[1] = res;
        for (int i = 2; i <= n; i++)
            ans[i] = ans[1] ^ val[i];
    }
    else
    {
        bool ok = false;
        for (int j = 1; j < n && !ok; j++)
        {
            if ((int)buc[j].size() <= 1)
                continue;
            ok = true;
            int res = ask(2, buc[j][0], buc[j][1]);
            ans[1] = res ^ val[buc[j][0]];
            for (int i = 2; i <= n; i++)
                ans[i] = ans[1] ^ val[i];
        }

        if (!ok)
        {
            int res = ask(2, 1, buc[1][0]);
            res >>= 1;
            res <<= 1;
            int tmp = ask(1, 1, buc[2][0]);
            if (tmp & 1)
                res |= 1;
            ans[1] = res;
            for (int i = 2; i <= n; i++)
                ans[i] = ans[1] ^ val[i];
        }
    }

    printf("!");
    for (int i = 1; i <= n; i++)
        printf(" %d", ans[i]);

    return 0;
}