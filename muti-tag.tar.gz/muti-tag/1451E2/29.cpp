﻿/*
ID: Trump
TASK:
LANG: C++
*/
/* LANG can be C++11 or C++14 for those more recent releases */
#include <iostream>
#include <fstream>
#include <cstring>
#include <map>
#include <queue>
#include <algorithm>
#include <cmath>
#define sll(n) scanf("%lld", &n);
#define sll2(a, b) scanf("%lld", &n);
#define sll3(a, b, c) scanf("%lld%lld%lld", &a, &b, &c);
#define slb(n) scanf("%Lf", &n);
#define pll(n) printf("%lld", n);
#define pln printf("\n");
#define plb(n) printf("%Lf", n);
#define plb2(n) printf("%.2Lf", n);
#define plb3(n) printf("%.3Lf", n);
#define plb4(n) printf("%.4Lf", n);
#define plb5(n) printf("%.5Lf", n);
#define plb6(n) printf("%.6Lf", n);
using namespace std;
typedef long long ll;
typedef long double lb;
typedef double db;
typedef int it;
typedef bool bl;
//#define MARK
const ll losn = 1e6 + 5;
const ll maxn = 1e5 + 5;
const ll minn = 1e3 + 5;
const ll tiny = 1e2 + 5;
const ll inf = 1e9;
const ll binf = 1e18;
const ll mod = 1e9 + 7;
const ll lmod = 998244353;
const ll hashmod = 4698571;
const lb pi = 3.1415926;
const ll myn = 0;
void gk()
{
    cout << "---------------" << endl;
}
void ck()
{
    cout << 1 << endl;
}
void ck(ll a)
{
    cout << a << endl;
}
void ck(ll a[minn][minn], ll n, ll m)
{
    for (ll i = 1; i <= n; i++)
    {
        for (ll j = 1; j <= m; j++)
        {
            cout << a[i][j] << " ";
        }
        cout << endl;
    }
}
ll n, m, k, T, u, v, len;

ll arr[losn];
ll nums[losn];
ll ans[losn];
ll ors[losn];

char c[losn];
ll cnt = 0;
int main()
{
    //#ifdef MARK
    //    freopen("input.in", "r", stdin);
    //    freopen("ouput.out", "w", stdout);
    //    freopen("ouput.out", "r", stdin);
    //    freopen("input.in", "w", stdout);
    //#endif
    cin >> n;
    ll s;
    ll state = 0;
    for (ll i = 2; i <= n; i++)
    {
        cout << "XOR 1 " << i << endl;
        cin >> s;
        ors[i] = s;
    }
    map<ll, ll> mp;
    for (ll i = 2; i <= n; i++)
    {
        if (ors[i] == 0)
        {
            cout << "AND 1 " << i << endl;
            ll s;
            cin >> s;
            ans[1] = s;
            ans[i] = s;
            state = 1;
            break;
        }
        if (mp[ors[i]])
        {
            cout << "AND " << mp[ors[i]] << " " << i << endl;
            ll s;
            cin >> s;
            ans[i] = s;
            ans[mp[ors[i]]] = s;
            ans[1] = ans[i] ^ ors[i];
            state = 2;
            break;
        }
        mp[ors[i]] = i;
    }
    if (state == 1 || state == 2)
    {
        for (ll i = 2; i <= n; i++)
        {
            ans[i] = ans[1] ^ ors[i];
        }
        cout << "! ";
        for (ll i = 1; i <= n; i++)
        {
            cout << ans[i] << " ";
        }
        cout << endl;
        return 0;
    }

    ll id1 = 0;
    ll id2 = 0;
    for (ll i = 2; i <= n; i++)
    {
        if (ors[i] == 1)
        {
            id1 = i;
        }
        if (ors[i] % 2 == 1 && ors[i] != 1)
        {
            id2 = i;
        }
    }
    cout << "AND " << 1 << " " << id1 << endl;
    cin >> s;
    while (s)
    {
        c[++cnt] = char((s % 2) + '0');
        s >>= 1;
    }
    cout << "OR " << id1 << " " << id2 << endl;
    cin >> s;
    if (s % 2 == 0)
    {
        c[1] = '1';
        if (cnt == 0)
        {
            cnt = 1;
        }
    }
    else
    {
        c[1] = '0';
    }
    ll nums = 0;
    ll ks = 1;
    for (ll i = 1; i <= cnt; i++)
    {
        if (c[i] == '1')
        {
            nums += ks;
        }
        ks *= 2;
    }
    ans[1] = nums;
    for (ll i = 2; i <= n; i++)
    {
        ans[i] = ans[1] ^ ors[i];
    }
    cout << "! ";
    for (ll i = 1; i <= n; i++)
    {
        cout << ans[i] << " ";
    }
    cout << endl;

    return 0;
}


/*



4
1 2 3 0

*/