﻿#include <bits/stdc++.h>
using namespace std;
char* str[] = { "AND", "OR", "XOR" };
enum
{
    AND,
    OR,
    XOR
};
const int maxn = 1e5 + 10;
int n;
int a[maxn], pre[maxn], ans[maxn], vis[maxn];
int query(int type, int i, int j)
{
    printf(str[type]);
    printf(" %d %d\n", i, j);
    fflush(stdout);
    int res = 0;
    scanf("%d", &res);
    return res;
}
int main()
{
    scanf("%d", &n);
    for (int i = 2; i <= n; ++i)
    {
        a[i] = query(XOR, 1, i);
    }
    for (int i = 2; i <= n; ++i)
    {
        int k = a[i];
        if (pre[k])
        {
            ans[1] = a[i] ^ query(AND, pre[k], i);
            for (int j = 2; j <= n; ++j)
            {
                ans[j] = a[j] ^ ans[1];
            }
            break;
        }
        if (pre[n - 1 - k])
        {
            int ci = pre[n - 1 - k], cj = i;
            int AND1i = query(AND, 1, ci);
            int AND1j = query(AND, 1, cj);
            int sum1i = a[ci] + (AND1i << 1);
            int sum1j = a[cj] + (AND1j << 1);
            int sumij = (a[ci] ^ a[cj]);
            ans[1] = (sum1i + sum1j + sumij) / 2 - sumij;
            for (int j = 2; j <= n; ++j)
            {
                ans[j] = a[j] ^ ans[1];
            }
            break;
        }
        pre[k] = i;
    }
    printf("!");
    for (int i = 1; i <= n; ++i)
    {
        printf(" %d", ans[i]);
    }
    puts("");
}