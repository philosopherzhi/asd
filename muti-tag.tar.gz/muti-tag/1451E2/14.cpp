﻿/*
 * CM 	= March
 * M 	= May
 * IM 	= July
 * GM 	= September
 * IGM	= December
*/

#include <bits/stdc++.h>

#define F first
#define S second

#define pb push_back
#define mp make_pair

typedef long long int lli;

#define pll pair<lli, lli>
#define pil pair<int, lli>
#define pli pair<lli, int>
#define pii pair<int, int>
#define pdd pair<double, double>

#define vi vector<int>
#define vl vector<lli>
#define pq priority_queue

#define end end
#define beg begin
#define lb lower_bound
#define ub upper_bound

#define dmx(x, y) x = max(x, y)
#define dmn(x, y) x = min(x, y)

using namespace std;

void setIO()
{
    ios_base::sync_with_stdio(0);

    cin.tie(nullptr);
    cout.tie(nullptr);
}

const int MAX = 7e4 + 0;
const int LEN = 5e2 + 0;
const int LVL = 2e1 + 0;
const lli MOD = 1e9 + 7;
const lli INF = 2e9;

int xyz = 1; // test cases

int n;
int val[MAX];
int ans[MAX];

vi pos[MAX];

int que(string s, int i, int j)
{
    cout << s << " " << i << " " << j << endl;
    int x;
    cin >> x;
    return x;
}

void run()
{
    cin >> n;

    for (int i = 2; i <= n; i++)
        val[i] = que("XOR", 1, i);

    for (int i = 2; i <= n; i++)
        pos[val[i]].pb(i);

    int a = 1;
    int b = -1;
    int c = -1;

    int can = -1;
    for (int i = 0; i < MAX; i++)
    {
        if (pos[i].size() > 1)
        {
            b = pos[i][0];
            c = pos[i][1];
            can = i;
        }
    }

    if (can != -1)
    {
        ans[1] = que("AND", b, c) ^ can;
    }
    else
    {
        for (int i = 2; i <= n; i++)
            for (int j = n; j > i; j--)
                if ((val[i] ^ val[j]) == n - 1)
                {
                    b = i;
                    c = j;
                    goto next;
                }

    next:;

        int p = val[b];
        int q = val[c];
        int x = que("AND", a, b);
        int y = que("AND", a, c);

        int s = n - 1;
        int ab = 2 * x + p;
        int ac = 2 * y + q;

        ans[1] = val[a] ^ (ab + ac - s) / 2;
    }

    for (int i = 2; i <= n; i++)
        ans[i] = val[i] ^ ans[1];

    cout << "! ";
    for (int i = 1; i <= n; i++)
        cout << ans[i] << " ";
    cout << endl;
}

int main()
{
    setIO();

    while (xyz--)
        run();

    return 0;
}
