﻿#pragma GCC target("avx2")
#pragma GCC optimize("Ofast")
#include <bits/stdc++.h>

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#define fin cin
#define fout cout
#define ll long long
#define ld long double
#define ull unsigned long long
#define endl '\n'
#define F first
#define S second
#define FBO find_by_order
#define pb push_back
#define pf push_front
#define ppf pop_front
#define ppb pop_back
//#define int ll
//#define int short


using namespace std;
using namespace __gnu_pbds;

const ll INF = 1e18 + 7;
const int inf = 1e9 + 7;
const ld eps = 0.00000000001;
const ld pi = 3.14159265358979;

typedef tree<pair<int, int>, null_type, less<pair<int, int> >, rb_tree_tag,
    tree_order_statistics_node_update> ordered_set;

mt19937_64 rnd(chrono::high_resolution_clock::now().time_since_epoch().count());


int32_t main()
{

    //        ios_base::sync_with_stdio(0);
    //    cin.tie(0);
    //    cout.tie(0);

    //    #ifdef ISMY
    //        ifstream fin("input.txt");
    //        ofstream fout("output.txt");
    //        #else
    ////                ifstream fin("mushrooms.in");
    ////        ofstream fout("mushrooms.out");
    //    #endif


    int n;
    fin >> n;

    int a[n] = { 0 };

    vector<int> cnt[n + 2];

    cnt[0].pb(0);
    for (int i = 1; i < n; ++i)
    {
        fout << "XOR" << ' ' << 1 << ' ' << i + 1 << endl;
        int x;
        fin >> x;
        a[i] = x;
        cnt[x].pb(i);
    }

    bool ok = 0;

    int ot[n] = { 0 };

    for (int i = 0; i < n; ++i)
    {
        if (int32_t(cnt[i].size()) >= 2)
        {
            ok = 1;

            fout << "AND" << ' ' << cnt[i][0] + 1 << ' ' << cnt[i][1] + 1 << endl;

            int x;
            fin >> x;
            ot[0] = (x ^ a[cnt[i][0]]);
            break;
        }
    }


    if (ok)
    {
        for (int i = 1; i < n; ++i)
            ot[i] = (ot[0] ^ a[i]);

        fout << '!' << ' ';

        for (int i = 0; i < n; ++i)
            fout << ot[i] << ' ';

        return 0;
    }


    int a1 = 0;
    int b1 = 0;
    int c1 = 0;

    int it = cnt[n - 1][0];

    a1 = n - 1;

    int it1 = it + 1;
    if (it1 == n)
        it1 -= 2;

    fout << "AND" << ' ' << 1 << ' ' << it1 + 1 << endl;

    int x;
    fin >> x;

    b1 = a[it1] + 2 * x;


    int y = a[it] ^ a[it1];

    fout << "AND" << ' ' << it + 1 << ' ' << it1 + 1 << endl;

    fin >> x;

    c1 = y + 2 * x;

    // cerr<<a1<<' '<<b1<<' '<<c1<<endl;

    ot[0] = (a1 + b1 - c1) / 2;

    for (int i = 1; i < n; ++i)
        ot[i] = (a[i] ^ ot[0]);

    fout << '!' << ' ';

    for (auto to : ot)
        fout << to << ' ';
}
