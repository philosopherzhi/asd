﻿#include <stdio.h>
int main()
{
    int n;
    scanf("%d", &n);
    int a[100000], b[100000], vis[100000] = { 0 };
    int q = -1, p = -1;
    for (int i = 2; i <= n; i++)
    {
        printf("XOR 1 %d\n", i);
        fflush(stdout);
        scanf("%d", &a[i]);
        if (a[i] == 0)
        {
            q = 1;
            p = i;
        }
        else if (vis[a[i]] != 0)
        {
            q = vis[a[i]];
            p = i;
        }
        else
        {
            vis[a[i]] = i;
        }
    }
    if (q == -1)
    {
        p = vis[n - 1];
        int c;
        if (p == 2)
        {
            c = 3;
        }
        else
        {
            c = 2;
        }
        int x, y, z;
        printf("AND 1 %d\n", c);
        fflush(stdout);
        scanf("%d", &x);
        y = (n - 1) ^ a[c];
        printf("AND %d %d\n", c, p);
        fflush(stdout);
        scanf("%d", &z);
        b[1] = (a[c] + 2 * x + a[p] - y - 2 * z) / 2;
        b[c] = (a[c] + 2 * x + y + 2 * z - a[p]) / 2;
        b[p] = (a[p] + y + 2 * z - a[c] - 2 * x) / 2;
        for (int i = 2; i <= n; i++)
        {
            if (i == p || i == c)
            {
                continue;
            }
            b[i] = a[i] ^ b[1];
        }
        printf("! ");
        for (int i = 1; i <= n; i++)
        {
            printf("%d ", b[i]);
        }
        printf("\n");
    }
    else
    {
        int x;
        printf("AND %d %d\n", q, p);
        fflush(stdout);
        scanf("%d", &x);
        b[q] = b[p] = x;
        if (q != 1 && p != 1)
            b[1] = b[q] ^ a[q];
        for (int i = 2; i <= n; i++)
        {
            if (i == q || i == p)
            {
                continue;
            }
            b[i] = b[1] ^ a[i];
        }
        printf("! ");
        for (int i = 1; i <= n; i++)
        {
            printf("%d ", b[i]);
        }
        printf("\n");
    }
}
