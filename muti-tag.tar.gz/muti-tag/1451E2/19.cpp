﻿#include <cstdio>
#include <iostream>
#include <cmath>
#include <cstring>
#include <cctype>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <queue>
#define fs(i, x, y) for (int i = (x), _ = (y); i <= _; ++i)
#define fn(i, x, y) for (int i = (x), _ = (y); i >= _; --i)
#define tor(i, v, x) for (int i = head[x], v = to[i]; i; i = nxt[i], v = to[i])
#define ls(x) ch[x][0]
#define rs(x) ch[x][1]
#define mpi(x, y) make_pair(x, y)
#define pi pair<int, int>
#define DEBUG printf("%s %d\n", __FUNCTION__, __LINE__)
using namespace std;
typedef long long ll;
typedef double db;
template <typename T>
void read(T& x)
{
    x = 0;
    char ch = getchar();
    bool f = 0;
    while (ch < '0' || ch > '9')
    {
        if (ch == '-')
            f = 1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9')
        x = (x << 1) + (x << 3) + ch - '0', ch = getchar();
    x = f ? -x : x;
}

const int N = 1e5 + 7;
int n, m;
int res[N];
int a[N];
int vis[N];

int yu(int i, int j)
{
    cout << "AND " << i << ' ' << j << endl;
    cin >> i;
    return i;
}

int huo(int i, int j)
{
    cout << "OR " << i << ' ' << j << endl;
    cin >> i;
    return i;
}

int yihuo(int i, int j)
{
    cout << "XOR " << i << " " << j << endl;
    cin >> i;
    return i;
}

void print()
{
    cout << "! ";
    fs(i, 1, n) cout << a[i] << ' ';
    cout << endl;
}

signed main()
{
    cin >> n;
    cin.tie(nullptr);
    ios::sync_with_stdio(false);
    bool ok = false;
    fs(i, 2, n)
    {
        res[i] = yihuo(1, i);
        if (!ok)
        {
            if (!res[i])
            {
                a[1] = yu(1, i);
                ok = true;
            }
            else if (vis[res[i]])
            {
                a[i] = yu(vis[res[i]], i);
                a[1] = res[i] ^ a[i];
                ok = true;
            }
        }
        vis[res[i]] = i;
    }
    if (!ok)
    {
        int pos = 0;
        fs(i, 2, n)
        {
            if (res[i] == 1)
            {
                pos = i;
                break;
            }
        }
        int hh = yu(1, pos);
        pos = 0;
        fs(i, 2, n)
        {
            if (res[i] % 2 == 0)
            {
                pos = i;
                break;
            }
        }
        int hhh = yu(1, pos);
        if (hhh & 1)
            a[1] = hh ^ 1;
        else
            a[1] = hh;
    }
    fs(i, 2, n) a[i] = res[i] ^ a[1];
    print();
    return 0;
}