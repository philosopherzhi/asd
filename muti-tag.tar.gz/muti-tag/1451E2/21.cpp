﻿#include <iostream>

using namespace std;

int main()
{
    int n;
    cin >> n;
    int a[65537];
    bool zero = false;
    int x = -1, y = -1, x1 = -1, y1 = -1;
    for (int i = 2; i <= n; ++i)
    {
        cout << "XOR " << 1 << ' ' << i << '\n';
        fflush(stdout);
        cin >> a[i];
        int k = a[i];
        if (k == 0)
        {
            x = 1;
            y = i;
            zero = true;
        }
        else if (!zero && k == 1)
        {
            x = 1;
            y = i;
        }
        else if ((k & 1) == 0)
        {
            x1 = 1;
            y1 = i;
        }
    }
    a[1] = 0;
    if (zero)
    {
        int c;
        cout << "AND " << x << ' ' << y << '\n';
        fflush(stdout);
        cin >> c;
        cout << "! ";
        for (int i = 1; i <= n; ++i)
        {
            cout << (a[i] ^ c) << ' ';
        }
        fflush(stdout);
        return 0;
    }
    bool found = false;
    for (int i = 2; i <= n; ++i)
    {
        for (int j = i + 1; j <= n; ++j)
        {
            int k = (a[i] ^ a[j]);
            if (k == 0)
            {
                x = i;
                y = j;
                zero = true;
                break;
            }
            else if (k == 1)
            {
                x = i;
                y = j;
            }
            else if ((k & 1) == 0)
            {
                x1 = i;
                y1 = j;
            }
            if (x != -1 && y != -1 && x1 != -1 && y1 != -1)
            {
                found = true;
                break;
            }
        }
        if (found)
            break;
    }
    if (zero)
    {
        int c;
        cout << "AND " << x << ' ' << y << '\n';
        fflush(stdout);
        cin >> c;
        c = (a[x] ^ c);
        cout << "! ";
        for (int i = 1; i <= n; ++i)
        {
            cout << (a[i] ^ c) << ' ';
        }
        fflush(stdout);
        return 0;
    }
    cout << "AND " << x1 << ' ' << y1 << '\n';
    fflush(stdout);
    int c, d, e, f;
    cin >> c;
    c = (c & 1);
    cout << "AND " << x << ' ' << y << '\n';
    fflush(stdout);
    cin >> d;
    e = ((a[x] ^ a[x1]) & 1);
    if (e == 0)
        d = d + c;
    else
        d = d + (1 - c);
    d = (a[x] ^ d);
    cout << "! ";
    for (int i = 1; i <= n; ++i)
    {
        cout << (a[i] ^ d) << ' ';
    }
    fflush(stdout);
    return 0;
}