﻿// Problem: E1. Bitwise Queries (Easy Version)
// Contest: Codeforces - Codeforces Round #685 (Div. 2)
// URL: https://codeforces.com/contest/1451/problem/E1
// Memory Limit: 256 MB
// Time Limit: 4000 ms
//
// Powered by CP Editor (https://cpeditor.org)

#include <bits/stdc++.h>
using namespace std;
#define int long long int
#define float long double
#define pb push_back
#define mp make_pair
#define pii pair<int, int>
#define vi vector<int>
#define mii map<int, int>
#define setbits(n) __builtin_popcount(n)
#define endl "\n"
#define yes cout << "YES" << endl;
#define no cout << "NO" << endl;
#define fi first
#define se second

#define IOS                                                                                        \
    ios::sync_with_stdio(false);                                                                   \
    cin.tie(0);                                                                                    \
    cout.tie(0);
int mod = 1e9 + 7;
const int N = 2e5 + 5;
int fact[N], inv[N];

int gcd(int a, int b)
{
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

int lcm(int a, int b)
{
    return (a * b) / gcd(a, b);
}

int power(int a, int b, int p)
{
    if (a == 0)
        return 0;
    int res = 1;
    a %= p;
    while (b > 0)
    {
        if (b % 2)
            res = (res * a) % p;
        a = (a * a) % p;
        b = b / 2;
    }
    return res;
}
void factorials()
{
    fact[0] = 1;
    inv[0] = 1;
    for (int i = 1; i < N; i++)
        fact[i] = (i % mod * fact[i - 1]) % mod;
    for (int i = 1; i < N; i++)
        inv[i] = power(fact[i], mod - 2, mod);
}


void solve()
{

    int n;
    cin >> n;
    int a[n + 1];
    mii m;
    int l = -1, r = -1;
    for (int i = 2; i <= n; i++)
    {
        cout << "XOR 1 " << i << endl;
        cout.flush();
        cin >> a[i];
        if (m.find(a[i]) != m.end())
        {
            l = m[a[i]];
            r = i;
        }
        m[a[i]] = i;
    }
    if (l != -1 && r != -1)
    {
        cout << "AND " << l << " " << r << endl;
        cout.flush();
        int x;
        cin >> x;
        a[1] = x ^ a[l];
    }
    else
    {
        int i;
        for (i = 2; i <= n; i++)
            if (a[i] == n - 1)
                break;
        int j;
        for (j = 2; j <= n; j++)
            if (j != i)
                break;
        int f = a[i], g = a[i] ^ a[j], h = a[j];
        int p, q, r;
        p = 0;
        cout << "AND " << i << " " << j << endl;
        cout.flush();
        cin >> q;
        cout << "AND " << 1 << " " << j << endl;
        cout.flush();
        cin >> r;
        f += 2 * p;
        g += 2 * q;
        h += 2 * r;
        a[1] = (f - g + h) / 2;
    }
    for (int i = 2; i <= n; i++)
        a[i] = a[i] ^ a[1];
    cout << "! ";
    for (int i = 1; i <= n; i++)
        cout << a[i] << " ";
    cout << endl;
}

int32_t main()
{
    IOS

        int t
        = 1; // cin>>t;
    while (t--)
    {
        solve();
    }
}
