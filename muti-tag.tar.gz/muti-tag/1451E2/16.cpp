﻿#include <bits/stdc++.h>

using namespace std;


void setup()
{
#ifdef LOCAL
// freopen("input", "r", stdin);
#else
    ios::sync_with_stdio(0);
    cin.tie(0);
#endif
}

int getAnd(int i, int j)
{
    cout << "AND " << i + 1 << " " << j + 1 << endl;
    int res;
    cin >> res;
    return res;
}


int getXor(int i, int j)
{
    cout << "XOR " << i + 1 << " " << j + 1 << endl;
    int res;
    cin >> res;
    return res;
}


int main()
{
    setup();
    int n;
    cin >> n;

    vector<int> xors(n - 1);
    vector<bool> seen(n);
    vector<int> arr(n);
    bool found = false;
    for (int i = 0; i < n - 1; i++)
    {
        xors[i] = getXor(0, i + 1);
        if (!found)
        {
            if (seen[xors[i]])
            {
                for (int j = 0; j < n; j++)
                {
                    if (i != j && xors[i] == xors[j])
                    {
                        arr[i + 1] = arr[j + 1] = getAnd(i + 1, j + 1);
                        arr[0] = xors[i] ^ arr[i + 1];
                        break;
                    }
                }
                found = true;
            }
            else if (xors[i] == 0)
            {
                arr[i + 1] = arr[0] = getAnd(0, i + 1);
                found = true;
            }
        }
        seen[xors[i]] = true;
    }
    if (!found)
    {
        int i;
        for (i = 1; i < n && xors[i - 1] != n - 1; i++)
            ;
        assert(i < n);
        int j = 1 + (i == 1);
        int s0i = xors[i - 1];
        int s0j = xors[j - 1] + 2 * getAnd(0, j);
        int sij = (xors[i - 1] ^ xors[j - 1]) + 2 * getAnd(i, j);

        int total = s0i + s0j + sij;
        assert(total % 2 == 0);
        total /= 2;
        arr[0] = total - sij;
    }
    for (int i = 1; i < n; i++)
    {
        arr[i] = arr[0] ^ xors[i - 1];
    }
    cout << "! ";
    for (int it : arr)
    {
        cout << it << " ";
    }
    cout << endl;
}
