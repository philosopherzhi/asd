﻿#include <bits/stdc++.h>
using namespace std;
const int maxn = (1 << 16) + 114;
int n, shu[maxn], ans[maxn];
int pre[maxn];
inline void work()
{
    cout << "! ";
    for (int i = 2; i <= n; ++i)
        ans[i] = ans[1] ^ shu[i];
    for (int i = 1; i <= n; ++i)
        cout << ans[i] << " ";
    return;
}
int main()
{
    cout.flush();
    cin >> n;
    for (int i = 2; i <= n; ++i)
    {
        cout << "XOR 1 " << i << "\n";
        cin >> shu[i];
    }
    for (int i = 2; i <= n; ++i)
        if (!shu[i])
        {
            cout << "AND 1 " << i << "\n";
            cin >> ans[1];
            work();
            return 0;
        }
    for (int i = 2; i <= n; ++i)
    {
        if (!pre[shu[i]])
            pre[shu[i]] = i;
        else
        {
            cout << "AND " << pre[shu[i]] << " " << i << "\n";
            int num;
            cin >> num;
            ans[1] = num ^ shu[i];
            work();
            return 0;
        }
    }
    int pos1 = 0, pos2 = 0;
    for (int i = 2; i <= n; ++i)
    {
        if (shu[i] == 1)
            pos1 = i;
        if (shu[i] == n - 2)
            pos2 = i;
    }
    cout << "OR 1 " << pos1 << "\n";
    int num = 0;
    cin >> num;
    ans[1] = num - (num & 1);
    cout << "OR 1 " << pos2 << "\n";
    cin >> num;
    ans[1] += num & 1;
    work();
}