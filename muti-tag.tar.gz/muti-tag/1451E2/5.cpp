﻿#undef local
#include <bits/stdc++.h>
#define all(v) v.begin(), v.end()
#define allr(v) v.rbegin(), v.rend()
#define fori(i, n) for (int i = 0; i < n; i++)
#define pb push_back
#define ll long long int
#define mod 1000000007
#define pi pair<int, int>
#define pll pair<ll, ll>
#define mp make_pair
#define fi first
#define se second
#define printVector(v)                                                                             \
    fori(i, v.size())                                                                              \
    {                                                                                              \
        cout << v[i] << " ";                                                                       \
    }                                                                                              \
    cout << endl;
using namespace std;
vector<vector<int> > ind;
vector<int> ans;
int ask(int op, int i, int j)
{
    int temp;
    if (op == 0)
    {
        cout << "OR " << i + 1 << " " << j + 1 << endl;
        cin >> temp;
    }
    else if (op == 1)
    {
        cout << "AND " << i + 1 << " " << j + 1 << endl;
        cin >> temp;
    }
    else
    {
        cout << "XOR " << i + 1 << " " << j + 1 << endl;
        cin >> temp;
    }
    return temp;
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n;
    cin >> n;
    ind.resize(n);
    ans.assign(n, -1);
    bool same = false;
    vector<int> xs(n, 0);
    for (int i = 0; i < n - 1; i++)
    {
        int t = ask(2, 0, i + 1);
        xs[i + 1] = t;
        if (ind[t].size() == 1 && !same)
        {
            same = true;
            ans[ind[t].back()] = ans[i + 1] = ask(1, ind[t].back(), i + 1);
            ind[t].pb(i + 1);
        }
        else
        {
            ind[t].pb(i + 1);
        }
    }
    if (same)
    {
        fori(i, n)
        {
            if (ans[i] != -1)
            {
                ans[0] = ans[i] ^ xs[i];
                fori(i, n - 1)
                {
                    ans[i + 1] = ans[0] ^ xs[i + 1];
                }
            }
        }
        cout << "! ";
        printVector(ans) return 0;
    }
    int temp = 1;
    if (temp == ind[n - 1].back())
        temp++;
    int a3 = ask(1, temp, ind[n - 1].back());
    int a1 = ask(1, temp, 0);
    int a2 = 0;
    int x1 = xs[temp];
    int x2 = xs[ind[n - 1].back()];
    int x3 = x1 ^ x2;
    int sum = x1 + x2 + x3 + 2 * (a1 + a2 + a3);
    sum = sum >> 1;
    sum -= x3 + 2 * a3;
    ans[0] = sum;
    fori(i, n - 1)
    {
        ans[i + 1] = ans[0] ^ xs[i + 1];
    }
    cout << "! ";
    printVector(ans)
}
