﻿#include <bits/stdc++.h>
using namespace std;
int ans[100010], n;
int x, y;
int check()
{
    for (int i = 2; i <= n; ++i)
        if (ans[i] == 0)
        {
            x = i;
            return 1;
        }
    map<int, int> m;
    for (int i = 2; i <= n; ++i)
    {
        if (m[ans[i]])
        {
            x = m[ans[i]], y = i;
            return 2;
        }
        m[ans[i]] = i;
    }
    return 3;
}
int main()
{
    ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
    cin >> n;
    for (int i = 2; i <= n; ++i)
    {
        cout << "XOR " << 1 << " " << i << endl;
        fflush(stdout);
        cin >> ans[i];
    }
    int f = check();
    if (f == 1)
    {
        cout << "AND " << 1 << " " << x << endl;
        fflush(stdout);
        cin >> ans[1];
        cout << "! " << ans[1] << " ";
        for (int i = 2; i <= n; ++i)
        {
            int s = ans[i] ^ ans[1];
            cout << s << " ";
        }
    }
    else if (f == 2)
    {
        cout << "AND " << x << " " << y << endl;
        fflush(stdout);
        cin >> x;
        x ^= ans[y];
        cout << "! ";
        cout << x << " ";
        for (int i = 2; i <= n; ++i)
        {
            int s = x ^ ans[i];
            cout << s << " ";
        }
    }
    else
    {
        int id1, id2;
        for (int i = 2; i <= n; ++i)
        {
            if (ans[i] == 1)
                id1 = i;
            if (ans[i] == 2)
                id2 = i;
        }
        cout << "AND " << 1 << " " << id1 << endl;
        fflush(stdout);
        cin >> x;
        cout << "AND " << 1 << " " << id2 << endl;
        fflush(stdout);
        cin >> y;
        ans[1] = x | y;
        cout << "! ";
        cout << ans[1] << " ";
        for (int i = 2; i <= n; ++i)
        {
            int s = ans[1] ^ ans[i];
            cout << s << " ";
        }
    }
    cout << endl;
}