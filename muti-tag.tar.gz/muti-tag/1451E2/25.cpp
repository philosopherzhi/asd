﻿#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<ll, ll> pii;
#define rep(i, x, y) for (int i = x; i < y; i++)
#define rept(i, x, y) for (int i = x; i <= y; i++)
#define pb push_back
#define mp make_pair
#define fi sirst
#define se second
#define all(x) x.begin(), x.end()
#define dd(x) cout << #x << "=" << x << " "
#define de(x) cout << #x << "=" << x << "\n"
#define mes(a, b) memset(a, b, sizeof a)
const int inf = 0x3f3f3f3f;
const int maxn = 1e5 + 5;
int a[maxn], ans[maxn];
int pos[maxn];

int main()
{
    ios::sync_with_stdio(false);
    int n;
    cin >> n;
    a[1] = 0;
    pos[0] = 1;
    rept(i, 2, n)
    {
        cout << "XOR 1 " << i << endl;
        cin >> a[i];
        if (pos[a[i]])
        {
            cout << "AND " << pos[a[i]] << " " << i << endl;
            cin >> ans[i];
            rep(j, 1, i)
            {
                ans[j] = ans[i] ^ a[j] ^ a[i];
            }
            rept(j, i + 1, n)
            {
                cout << "XOR " << i << " " << j << "\n";
                cin >> ans[j];
                ans[j] ^= ans[i];
            }
            cout << "!";
            rept(i, 1, n) cout << " " << ans[i];
            cout << "\n";
            return 0;
        }
        pos[a[i]] = i;
    }
    rept(i, 2, n)
    {
        if (a[i] == n - 1)
        {
            int ida = 1, idb = i, idc = 2;
            if (idc == idb)
                idc++;
            int ab = 0, ac, bc;
            cout << "AND " << ida << " " << idc << endl;
            cin >> ac;
            cout << "AND " << idb << " " << idc << endl;
            cin >> bc;
            int apb = a[idb] + ab * 2;
            int apc = a[idc] + ac * 2;
            int bpc = (a[idb] ^ a[idc]) + bc * 2;
            ans[ida] = (apb + apc + bpc) / 2 - bpc;
            // dd(ida);dd(idb);de(idc);dd(apb);dd(apc);dd(bpc);
            // ans[idb]=apb-ans[ida];
            // ans[idc]=apb-ans[ida];
            rept(j, 2, n)
            {
                ans[j] = ans[1] ^ a[j];
            }
            cout << "!";
            rept(j, 1, n) cout << " " << ans[j];
            cout << "\n";
            return 0;
        }
    }
    return 0;
}
