﻿#include <bits/stdc++.h>
using namespace std;
/*<DEBUG>*/
#define tem template <typename
#define can_shift(_X_, ...) enable_if_t<sizeof test<_X_>(0) __VA_ARGS__ 8, debug&> operator<<(T i)
#define _op debug& operator<<
tem C > auto test(C* x) -> decltype(cerr << *x, 0LL);
tem C > char test(...);
tem C > struct itr
{
    C begin, end;
};
tem C > itr<C> get_range(C b, C e)
{
    return itr<C>{ b, e };
}
struct debug
{
#ifdef _LOCAL
    ~debug()
    {
        cerr << endl;
    }
    tem T > can_shift(T, == )
    {
        cerr << boolalpha << i;
        return *this;
    }
    tem T > can_shift(T, != )
    {
        return *this << get_range(begin(i), end(i));
    }
    tem T, typename U > _op(pair<T, U> i)
    {
        return *this << "< " << i.first << " , " << i.second << " >";
    }
    tem T > _op(itr<T> i)
    {
        *this << "{ ";
        for (auto it = i.begin; it != i.end; it++)
        {
            *this << " , " + (it == i.begin ? 2 : 0) << *it;
        }
        return *this << " }";
    }
#else
    tem T > _op(const T&)
    {
        return *this;
    }
#endif
};

string _ARR_(int* arr, int sz)
{
    string ret = "{ " + to_string(arr[0]);
    for (int i = 1; i < sz; i++)
        ret += " , " + to_string(arr[i]);
    ret += " }";
    return ret;
}

#define exp(...) " [ " << #__VA_ARGS__ << " : " << (__VA_ARGS__) << " ]"
/*</DEBUG>*/

typedef long long ll;
typedef unsigned long long ull;
typedef unsigned int uint;
typedef pair<int, int> pii;
// mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());

#define pb push_back
#define FAST                                                                                       \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0);                                                                                    \
    cout.tie(0)
#define TC                                                                                         \
    int __TC__;                                                                                    \
    cin >> __TC__;                                                                                 \
    while (__TC__--)
#define ar array

const int INF = 1e9 + 7;

int query(int t, int i, int j)
{
    ++i;
    ++j;
    int ans;
    if (t == 0)
    {
        cout << "AND " << i << ' ' << j << endl;
        fflush(stdout);
        cin >> ans;
    }
    else if (t == 1)
    {
        cout << "OR " << i << ' ' << j << endl;
        fflush(stdout);
        cin >> ans;
    }
    else
    {
        cout << "XOR " << i << ' ' << j << endl;
        fflush(stdout);
        cin >> ans;
    }
    return ans;
}

int main(void)
{
    int n;
    cin >> n;
    vector<ar<int, 2>> xr(n);
    xr[0] = { -INF, -INF };
    vector<int> ans(n);

    for (int i = 1; i < n; ++i)
    {
        xr[i] = { query(2, 0, i), i };
    }
    sort(xr.begin(), xr.end());

    int fst = 0;
    bool found = 0;

    for (int i = 1; i < n - 1; ++i)
    {
        if (xr[i][0] == xr[i + 1][0])
        {
            assert(query(2, xr[i][1], xr[i + 1][1]) == 0);
            fst = xr[i][0] ^ query(0, xr[i][1], xr[i + 1][1]);
            found = 1;
            break;
        }
    }

    assert(xr[1][0] >= 0);
    if (xr[1][0] == 0 && !found)
    {
        assert(query(2, xr[1][1], 0) == 0);
        fst = query(0, xr[1][1], 0);
        found = 1;
    }

    if (!found)
    {
        assert(xr[n - 1][0] == n - 1);
        int aandc = 0, aandb = query(0, 0, xr[n - 2][1]),
            bandc = query(0, xr[n - 1][1], xr[n - 2][1]);
        int axorc = n - 1, axorb = xr[n - 2][0], bxorc = (xr[n - 2][0] ^ xr[n - 1][0]);
        int aplusc = n - 1, aplusb = axorb + 2 * aandb, bplusc = bxorc + 2 * bandc;
        fst = aplusc + aplusb - bplusc;
        fst /= 2;
    }

    debug() << exp(fst);
    ans[0] = fst;
    for (int i = 1; i < n; ++i)
    {
        ans[xr[i][1]] = xr[i][0] ^ fst;
    }

    cout << "! ";
    for (int i = 0; i < n; ++i)
        cout << ans[i] << ' ';
    cout << endl;


    return 0;
}
