﻿#include <cmath>
#include <cstring>
#include <iostream>
#include <map>
#include <queue>
#include <vector>

using namespace std;
#define N 1 << 17

map<int, int> m;
int ans[N];

int main()
{
    int n;
    scanf("%d", &n);
    int flag = false;
    int id1 = 0, id2 = 0;
    for (int i = 2; i <= n; i++)
    {
        printf("XOR 1 %d\n", i);
        cout.flush();
        int x;
        scanf("%d", &x);
        if (x == 0)
        {
            flag = true;
            id1 = 1;
            id2 = i;
        }
        if (m.find(x) != m.end())
        {
            flag = true;
            id1 = m[x];
            id2 = i;
        }
        m[x] = i;
        ans[i] = x;
    }
    if (flag)
    {
        printf("AND %d %d\n", id1, id2);
        cout.flush();
        int x;
        scanf("%d", &x);
        if (id1 != 1)
            x ^= ans[id1];
        printf("!");
        for (int i = 1; i <= n; i++)
            printf(" %d", x ^ ans[i]);
        puts("");
        cout.flush();
    }
    else
    {
        int id1 = m[1], id2 = m[n - 2];
        printf("OR %d %d\n", 1, id1);
        cout.flush();
        int ans1;
        scanf("%d", &ans1);
        printf("OR %d %d\n", 1, id2);
        cout.flush();
        int ans2;
        scanf("%d", &ans2);
        for (int i = 0; i < n; i++)
        {
            if ((i | (1 ^ i)) == ans1 && (i | ((n - 2) ^ i)) == ans2)
            {
                printf("!");
                for (int j = 1; j <= n; j++)
                    printf(" %d", i ^ ans[j]);
                puts("");
                cout.flush();
                break;
            }
        }
    }
    return 0;
}