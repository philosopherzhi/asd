﻿#include <bits/stdc++.h>
#define DEBUG cerr << "Passing Line " << __LINE__ << " in Function [" << __FUNCTION__ << "].\n";
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;

const int INF = 0x3f3f3f3f;
const ll llINF = 1e18;

int n;
int a[1 << 17], ans[1 << 17];
vector<int> vec[1 << 17];

void SolveZero(int x)
{
    cout << "AND " << 1 << " " << x << endl;
    fflush(stdout);
    int t;
    cin >> t;
    ans[1] = ans[x] = t;
    for (int i = 2; i <= n; i++)
        ans[i] = ans[1] ^ a[i];
    cout << "! ";
    for (int i = 1; i <= n; i++)
        cout << ans[i] << " ";
    cout << endl;
    fflush(stdout);
}

void SolveEqual(int x, int y)
{
    if (x > y)
        swap(x, y);
    cout << "AND " << x << " " << y << endl;
    fflush(stdout);
    int t;
    cin >> t;
    ans[x] = ans[y] = t;
    ans[1] = a[x] ^ ans[x];
    for (int i = 2; i <= n; i++)
        ans[i] = ans[1] ^ a[i];
    cout << "! ";
    for (int i = 1; i <= n; i++)
        cout << ans[i] << " ";
    cout << endl;
    fflush(stdout);
}

int main()
{
    cin >> n;
    for (int i = 2; i <= n; i++)
    {
        cout << "XOR " << 1 << " " << i << endl;
        fflush(stdout);
        cin >> a[i];
    }
    for (int i = 2; i <= n; i++)
    {
        if (a[i] == 0)
        {
            SolveZero(i);
            return 0;
        }
        vec[a[i]].push_back(i);
    }
    for (int i = 0; i < n; i++)
    {
        if ((int)vec[i].size() >= 2)
        {
            SolveEqual(vec[i][0], vec[i][1]);
            return 0;
        }
    }
    int xor1, xor2;
    for (int i = 2; i <= n; i++)
    {
        if (a[i] == 1)
            xor1 = i;
        if (a[i] == 2)
            xor2 = i;
    }
    cout << "AND " << 1 << " " << xor1 << endl;
    fflush(stdout);
    int x, y;
    cin >> x;
    cout << "AND " << 1 << " " << xor2 << endl;
    fflush(stdout);
    cin >> y;
    ans[1] = x | y;
    for (int i = 2; i <= n; i++)
        ans[i] = ans[1] ^ a[i];
    cout << "! ";
    for (int i = 1; i <= n; i++)
        cout << ans[i] << " ";
    cout << endl;
    fflush(stdout);
    return 0;
}