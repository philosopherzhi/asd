﻿// Author : MatrixCascade

#include <bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define clr(f, n) memset(f, 0, sizeof(int) * (n))
#define cpy(f, g, n) memcpy(f, g, sizeof(int) * (n))
#define rev(f, n) reverse(f, f + n)
#define pir pair<int, int>
#define mkp make_pair
#define fst it->first
#define sec it->second
#define int long long
#define up(i, x, y) for (int i = x, i##end = y; i <= i##end; ++i)
#define down(i, x, y) for (int i = x, i##end = y; i >= i##end; --i)
using namespace std;
int n, m, k;
int read()
{
    int s = 0, f = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9')
    {
        if (ch == '-')
            f = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9')
    {
        s = s * 10 + ch - '0';
        ch = getchar();
    }
    return s * f;
}
inline void print(int* f, int len)
{
    for (int i = 0; i < len; i++)
        printf("%lld ", f[i]);
    puts("");
}
int c[100001], a[100001];
int b[101010];
int p1, p2, flag;
signed main()
{
    n = read();
    up(i, 2, n)
    {
        cout << "XOR 1 " << i << endl;
        c[i] = read();
        if (b[c[i]] && flag == 0)
        {
            p1 = b[c[i]];
            p2 = i;
            flag = 1;
        }
        b[c[i]] = i;
    }
    if (flag)
    {
        int w;
        cout << "AND " << p1 << " " << p2 << endl;
        cin >> w;
        a[p1] = a[p2] = w;
        a[1] = w ^ c[p1];
        up(i, 2, n) a[i] = a[1] ^ c[i];
        cout << "! ";
        up(i, 1, n) cout << a[i] << " ";
        cout << endl;
        return 0;
    }
    up(i, 2, n)
    {
        if (c[i] == 0)
        {
            cout << "AND " << 1 << " " << i << endl;
            int w;
            cin >> w;
            a[1] = w;
            up(i, 2, n) a[i] = a[1] ^ c[i];
            cout << "! ";
            up(i, 1, n) cout << a[i] << " ";
            cout << endl;
            return 0;
        }
    }
    int u1, u2;
    up(i, 2, n)
    {
        if (c[i] == 1)
            u1 = i;
        if (c[i] == n - 1)
            u2 = i;
    }
    int q = 0;
    cout << "AND 1 " << u1 << endl;
    cin >> q;
    a[1] = q;
    cout << "AND " << u1 << " " << u2 << endl;
    cin >> q;
    a[1] += (1 - q % 2);
    up(i, 2, n) a[i] = a[1] ^ c[i];
    cout << "! ";
    up(i, 1, n) cout << a[i] << " ";
    cout << endl;
    return 0;
}
