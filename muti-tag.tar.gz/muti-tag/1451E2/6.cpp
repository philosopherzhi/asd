﻿#include "bits/stdc++.h"
using namespace std;
#define ll long long
#define ul unsigned long long
#define ui unsigned int
#define ri register int
#define pb push_back
#define mp make_pair
char p[30] = { '0', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
    'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
inline ll rd()
{
    ll x = 0, flag = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9')
    {
        if (ch == '-')
            flag = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9')
    {
        x = x * 10 + (ch ^ 48);
        ch = getchar();
    }
    return x * flag;
}
inline void op1(int x, int y)
{ //&
    cout << "AND"
         << " " << x << " " << y << endl;
}
inline void op2(int x, int y)
{ //|
    cout << "OR"
         << " " << x << " " << y << endl;
}
inline void op3(int x, int y)
{ // xor
    cout << "XOR"
         << " " << x << " " << y << endl;
}
#define N 1000010
int c[N], yy, ans[N], vis[N], n;
int main()
{
    ios::sync_with_stdio(false);
    cin >> n;
    int num = 0, tmp = n;
    while (tmp)
        num++, tmp /= 2;
    int flg1 = -1, flg2 = -1;
    for (ri i = 2; i <= n; ++i)
    {
        op3(1, i);
        cin >> c[i];
        if (!vis[c[i]])
            vis[c[i]] = i;
        else
            flg1 = vis[c[i]], flg2 = i;
    }
    for (ri i = 2; i <= n; ++i)
    {
        if (c[i] == 0)
        {
            flg1 = 1, flg2 = i;
            break;
        }
    } // n-1
    if (flg1 != -1 && flg2 != -1)
    {
        op1(flg1, flg2);
        cin >> ans[flg1];
        ans[flg2] = ans[flg1];
        ans[1] = ans[flg1] ^ c[flg1];
        // cout<<ans[1]<<endl;
        for (ri i = 2; i <= n; ++i)
            ans[i] = ans[1] ^ c[i];
        cout << "!"
             << " ";
        for (ri i = 1; i <= n; ++i)
            cout << ans[i] << " ";
        cout << endl;
        return 0;
    }
    else
    {
        int pos = -1;
        for (ri i = 2; i <= n; ++i)
            if (c[i] == 1)
                pos = i;
        int nxt = pos + 1;
        if (nxt > n)
            nxt -= 2;
        op1(1, pos);
        cin >> yy;
        for (ri i = 0; i < num; ++i)
            if (yy & (1 << i))
                ans[1] += (1 << i);
        int val = c[pos] ^ c[nxt];
        if (val & 1)
        {
            int v;
            op1(1, nxt);
            cin >> v;
            if (v & 1)
                ans[1]++;
        }
        else
        {
            int v;
            op1(pos, nxt);
            cin >> v;
            if (!(v & 1))
                ans[1]++;
        }
        for (ri i = 2; i <= n; ++i)
            ans[i] = ans[1] ^ c[i];
        cout << '!' << " ";
        for (ri i = 1; i <= n; ++i)
            cout << ans[i] << " ";
        cout << endl;
    }
    return 0;
}
