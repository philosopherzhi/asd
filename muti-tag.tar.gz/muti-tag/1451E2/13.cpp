﻿#include <bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n;
    cin >> n;
    int x[n + 1] = { 0 };
    for (int i = 1; i < n; ++i)
    {
        cout << "XOR " << i << " " << i + 1 << "\n" << flush;
        cin >> x[i];
        x[i] ^= x[i - 1];
    }
    int y[n];
    memset(y, 0, sizeof y);
    int l = -1, r = -1;
    for (int i = 1; i < n; ++i)
    {
        if (!x[i])
        {
            l = 1;
            r = i + 1;
            break;
        }
        if (y[x[i]])
        {
            l = y[x[i]] + 1;
            r = i + 1;
            break;
        }
        y[x[i]] = i;
    }
    int a[n + 1];
    memset(a, 0, sizeof a);
    if (l != -1)
    {
        cout << "AND " << l << " " << r << "\n" << flush;
        cin >> a[l];
        for (int i = l; i < n; ++i)
        {
            a[i + 1] = a[i] ^ x[i] ^ x[i - 1];
        }
        for (int i = l - 1; i > 0; --i)
        {
            a[i] = a[i + 1] ^ x[i] ^ x[i - 1];
        }
        cout << "! ";
        for (int i = 1; i <= n; ++i)
        {
            cout << a[i] << " ";
        }
        cout << "\n" << flush;
        return 0;
    }
    int o = 0, e = 0;
    for (int i = 1; i < n; ++i)
    {
        if (x[i] == 1)
        {
            cout << "AND " << 1 << " " << i + 1 << "\n" << flush;
            cin >> o;
        }
        else if (x[i] == 2)
        {
            cout << "AND " << 1 << " " << i + 1 << "\n" << flush;
            cin >> e;
        }
    }
    a[1] = o | e;
    for (int i = 1; i < n; ++i)
    {
        a[i + 1] = a[i] ^ x[i] ^ x[i - 1];
    }
    cout << "! ";
    for (int i = 1; i <= n; ++i)
    {
        cout << a[i] << " ";
    }
    cout << "\n" << flush;
    return 0;
}
