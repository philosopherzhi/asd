﻿#include <bits/stdc++.h>
using namespace std;

const int N = (1 << 16) + 10;
int n, flag, a[N], b[N], pos[N];

int main()
{
    scanf("%d", &n);
    pos[0] = 1;
    for (int i = 2; i <= n; i++)
    {
        printf("XOR 1 %d\n", i);
        fflush(stdout);
        scanf("%d", &a[i]);
        if (pos[a[i]])
            flag = pos[a[i]];
        pos[a[i]] = i;
    }
    if (flag)
    {
        printf("OR %d %d\n", flag, pos[a[flag]]);
        fflush(stdout);
        scanf("%d", &b[flag]);
        b[pos[a[flag]]] = b[flag];
        b[1] = a[flag] ^ b[flag];
    }
    else
    {
        int x = 0, y = 0;
        for (int i = 2; i <= n; i++)
        {
            if (a[i] == 1)
            {
                printf("OR 1 %d\n", i);
                fflush(stdout);
                scanf("%d", &x);
            }
            if (a[i] == (n >> 1))
            {
                printf("OR 1 %d\n", i);
                fflush(stdout);
                scanf("%d", &y);
            }
        }
        b[1] = ((x >> 1) << 1) | (y & 1);
    }
    printf("! %d", b[1]);
    for (int i = 2; i <= n; i++)
        printf(" %d", b[1] ^ a[i]);
    fflush(stdout);
    return 0;
}