﻿#include <bits/stdc++.h>
using namespace std;

int main()
{
    cout.flush();
    int n, tmp;
    cin >> n;
    vector<int> res(n);
    vector<int> ans(n);
    vector<int> cnt[n + 1];
    for (int i = 1; i < n; i++)
    {
        cout << "XOR " << 1 << ' ' << i + 1 << '\n';
        cin >> res[i];
    }
    cnt[0].push_back(0);
    for (int i = 1; i < n; i++)
        cnt[res[i]].push_back(i);
    for (int i = 0; i < n; i++)
        if (cnt[i].size() > 1)
        {
            cout << "AND " << cnt[i][0] + 1 << ' ' << cnt[i][1] + 1 << '\n';
            cin >> tmp;
            ans[0] = (res[cnt[i][0]] ^ tmp);
            for (int j = 1; j < n; j++)
                ans[j] = (res[j] ^ ans[0]);
            cout << "! ";
            for (int j = 0; j < n; j++)
                cout << ans[j] << ' ';
            return 0;
        }
    for (int j = 1; j < n; j++)
    {
        int k;
        if (res[j] == n - 1)
        {
            if (j == 1)
                k = 2;
            else
                k = 1;
            int sum12 = n - 1;
            int xor13 = res[k];
            int xor23 = (res[j] ^ res[k]);
            int and13, and23;
            cout << "AND " << j + 1 << ' ' << k + 1 << '\n';
            cin >> and23;
            cout << "AND " << 1 << ' ' << k + 1 << '\n';
            cin >> and13;
            int sum13 = xor13 + 2 * and13;
            int sum23 = xor23 + 2 * and23;
            ans[0] = (sum12 + sum13 - sum23) / 2;
            for (int j = 1; j < n; j++)
                ans[j] = (res[j] ^ ans[0]);
            cout << "! ";
            for (int j = 0; j < n; j++)
                cout << ans[j] << ' ';
            return 0;
        }
    }
    // your code goes here
    return 0;
}