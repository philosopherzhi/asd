﻿#include <bits/stdc++.h>
using namespace std;

#define ll long long int
#define pb push_back
#define fi first
#define se second
#define mp make_pair
#define mt make_tuple
#define all(A) A.begin(), A.end()
#define sz(A) (int) A.size()
typedef vector<int> vi;
typedef vector<ll> vl;
typedef pair<int, int> pii;
typedef tuple<int, int, int> tii;
const ll mod = 1e9 + 7;
// const ll mod = 998244353;
const int inf = 1e9;
// const ll inf = 1e18;
const int N = 2e5;

void solve()
{
    int n;
    cin >> n;
    int a[n + 1];
    int x = -1, y = -1;
    int pos[n];
    memset(pos, -1, sizeof pos);
    for (int i = 2; i <= n; i++)
    {
        cout << "XOR " << 1 << ' ' << i << endl;
        cin >> a[i];
        if (a[i] == 0)
        {
            x = 1, y = i;
        }
        else if (pos[a[i]] != -1)
        {
            x = pos[a[i]], y = i;
        }
        pos[a[i]] = i;
    }
    int arr[n + 1];
    if (x != -1)
    {
        cout << "AND " << x << ' ' << y << endl;
        cin >> arr[x];
        if (x != 1)
        {
            arr[1] = arr[x] ^ a[x];
        }
        for (int i = 2; i <= n; i++)
        {
            arr[i] = arr[1] ^ a[i];
        }
        cout << "! ";
        for (int i = 1; i <= n; i++)
        {
            cout << arr[i] << ' ';
        }
        cout << endl;
    }
    else
    {
        int p, q;
        cout << "AND " << 1 << ' ' << pos[1] << endl;
        cin >> p;
        cout << "AND " << 1 << ' ' << pos[n - 2] << endl;
        cin >> q;
        arr[1] = p + q;
        cout << "! " << arr[1] << ' ';
        for (int i = 2; i <= n; i++)
        {
            cout << (a[i] ^ arr[1]) << ' ';
        }
        cout << endl;
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    // #ifndef ONLINE_JUDGE
    //   freopen("in.txt", "r", stdin);
    // #endif
    int t = 1;
    while (t--)
    {
        solve();
    }
    return 0;
}