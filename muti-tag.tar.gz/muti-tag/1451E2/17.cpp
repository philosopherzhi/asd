﻿#include <iostream>
#include <vector>
#include <cmath>
#include <string>
#include <algorithm>
#define LL long long
using namespace std;
const int N = 2e5 + 6;
struct Node
{
    int id, value;
    Node()
    {
    }
    Node(int i, int v)
    {
        id = i;
        value = v;
    }
};
Node A[N];
int B[N];
bool cmp(Node a, Node b)
{
    return a.value < b.value;
}
int query(string str, int x, int y)
{
    cout << str << " " << x << " " << y << endl;
    int res = 0;
    cin >> res;
    return res;
}
int main()
{
    cin.tie(0); //取消cin的同步
    cout.tie(0); //取消cout的同步
    std::ios::sync_with_stdio(false); //优化
    int n;
    cin >> n;
    for (int i = 1; i <= n - 1; i++)
    {
        A[i].id = i + 1;
        A[i].value = query("XOR", 1, i + 1);
    }
    sort(A + 1, A + n, cmp);
    bool flag = false;
    int xx = 0;
    for (int i = 2; i <= n - 1; i++)
    {
        if (A[i].value == A[i - 1].value)
        {
            flag = 1;
            xx = i;
            break;
        }
    }
    if (flag)
    {
        B[1] = query("AND", A[xx - 1].id, A[xx].id) xor A[xx].value;
    }
    else
    {
        if (A[1].value == 0)
        {
            B[1] = query("AND", 1, A[1].id);
        }
        else
        {
            int x = A[1].id, y = A[3].id;
            B[1] = query("AND", 1, x);
            int temp = query("AND", x, y);
            if ((temp & 1) == 0)
                B[1] = B[1] | 1;
        }
    }
    for (int i = 1; i <= n - 1; i++)
    {
        B[A[i].id] = B[1] xor A[i].value;
    }
    cout << '!';
    for (int i = 1; i <= n; i++)
        cout << ' ' << B[i];
    cout << endl;
    cout.flush();
    return 0;
}