﻿#include <bits/stdc++.h>
using namespace std;

#define int long long

const int N = 1e6 + 5;

int n, a[N], b[N];

signed main()
{
    ios::sync_with_stdio(false);

    cin >> n;

    int flag = 0, p_1 = 1, p_2 = 1, same_flag = 0, same_a, same_b;

    map<int, int> mp;

    for (int i = 2; i <= n; i++)
    {
        cout << "XOR " << 1 << " " << i << endl;
        cout.flush();
        cin >> b[i];
        if (mp[b[i]])
        {
            same_flag = 1;
            same_a = mp[b[i]];
            same_b = i;
        }
        mp[b[i]] = i;
        if (b[i] == 0)
            flag = i;
        if (b[i] == 1)
            p_1 = i;
        if (b[i] == n - 2)
            p_2 = i;
    }

    if (flag)
    {
        cout << "AND " << 1 << " " << flag << endl;
        cout.flush();
        cin >> a[1];
        for (int i = 2; i <= n; i++)
            a[i] = b[i] ^ a[1];
        cout << "! ";
        for (int i = 1; i <= n; i++)
            cout << a[i] << " ";
        cout << endl;
    }
    else if (same_flag)
    {
        cout << "AND " << same_a << " " << same_b << endl;
        cout.flush();
        cin >> a[same_a];
        a[1] = a[same_a] ^ b[same_a];
        for (int i = 2; i <= n; i++)
            a[i] = b[i] ^ a[1];
        cout << "! ";
        for (int i = 1; i <= n; i++)
            cout << a[i] << " ";
        cout << endl;
    }
    else
    {
        cout << "AND " << 1 << " " << p_1 << endl;
        cout.flush();
        int t1, t2;
        cin >> t1;
        cout << "AND " << 1 << " " << p_2 << endl;
        cout.flush();
        cin >> t2;
        a[1] = ((t1 >> 1) << 1) | (t2 & 1);
        for (int i = 2; i <= n; i++)
            a[i] = b[i] ^ a[1];
        cout << "! ";
        for (int i = 1; i <= n; i++)
            cout << a[i] << " ";
        cout << endl;
    }
}