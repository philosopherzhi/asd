﻿#include <bits/stdc++.h>
using namespace std;
set<int> doub, rem, lgt;
int64_t sumd, sumr;
int n, t, x, tmp, tmp2;
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cin >> n;
    for (int i = 1; i <= n; ++i)
    {
        cin >> t >> x;
        if (x > 0)
        {
            rem.insert(x);
            sumr += x;
            if (t == 1)
                lgt.insert(x);
        }

        else
        {
            x *= -1;
            if (doub.count(x))
            {
                doub.erase(x);
                sumd -= x;
            }
            else
            {
                rem.erase(x);
                sumr -= x;
            }
            if (t == 1)
                lgt.erase(x);
        }

        while (doub.size() > lgt.size() && !doub.empty())
        {
            tmp = *doub.begin();
            doub.erase(tmp);
            rem.insert(tmp);
            sumd -= tmp;
            sumr += tmp;
        }

        while (doub.size() < lgt.size() && !rem.empty())
        {
            tmp = *rem.rbegin();
            doub.insert(tmp);
            rem.erase(--rem.end());
            sumd += tmp;
            sumr -= tmp;
        }

        while (!doub.empty() && !rem.empty() && *doub.begin() < *rem.rbegin())
        {
            tmp = *doub.begin();
            tmp2 = *rem.rbegin();
            doub.erase(tmp);
            doub.insert(tmp2);
            rem.erase(tmp2);
            rem.insert(tmp);
            sumd -= tmp;
            sumd += tmp2;
            sumr -= tmp2;
            sumr += tmp;
        }

        if (!lgt.empty() && *lgt.begin() == *doub.begin())
        {
            tmp = *doub.begin();
            tmp2 = 0;
            if (!rem.empty())
                tmp2 = *rem.rbegin();
            cout << 2 * (sumd - tmp + tmp2) + (sumr - tmp2 + tmp) << '\n';
        }
        else
            cout << 2 * sumd + sumr << '\n';
    }
}