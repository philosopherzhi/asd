﻿#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>
#include <queue>
#include <set>
#include <map>
#include <cstdlib>

using namespace std;

#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define li long long
#define pii pair<int, int>
#define vi vector<int>
#define li long long

#define forn(i, n) for (int i = 0; i < (int)n; i++)
#define fore(i, b, e) for (int i = (int)b; i <= (int)e; i++)

const int INF = 2e9;

multiset<int> strong, weak;
li ans = 0;
multiset<int> fire;
int lightning;

void add_strong(int x)
{
    strong.insert(x);
    ans += 2 * x;
}

void add_weak(int x)
{
    weak.insert(x);
    ans += x;
}

void remove_strong(int x)
{
    // cerr << "remove strong" << x << endl;
    strong.erase(strong.find(x));
    ans -= 2 * x;
}

void remove_weak(int x)
{
    // cerr << "remove weak" << x << endl;
    weak.erase(weak.find(x));
    ans -= x;
}

void transfer_from_weak()
{
    // cout << "transfer_from_weak" << endl;
    if (!weak.empty())
    {
        int x = *weak.rbegin();
        remove_weak(x);
        add_strong(x);
    }
}

void transfer_from_strong()
{
    // cout << "transfer_from_strong" << endl;
    if (!strong.empty())
    {
        int x = *strong.begin();
        remove_strong(x);
        add_weak(x);
    }
}

int get_first(const multiset<int>& x)
{
    return x.empty() ? INF : *x.begin();
}

void balance()
{
    // cerr << "balance" << endl;
    while (strong.size() < lightning)
    {
        transfer_from_weak();
    }
    while (strong.size() > lightning)
    {
        transfer_from_strong();
    }
}

int main()
{
    int q;
    scanf("%d", &q);
    forn(query, q)
    {
        int typ, power;
        scanf("%d%d", &typ, &power);
        // cerr << typ << " " << power << endl;
        if (power > 0)
        {
            if (power >= get_first(strong))
            {
                add_strong(power);
            }
            else
            {
                add_weak(power);
            }
            if (typ == 1)
            {
                lightning++;
            }
            else
            {
                fire.insert(power);
            }
            /*if (power > get_first(strong)) {
                    int x = *strong.begin();
                    remove_strong(x);
                    add_strong(power);
                    add_weak(x);
            } else {
                    add_weak(power);
            }
            if (typ == 1) {
                    transfer_from_weak();
            }*/
        }
        if (power < 0)
        {
            power = -power;
            if (power >= get_first(strong))
            {
                remove_strong(power);
            }
            else
            {
                remove_weak(power);
            }
            if (typ == 1)
            {
                lightning--;
            }
            else
            {
                fire.erase(fire.find(power));
            }
        }
        balance();
        int best_fire = fire.empty() ? 0 : *fire.rbegin();
        if (!strong.empty() && best_fire < *strong.begin())
        {
            // cerr << "correction" << endl;
            li corrected = ans - *strong.begin() + best_fire;
            printf("%lld\n", corrected);
        }
        else
        {
            printf("%lld\n", ans);
        }
    }
}