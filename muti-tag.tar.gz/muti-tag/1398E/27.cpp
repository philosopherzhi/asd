﻿#include <iostream>
#include <vector>
#include <assert.h>
#include <cmath>
#include <algorithm>
#include <set>
using namespace std;
typedef long long ll;

int main()
{

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int n;
    cin >> n;
    ll res = 0, lightcnt = 0;
    set<ll> fire, notdoubled, doubled;

    while (n--)
    {
        ll tp, d;
        cin >> tp >> d;
        res += d;
        if (d > 0)
        {
            if (tp == 1)
                lightcnt++;
            else
                fire.insert(d);
            if (notdoubled.size() > 0 && d <= *notdoubled.rbegin())
                notdoubled.insert(d);
            else
                doubled.insert(d), res += d;
        }
        else
        {
            if (tp == 1)
                lightcnt--;
            else
                fire.erase(-d);
            if (notdoubled.size() > 0 && -d <= *notdoubled.rbegin())
                notdoubled.erase(-d);
            else
                doubled.erase(-d), res += d;
        }
        while (doubled.size() > lightcnt)
        {
            int x = *doubled.begin();
            notdoubled.insert(x);
            doubled.erase(x);
            res -= x;
        }
        while (doubled.size() < lightcnt)
        {
            int x = *notdoubled.rbegin();
            doubled.insert(x);
            notdoubled.erase(x);
            res += x;
        }
        ll x = 0;
        if (doubled.size())
        {
            if (fire.size())
                x = min(x, *fire.rbegin() - *doubled.begin());
            else
                x = 0 - *doubled.begin();
        }
        cout << res + x << endl;
    }


    return 0;
}