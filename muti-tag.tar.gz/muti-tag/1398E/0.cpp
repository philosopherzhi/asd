﻿#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll sum, sum_big;
set<ll> big, small, A, B;
void add(int x)
{
    sum += x;
    if (big.empty() || x < *big.begin())
    {
        small.insert(x);
    }
    else
    {
        big.insert(x);
        sum_big += x;
    }
}
void remove(int x)
{
    sum -= x;
    if (small.count(x))
    {
        small.erase(x);
    }
    else
    {
        big.erase(x);
        sum_big -= x;
    }
}
ll calc()
{
    while ((int)big.size() < (int)B.size())
    {
        ll x = *small.rbegin();
        big.insert(x);
        small.erase(x);
        sum_big += x;
    }
    while ((int)big.size() > (int)B.size())
    {
        ll x = *big.begin();
        small.insert(x);
        big.erase(x);
        sum_big -= x;
    }
    ll ans = sum + sum_big;
    if (!B.empty() && (A.empty() || *A.rbegin() < *B.begin()))
    {
        ans -= *B.begin();
        if (!A.empty())
        {
            ans += *A.rbegin();
        }
    }
    return ans;
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int q;
    cin >> q;
    while (q--)
    {
        int type, damage;
        cin >> type >> damage;
        if (damage < 0)
        {
            damage = -damage;
            remove(damage);
            if (type == 0)
            {
                A.erase(damage);
            }
            else
            {
                B.erase(damage);
            }
        }
        else
        {
            add(damage);
            if (type == 0)
            {
                A.insert(damage);
            }
            else
            {
                B.insert(damage);
            }
        }
        cout << calc() << '\n';
    }
}
