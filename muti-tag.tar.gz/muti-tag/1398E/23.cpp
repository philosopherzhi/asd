﻿#include <bits/stdc++.h>
#define T                                                                                          \
    int t;                                                                                         \
    cin >> t;                                                                                      \
    while (t--)
#define ff first
#define ss second
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;

void solve()
{
    int n;
    cin >> n;
    set<pii> general, doubled;
    ll gen_sum = 0, doub_sum = 0;
    int cnt_l = 0, cnt_f = 0;
    while (n--)
    {
        int tp, d;
        cin >> tp >> d;
        if (d < 0)
        {
            d = -d;
            if (tp)
                cnt_l--;
            if (general.find({ d, tp }) != general.end())
            {
                general.erase({ d, tp });
                gen_sum -= d;
            }
            else
            {
                doubled.erase({ d, tp });
                doub_sum -= d;
                if (!tp)
                    cnt_f--;
            }
        }
        else
        {
            if (tp)
                cnt_l++;
            general.insert({ d, tp });
            gen_sum += d;
        }
        while (doubled.size() < cnt_l)
        {
            pii el = *general.rbegin();
            doubled.insert(el);
            if (!el.ss)
                cnt_f++;
            gen_sum -= el.ff;
            doub_sum += el.ff;
            general.erase(*general.rbegin());
        }
        while (cnt_l < doubled.size())
        {
            pii el = *doubled.begin();
            doubled.erase(el);
            if (!el.ss)
                cnt_f--;
            gen_sum += el.ff;
            doub_sum -= el.ff;
            general.insert(el);
        }
        while (doubled.size() && general.size() && (*doubled.begin()).ff < (*general.rbegin()).ff)
        {
            pii d_el = *doubled.begin(), g_el = *general.rbegin();
            if (!g_el.ss)
                cnt_f++;
            if (!d_el.ss)
                cnt_f--;
            gen_sum += d_el.ff - g_el.ff;
            doub_sum += g_el.ff - d_el.ff;
            doubled.erase(d_el);
            general.erase(g_el);
            doubled.insert(g_el);
            general.insert(d_el);
        }
        ll ans = gen_sum + doub_sum * 2;
        if (!cnt_f)
        {
            if (general.size() && cnt_l)
                ans += (*general.rbegin()).ff;
            if (doubled.size())
                ans -= (*doubled.begin()).ff;
        }
        cout << ans << '\n';
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cout << setprecision(12);
    cin.tie(0);
    cout.tie(0);
    solve();
    return 0;
}