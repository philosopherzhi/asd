﻿
#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define all(x) x.begin(), x.end()
#define pb push_back
#define mp make_pair
#define ps push
#define in insert
#define f first
#define s second
#define ca(v)                                                                                      \
    for (auto i : v)                                                                               \
        cout << i << " ";
#define cap(v)                                                                                     \
    for (auto i : v)                                                                               \
        cout << i.f << "|" << i.s << " ";
#define nl cout << "\n"
#define gcd(a, b) __gcd(a, b)
#define lcm(a, b) (a * b / gcd(a, b))
int xm[4] = { -1, 1, 0, 0 };
int ym[4] = { 0, 0, -1, 1 };
const int MOD = 1e9 + 7;
const int MAXN = 5e5 + 5;
const ll POW = 9973;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int n;
    cin >> n;
    ll tot = 0;
    multiset<pair<int, int>> paired;
    multiset<int> availible[2];
    int fire = 0;
    int light = 0;
    int firein = 0;
    for (int i = 0; i < n; i++)
    {
        int id;
        ll val;
        cin >> id >> val;
        if (val < 0)
        {
            if (id == 0)
                fire--;
            else
                light--;
            val = val * -1;
            tot -= val;
            if (paired.find(mp(val, id)) != paired.end())
            {
                paired.erase(paired.find(mp(val, id)));
                if (id == 0)
                    firein--;
                tot -= val;
            }
            else
                availible[id].erase(availible[id].find(val));
            while (paired.size() > light)
            {
                auto p = (*paired.begin());
                tot -= p.f;
                availible[p.s].in(p.f);
                paired.erase(*paired.begin());
                if (p.s == 0)
                    firein--;
            }
            if (firein == 0 && paired.size() > 0)
            {
                auto p = *paired.begin();
                tot -= p.f;
                availible[p.s].in(p.f);
                paired.erase(paired.begin());
            }
        }
        else
        {
            tot += val;
            availible[id].in(val);
            if (paired.size() > 0)
            {
                auto p = *paired.begin();
                if (p.s == 0)
                    firein--;
                availible[p.s].in(p.f);
                tot -= p.f;
                paired.erase(paired.begin());
            }
            if (id == 0)
                fire++;
            else
                light++;
        }
        if (firein == 0 && availible[0].size() && light > 0)
        {
            firein++;
            auto it = --availible[0].end();
            paired.in(mp(*it, 0));
            tot += *it;
            availible[0].erase(it);
        }
        while ((light - ((firein == 0) ? 1 : 0)) > (int)paired.size())
        {
            int add1 = 0;
            int add2 = 0;
            if (availible[0].size() > 0)
                add1 = *availible[0].rbegin();
            if (availible[1].size() > 0)
                add2 = *availible[1].rbegin();
            if (add1 + add2 == 0)
                break;
            if (add1 >= add2)
            {
                paired.in(mp(add1, 0));
                availible[0].erase(--availible[0].end());
                tot += add1;
                firein++;
            }
            else
            {
                paired.in(mp(add2, 1));
                availible[1].erase(--availible[1].end());
                tot += add2;
            }
        }
        cout << tot << "\n";
    }
}
