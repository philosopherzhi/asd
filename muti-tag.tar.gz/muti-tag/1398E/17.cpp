﻿#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define ull unsigned long long
#define ld long double
#define fi first
#define se second
#define pb push_back
#define pf push_front
#define INeedToSpeed                                                                               \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0);                                                                                    \
    cout.tie(0);
#define rep(i, a, b) for (int i = a; i <= b; i++)
#define per(i, a, b) for (int i = a; i >= b; i--)
#define all(a) a.begin(), a.end()
#define pus(a) cout << a << "\n";

ll mod = 1000000000 + 7;
const ll N = 100017;


void solve()
{
    ll n;
    ll res = 0, C = 0, sum = 0;
    set<ll> a, b;
    set<pair<ll, ll>> s1, s2;
    cin >> n;
    rep(i, 1, n)
    {
        ll t, x;
        cin >> t >> x;
        sum += x;
        if (t == 0)
        {
            if (x > 0)
            {
                a.insert(x);
                s2.insert({ x, 0 });
            }
            else
            {
                x = -x;
                a.erase(x);
                if (s1.find({ x, 0 }) != s1.end())
                {
                    res -= x;
                    s1.erase({ x, 0 });
                }
                else
                    s2.erase({ x, 0 });
            }
        }
        else
        {
            if (x > 0)
            {
                b.insert(x);
                s2.insert({ x, 1 });
            }
            else
            {
                x = -x;
                b.erase(x);
                if (s1.find({ x, 1 }) != s1.end())
                {
                    res -= x;
                    C -= 1;
                    s1.erase({ x, 1 });
                }
                else
                    s2.erase({ x, 1 });
            }
        }
        while (s1.size() > b.size())
        {
            auto p = *s1.begin();
            s1.erase(p);
            s2.insert(p);
            res -= p.fi;
            C -= p.se;
        }
        while (s1.size() < b.size())
        {
            auto p = *(--s2.end());
            s2.erase(p);
            s1.insert(p);
            res += p.fi;
            C += p.se;
        }
        while (!s1.empty() && !s2.empty() && s1.begin()->fi < (--s2.end())->fi)
        {
            auto p = *s1.begin();
            auto q = *(--s2.end());
            s1.erase(p);
            s2.erase(q);
            s1.insert(q);
            s2.insert(p);
            res += q.fi - p.fi;
            C += q.se - p.se;
        }
        ll cur = sum + res;
        if (C == b.size() && C > 0)
        {
            cur -= *b.begin();
            if (!a.empty())
                cur += *(--a.end());
        }
        cout << cur << "\n";
    }
}
main()
{

    INeedToSpeed ll t24 = 1;
    // cin >> t24;
    while (t24--)
    {
        solve();
        cout << "\n";
    }
}
