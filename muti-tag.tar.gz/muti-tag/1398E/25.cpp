﻿#include <bits/stdc++.h>
using namespace std;
set<int> si, no, es;
int tsi, tno; // contadores de luz
typedef long long ll;
ll ssi, sno; /// contadores de la suma total
void csi()
{ /// cambio de si a no
    int x = *si.begin();
    int op = es.count(x);
    tsi -= op;
    tno += op;
    si.erase(x);
    no.insert(x);
    ssi -= x;
    sno += x;
}
void cno()
{
    int x = *no.rbegin();
    int op = es.count(x);
    tsi += op;
    tno -= op;
    no.erase(x);
    si.insert(x);
    ssi += x;
    sno -= x;
}
int main()
{
    int n;
    scanf("%d", &n);
    while (n--)
    {
        int op, x;
        scanf("%d %d", &op, &x);
        if (x > 0)
        {
            if (op)
                es.insert(x);
            no.insert(x);
            sno += x;
            tno += op;
        }
        else
        {
            x = -x;
            int tipo = si.count(x);
            if (tipo)
            {
                si.erase(x);
                tsi -= op;
                ssi -= x;
                es.erase(x);
            }
            else
            {
                no.erase(x);
                tno -= op;
                sno -= x;
                if (es.count(x))
                    es.erase(x);
            }
        }
        int luz = tsi + tno;
        while (si.size() < luz)
            cno();
        while (si.size() > luz)
            csi();
        while (si.size() && no.size() && *no.rbegin() > *si.begin())
        {
            cno();
            csi();
        }
        long long ans = sno + ssi * 2;
        if (tsi == luz && luz > 0)
        {
            ans -= *si.begin();
            if (no.size())
                ans += *no.rbegin();
        }
        printf("%lld\n", ans);
    }
    return 0;
}