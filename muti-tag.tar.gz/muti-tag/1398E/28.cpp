﻿#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define fi first
#define se second
#define sz(a) (int)(a.size())
#define all(a) a.begin(), a.end()
#define lb lower_bound
#define ub upper_bound
#define owo                                                                                        \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0);
#define MOD (ll)(1e9 + 7)
#define INF (ll)(1e18)
#define debug(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define time__(d)                                                                                  \
    for (long blockTime = 0; (blockTime == 0 ? (blockTime = clock()) != 0 : false); \
debug("%s time : %.4fs\n", d, (double)(clock() - blockTime) / CLOCKS_PER_SEC))
typedef long long int ll;
typedef long double ld;
typedef pair<ll, ll> PII;
typedef pair<int, int> pii;
typedef vector<vector<int>> vii;
typedef vector<vector<ll>> VII;
ll gcd(ll a, ll b)
{
    if (!b)
        return a;
    else
        return gcd(b, a % b);
}
vector<ll> sum(2), cnt(2);
set<ll> s[2];
set<ll> elec;
void add()
{
    ll d = *s[0].rbegin();
    s[1].insert(d);
    s[0].erase(d);
    sum[1] += d;
    sum[0] -= d;
    if (elec.count(d))
    {
        cnt[0]--;
        cnt[1]++;
    }
}
void del()
{
    ll d = *s[1].begin();
    s[0].insert(d);
    s[1].erase(d);
    sum[0] += d;
    sum[1] -= d;
    if (elec.count(d))
    {
        cnt[1]--;
        cnt[0]++;
    }
}
int main()
{
    owo int n;
    cin >> n;
    while (n--)
    {
        ll tp, d;
        cin >> tp >> d;
        if (d > 0)
        {
            s[0].insert(d);
            sum[0] += d;
            cnt[0] += tp;
            if (tp)
                elec.insert(d);
        }
        else
        {
            d = -d;
            int id = s[1].count(d);
            s[id].erase(d);
            sum[id] -= d;
            cnt[id] -= tp;
            if (tp)
                elec.erase(d);
        }
        int tot = cnt[0] + cnt[1];

        while (sz(s[1]) < tot)
            add();
        while (sz(s[1]) > tot)
            del();
        while (sz(s[0]) && sz(s[1]) && *s[0].rbegin() > *s[1].begin())
        {
            add();
            del();
        }
        ll ans = sum[0] + sum[1] * 2;
        if (cnt[1] == tot && tot)
        {
            ans -= *s[1].begin();
            if (sz(s[0]))
                ans += *s[0].rbegin();
        }
        cout << ans << '\n';
    }
}
