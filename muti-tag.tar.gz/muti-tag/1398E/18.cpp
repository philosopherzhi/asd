﻿#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define IOS                                                                                        \
    ios::sync_with_stdio(false);                                                                   \
    cin.tie(0), cout.tie(0)
typedef long long LL;
using PII = pair<LL, LL>;
const int maxn = 2e2 + 5;
const LL mod = 1e9 + 7;

set<pair<int, int>> s[2], all;
int n, opt, d, cnt = 0, num = 0;
LL ans = 0, sum = 0;

inline void ppop()
{
    while (all.size() > cnt)
    {
        sum -= all.begin()->first;
        s[all.begin()->second].insert(*all.begin());
        num -= all.begin()->second;
        all.erase(all.begin());
    }
}

inline void alls0()
{
    if (cnt && num == cnt)
    {
        sum -= all.begin()->first;
        s[all.begin()->second].insert(*all.begin());
        all.erase(all.begin());
        num--;
        if (!s[0].empty())
        {
            sum += s[0].rbegin()->first;
            all.insert(*s[0].rbegin());
            s[0].erase(*s[0].rbegin());
        }
    }
}

inline void add()
{
    if (all.size() < cnt)
    {
        if (s[0].empty() && !s[1].empty()
            || (!s[0].empty() && !s[1].empty() && s[1].rbegin()->first > s[0].rbegin()->first))
        {
            sum += s[1].rbegin()->first;
            num++;
            all.insert(*s[1].rbegin());
            s[1].erase(*s[1].rbegin());
        }
        else if (!s[0].empty() && s[1].empty()
            || (!s[0].empty() && !s[1].empty() && s[1].rbegin()->first < s[0].rbegin()->first))
        {
            sum += s[0].rbegin()->first;
            all.insert(*s[0].rbegin());
            s[0].erase(*s[0].rbegin());
        }
    }
}

int main()
{
    IOS;

    cin >> n;
    while (n--)
    {
        cin >> opt >> d;
        ans += d;
        if (opt)
        {
            if (d > 0)
            {
                cnt++;
                s[1].insert(make_pair(d, opt));
                add();
                ppop();
                alls0();
            }
            else
            {
                d = -d;
                cnt--;
                if (all.count(make_pair(d, opt)))
                {
                    all.erase(make_pair(d, opt));
                    sum -= d;
                    num--;
                }
                if (s[1].count(make_pair(d, opt)))
                    s[1].erase(make_pair(d, opt));
                add();
                ppop();
                alls0();
            }
        }
        else
        {
            if (d > 0)
            {
                all.insert(make_pair(d, opt));
                sum += d;
                ppop();
                alls0();
            }
            else
            {
                d = -d;
                if (all.count(make_pair(d, opt)))
                {
                    all.erase(make_pair(d, opt));
                    sum -= d;
                }
                if (s[0].count(make_pair(d, opt)))
                    s[0].erase(make_pair(d, opt));
                add();
                ppop();
                alls0();
            }
        }
        cout << ans + sum << endl;
    }
}
/*
 8
 1 83723419
1 -83723419
1 43688531
0 107306488
0 -107306488
1 741108574
1 -741108574
1 22459404

 83723419
0
43688531
258301507
43688531
1525905679
43688531
109836466
 */