﻿#include <bits/stdc++.h>
using namespace std;

#define fastIO                                                                                     \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(NULL);                                                                                 \
    cout.tie(NULL);
#define endl '\n'
#define lli long long int
#define ld long double
#define p_b push_back
#define m_p make_pair
#define fs first
#define sc second
#define sz(x) ((lli)x.size())
#define all(x) x.begin(), x.end()
const lli mod = 1e9 + 7;
const lli N = 1e6 + 5;
/*****************************************************/
lli t, n, m;
set<lli> s0, s1, s2, s3;
int main()
{
    fastIO lli i, j, k, x, y;
    cin >> n;
    lli tot = 0, sum = 0;
    while (n--)
    {
        cin >> x >> y;
        if (x == 0)
        {
            if (y > 0)
                s0.insert(y);
            else
                s0.erase(-y);
        }
        else
        {
            if (y > 0)
                s1.insert(y);
            else
                s1.erase(-y);
        }
        tot += y;
        if (y < 0)
        {
            if (s2.find(-y) != s2.end())
            {
                sum += y;
                s2.erase(-y);
            }
            else
                s3.erase(-y);
        }
        else
        {
            sum += y;
            s2.insert(y);
        }
        while (sz(s2) < sz(s1) && sz(s3) > 0)
        {
            auto it = s3.end();
            it--;
            s2.insert(*it);
            sum += *it;
            s3.erase(*it);
        }
        while (sz(s2) > sz(s1))
        {
            auto it = s2.begin();
            x = *it;
            sum -= x;
            s2.erase(x);
            s3.insert(x);
        }
        while (sz(s3) > 0 && sz(s2) > 0)
        {
            auto it = s3.end();
            it--;
            if (*it < *s2.begin())
                break;
            sum = sum + *it - *s2.begin();
            x = *it;
            y = *s2.begin();
            s3.erase(x);
            s2.insert(x);
            s3.insert(y);
            s2.erase(y);
        }
        if (sz(s1) > 0)
        {
            x = *s1.begin();
            if (s2.find(x) != s2.end())
            {
                if (sz(s3) > 0)
                {
                    auto it = s3.end();
                    it--;
                    sum += *it;
                    s2.insert(*it);
                    s3.erase(*it);
                }
                sum -= x;
                s2.erase(x);
                s3.insert(x);
            }
        }

        // cout<<sum<<" "<<tot<<endl;
        // cout<<sz(s0)<<" "<<sz(s1)<<" "<<sz(s2)<<" "<<sz(s3)<<endl;
        cout << tot + sum << endl;
        // if(n<=1)
        // {
        //     cout<<tot+sum<<endl;
        //     for(auto it=s0.begin();it!=s0.end();it++)
        //         cout<<*it<<" ";
        //     cout<<endl;
        //     for(auto it=s1.begin();it!=s1.end();it++)
        //         cout<<*it<<" ";
        //     cout<<endl;
        //     for(auto it=s2.begin();it!=s2.end();it++)
        //         cout<<*it<<" ";
        //     cout<<endl;
        //     for(auto it=s3.begin();it!=s3.end();it++)
        //         cout<<*it<<" ";
        //     cout<<endl;
        //     cout<<"**********\n";

        // }
        // cout<<"**********\n";
    }
    // cerr<< '\n' << "Time elapsed :" << clock() * 1000.0 / CLOCKS_PER_SEC << " ms\n" ;
    return 0;
}