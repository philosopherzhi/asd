﻿#include <bits/stdc++.h>
#define ll long long
#define pb push_back
#define fi first
#define se second
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
#define sz(x) x.size()
#define pii pair<int, int>
#define en '\n'
#define sp ' '
#define smin(a, b) a = min(a, b)
#define smax(a, b) a = max(a, b)
#define ar array
using namespace std;
const ll mod = 998244353;
// const int mod = 1e9+7;
const int N = 2e5 + 2;
const int inf = 2e9;
const ll linf = 4e18;
set<ll> fire, lightning, small, big;
ll sumall, sumbig;
void add(ll x)
{
    sumall += x;
    if (big.empty() || x < *big.begin())
        small.insert(x);
    else
    {
        big.insert(x);
        sumbig += x;
    }
}
void rem(ll x)
{
    sumall -= x;
    if (small.count(x))
        small.erase(x);
    else
    {
        big.erase(x);
        sumbig -= x;
    }
}
ll calc()
{
    if (sz(big) > sz(lightning))
    {
        ll c = *big.begin();
        sumbig -= c;
        big.erase(c);
        small.insert(c);
    }
    if (sz(big) < sz(lightning))
    {
        ll c = *small.rbegin();
        small.erase(c);
        sumbig += c;
        big.insert(c);
    }
    ll ans = sumall + sumbig;
    if (fire.empty() || (*fire.rbegin() < *lightning.begin()))
    {
        ans -= *lightning.begin();
        if (!fire.empty())
            ans += *fire.rbegin();
    }
    return ans;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cerr.tie(0);
    int Q;
    cin >> Q;
    sumall = sumbig = 0;
    while (Q--)
    {
        ll t, x;
        cin >> t >> x;
        if (x > 0)
        {
            if (t)
                lightning.insert(x);
            else
                fire.insert(x);
            add(x);
        }
        else
        {
            x *= -1;
            if (t)
                lightning.erase(x);
            else
                fire.erase(x);
            rem(x);
        }
        cout << calc() << en;
    }
    return 0;
}
