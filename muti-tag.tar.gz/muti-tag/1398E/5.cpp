﻿#include <algorithm>
#include <bitset>
#include <cassert>
#include <cmath>
#include <deque>
#include <functional>
#include <iostream>
#include <iterator>
#include <map>
#include <numeric>
#include <ostream>
#include <queue>
#include <random>
#include <set>
#include <string>
#include <vector>

//#pragma GCC optimize("Ofast")
//#pragma GCC target("avx2")

using namespace std;

#ifdef _DEBUG
#define DEB 1
#else
#define DEB 0
#endif
#define MTEST()                                                                                    \
    int _t;                                                                                        \
    cin >> _t;                                                                                     \
    for (int _tn = 0; _tn < _t; ++_tn)
#define ALL(c) c.begin(), c.end()
#define SZ(c) (int) c.size()

#define int long long

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int q;
    cin >> q;
    set<int> a;
    set<int, greater<int>> b;
    set<int> c;
    int ans = 0;
    while (q--)
    {
        int t, x;
        cin >> t >> x;
        if (t == 0)
        {
            if (x < 0)
            {
                x = -x;
                if (a.count(x))
                {
                    ans -= 2 * x;
                    a.erase(x);
                }
                else
                {
                    ans -= x;
                    b.erase(x);
                }
            }
            else
            {
                ans += x;
                b.insert(x);
            }
        }
        else
        {
            if (x < 0)
            {
                x = -x;
                if (a.count(x))
                {
                    ans -= 2 * x;
                    a.erase(x);
                }
                else
                {
                    ans -= x;
                    b.erase(x);
                }
                c.erase(x);
            }
            else
            {
                ans += x;
                b.insert(x);
                c.insert(x);
            }
        }
        if (!c.empty())
        {
            if (a.count(*c.begin()))
            {
                ans -= 2 * *c.begin();
                a.erase(*c.begin());
            }
            else
            {
                ans -= *c.begin();
                b.erase(*c.begin());
            }
        }
        while (SZ(a) > SZ(c))
        {
            ans -= *a.begin();
            b.insert(*a.begin());
            a.erase(a.begin());
        }
        while (!b.empty() && a.size() + 1 <= SZ(c))
        {
            ans += *b.begin();
            a.insert(*b.begin());
            b.erase(b.begin());
        }
        while (!a.empty() && !b.empty() && *a.begin() < *b.begin())
        {
            ans -= *a.begin();
            b.insert(*a.begin());
            a.erase(a.begin());

            ans += *b.begin();
            a.insert(*b.begin());
            b.erase(b.begin());
        }
        if (!c.empty())
        {
            ans += *c.begin();
            b.insert(*c.begin());
        }
        cout << ans << '\n';
    }
    return 0;
}
