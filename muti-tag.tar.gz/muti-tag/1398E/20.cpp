﻿#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> ii;

class Node
{
public:
    int r, l, c;
    long long s;
    Node* n1;
    Node* n2;
    Node(int l, int r)
    {
        this->l = l;
        this->r = r;
        s = c = 0;
        n1 = n2 = NULL;
    }
};

void up(Node* ac, int d)
{
    if (ac->l == d && ac->r == d)
    {
        if (ac->c)
        {
            ac->c = ac->s = 0;
        }
        else
        {
            ac->c = 1;
            ac->s = d;
        }
        return;
    }

    int m = (ac->l + ac->r) / 2;
    if (m >= d)
    {
        if (ac->n1 == NULL)
            ac->n1 = new Node(ac->l, m);
        up(ac->n1, d);
    }
    else
    {
        if (ac->n2 == NULL)
            ac->n2 = new Node(m + 1, ac->r);
        up(ac->n2, d);
    }
    ac->c = ac->s = 0;
    if (ac->n1 != NULL)
    {
        ac->c += ac->n1->c;
        ac->s += ac->n1->s;
    }

    if (ac->n2 != NULL)
    {
        ac->c += ac->n2->c;
        ac->s += ac->n2->s;
    }
}

long long qu(Node* ac, int q)
{
    if (q >= ac->c)
        return ac->s;
    long long res = 0;
    if (ac->n2 != NULL)
    {
        res += qu(ac->n2, q);
        q -= ac->n2->c;
    }
    if (q > 0)
        res += qu(ac->n1, q);
    return res;
}
int main()
{

    cin.tie(0);
    ios_base::sync_with_stdio(0);

    Node* head = new Node(0, 1000000000);
    int n, tp, d;
    cin >> n;
    set<int> f, l;
    long long sum = 0;
    while (n--)
    {
        cin >> tp >> d;
        sum += d;
        if (tp == 0)
        {
            if (d > 0)
                f.insert(-d), up(head, d);
            else
                f.erase(d), up(head, -d);
        }
        else
        {
            if (d > 0)
                l.insert(d), up(head, d);
            else
                l.erase(-d), up(head, -d);
        }
        if (l.empty())
            cout << sum << endl;
        else
        {
            long long res = sum;
            if (f.empty() || *l.begin() > -(*f.begin()))
            {
                res += qu(head, l.size() - 1);
                if (!f.empty())
                    res += -(*f.begin());
            }
            else
                res += qu(head, l.size());
            cout << res << endl;
        }
    }


    return 0;
}