﻿#include <bits/stdc++.h>
#define rep(i, n) for (int i = 0; i < (int)(n); i++)
#define rrep(i, n) for (int i = (int)(n - 1); i >= 0; i--)
#define all(x) (x).begin(), (x).end()
#define sz(x) int(x.size())
using namespace std;
using ll = long long;
const int INF = 1e9;
const ll LINF = 1e18;
template <class T>
void get_unique(vector<T>& x)
{
    x.erase(unique(x.begin(), x.end()), x.end());
}
template <class T>
bool chmax(T& a, const T& b)
{
    if (a < b)
    {
        a = b;
        return 1;
    }
    return 0;
}
template <class T>
bool chmin(T& a, const T& b)
{
    if (b < a)
    {
        a = b;
        return 1;
    }
    return 0;
}
template <class T>
vector<T> make_vec(size_t a)
{
    return vector<T>(a);
}
template <class T, class... Ts>
auto make_vec(size_t a, Ts... ts)
{
    return vector<decltype(make_vec<T>(ts...))>(a, make_vec<T>(ts...));
}
template <typename T>
istream& operator>>(istream& is, vector<T>& v)
{
    for (int i = 0; i < int(v.size()); i++)
    {
        is >> v[i];
    }
    return is;
}
template <typename T>
ostream& operator<<(ostream& os, const vector<T>& v)
{
    for (int i = 0; i < int(v.size()); i++)
    {
        os << v[i];
        if (i < sz(v) - 1)
            os << ' ';
    }
    return os;
}
int main()
{
    multiset<pair<ll, int>> left, right;
    int x = 0;
    int cnt = 0;
    ll sum = 0;
    ll all_sum = 0;

    auto balance = [&]() -> void
    {
        while (sz(left) > x)
        {
            sum -= left.begin()->first;
            if (left.begin()->second == 1)
                cnt--;
            right.emplace(*left.begin());
            left.erase(left.begin());
        }
        while (sz(left) < x && sz(right))
        {
            sum += right.rbegin()->first;
            if (right.rbegin()->second == 1)
                cnt++;
            left.emplace(*right.rbegin());
            right.erase(--right.end());
        }
        if (sz(left) && sz(right))
            assert(*left.begin() >= *right.rbegin());
    };
    auto push = [&](ll a, int t) -> void
    {
        if (t == 0)
            x++;
        if ((left.empty() && right.empty()) or (sz(left) && make_pair(a, t) >= *left.begin())
            or (sz(right) && make_pair(a, t) >= *right.rbegin()))
        {
            left.emplace(a, t);
            if (t == 1)
                cnt++;
            sum += a;
        }
        else
        {
            right.emplace(a, t);
        }
        balance();
    };
    auto pop = [&](ll a, int t) -> void
    {
        if (t == 0)
            x--;
        if (left.count({ a, t }))
        {
            left.erase(left.lower_bound({ a, t }));
            if (t == 1)
                cnt--;
            sum -= a;
        }
        else if (right.count({ a, t }))
        {
            right.erase(right.lower_bound({ a, t }));
        }
        else
        {
            assert(0);
        }
        balance();
    };

    int q;
    cin >> q;
    while (q--)
    {
        int t;
        ll d;
        cin >> t >> d;
        t ^= 1;
        ll ans = 0;

        all_sum += d;
        if (d > 0)
        {
            push(d, t);
        }
        else
        {
            pop(-d, t);
        }

        if (cnt == 0 && (sz(left)))
        {
            ans -= left.begin()->first;
            if (sz(right))
                ans += right.rbegin()->first;
        }

        /* cout << cnt << '\n';
        for (auto itr = left.rbegin(); itr != left.rend(); itr++)
            cout << itr->first << ' ';
        cout << "| ";
        for (auto itr = right.begin(); itr != right.end(); itr++)
            cout << itr->first << ' ';
        cout << '\n';
        cout << ans << ' ' << all_sum << ' ' << sum << '\n'; */
        ans += all_sum + sum;
        // assert(ans >= all_sum);
        cout << ans << '\n';
    }
}