﻿#include <bits/stdc++.h>
using namespace std;

#define mp make_pair
typedef long long ll;
typedef pair<int, int> pii;
const int N = 2e5;
vector<pii> sq;
vector<int> v;
int Bit1[N + 10];
ll Bit2[N + 10];
set<int> st;

void update1(int idx, int val)
{
    while (idx <= N)
    {
        Bit1[idx] += val;
        idx += (idx & -idx);
    }
}
void update2(int idx, int val)
{
    while (idx <= N)
    {
        Bit2[idx] += val;
        idx += (idx & -idx);
    }
}
int query1(int idx)
{
    int total = 0;
    while (idx > 0)
    {
        total += Bit1[idx];
        idx -= (idx & -idx);
    }
    return total;
}
ll query2(int idx)
{
    ll total = 0;
    while (idx > 0)
    {
        total += Bit2[idx];
        idx -= (idx & -idx);
    }
    return total;
}

int main()
{
    v.push_back(0);
    int n, cntli = 0, cnttot = 0;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
    {
        int tp, d;
        scanf("%d%d", &tp, &d);
        sq.push_back(mp(tp, d));
        if (d > 0)
        {
            v.push_back(d);
        }
    }
    sort(v.begin(), v.end());
    int m = unique(v.begin(), v.end()) - v.begin();
    while ((int)v.size() > m + 1)
    {
        v.pop_back();
    }
    for (auto it : sq)
    {
        ll ans = 0;
        if (it.first == 0)
        {
            auto del = lower_bound(v.begin(), v.end(), abs(it.second)) - v.begin();
            if (it.second > 0)
            {
                update1(del, 1);
                cnttot++;
            }
            else
            {
                cnttot--;
                update1(del, -1);
            }
            update2(del, it.second);
        }
        else
        {
            auto del = lower_bound(v.begin(), v.end(), abs(it.second)) - v.begin();
            if (it.second > 0)
            {
                cntli++;
                cnttot++;
                st.insert(it.second);
                update1(del, 1);
            }
            else
            {
                cntli--;
                cnttot--;
                st.erase(-it.second);
                update1(del, -1);
            }
            update2(del, it.second);
        }
        // printf("%d ",it.second);
        if (cnttot == 0)
        {
            ans = 0;
        }
        else if (cntli == 0)
        {
            ans = query2(n);
        }
        else if (cntli == cnttot)
        {
            int lo = 0, hi = n, idx = 0;
            while (lo <= hi)
            {
                int mid = (lo + hi) / 2;
                if (query1(mid) >= 1)
                {
                    idx = mid;
                    hi = mid - 1;
                }
                else
                {
                    lo = mid + 1;
                }
            }
            ans = query2(n) - query2(idx);
            // printf("%lld ",ans);
            ans *= 2;
            // printf("%lld ",ans);
            ans += *st.begin();
            // printf("%lld ",ans);
            // printf("%d\n",2);
        }
        else
        {
            int b = *st.begin();
            int lower = cnttot - cntli;
            int bidx = lower_bound(v.begin(), v.end(), b) - v.begin();
            bidx = query1(bidx);
            // printf("%d %d\n",b,bidx);
            if (bidx > lower)
            {
                int lo = 0, hi = n, idx = 0;
                while (lo <= hi)
                {
                    int mid = (lo + hi) / 2;
                    if (query1(mid) <= lower - 1)
                    {
                        idx = mid;
                        lo = mid + 1;
                    }
                    else
                    {
                        hi = mid - 1;
                    }
                }
                ans = query2(n) + query2(n) - query2(idx) - b;
            }
            else
            {
                int lo = 0, hi = n, idx = 0;
                while (lo <= hi)
                {
                    int mid = (lo + hi) / 2;
                    if (query1(mid) <= lower)
                    {
                        idx = mid;
                        lo = mid + 1;
                    }
                    else
                    {
                        hi = mid - 1;
                    }
                }
                ans = query2(n) + query2(n) - query2(idx);
            }
        }
        printf("%lld\n", ans);
    }
}
