﻿#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <stack>
#include <queue>
#include <cmath>
#include <ctime>
#include <vector>
#include <set>
#define inf 0x3f3f3f3f
#define r(i, a, b) for (int i = a; i <= b; ++i)
#define rr(i, a, b) for (int i = a; i >= b; --i)
#define re(a) a = read()
#define mem(a) memset(a, 0x3f, sizeof(a))
#define me(a) memset(a, 0, sizeof(a))
#define rel(a) a = readl()
#define ll long long
#define db double
#define in inline
using namespace std;
const int N = 2e6 + 7;
in int read()
{
    char ch = getchar();
    int x = 0, w = 1;
    while (ch < '0' || ch > '9')
    {
        if (ch == '-')
            w = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9')
    {
        x = (x << 1) + (x << 3) + ch - '0', ch = getchar();
    }
    return x * w;
}
in ll readl()
{
    char ch = getchar();
    ll x = 0, w = 1;
    while (ch < '0' || ch > '9')
    {
        if (ch == '-')
            w = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9')
    {
        x = x * 10 + ch - '0', ch = getchar();
    }
    return x * w;
}
int n, tot;
ll ans = 0;
set<int> fire, light, remain;
int main()
{
    re(n);
    int x, d;
    tot = 0;
    r(i, 1, n)
    {
        re(x), re(d);
        if (d > 0)
        {
            ans += d;
            if (x)
                ++tot;
            else
                fire.insert(d);
            if (remain.size() && d < *remain.rbegin())
                remain.insert(d);
            else
            {
                ans += d;
                light.insert(d);
            }
        }
        else
        {
            ans += d;
            if (x)
                --tot;
            else
                fire.erase(-d);
            if (remain.size() && -d <= *remain.rbegin())
                remain.erase(-d);
            else
            {
                ans += d;
                light.erase(-d);
            }
        }
        while (light.size() < tot)
        {
            ans += *remain.rbegin();
            light.insert(*remain.rbegin());
            remain.erase(--remain.end());
        }
        while (light.size() > tot)
        {
            ans -= *light.begin();
            remain.insert(*light.begin());
            light.erase(light.begin());
        }
        printf("%lld\n", ans
                + 1ll
                    * min((light.size() ? (fire.size() ? *fire.rbegin() : 0) - *light.begin() : 0),
                          0));
    }

    return 0;
}
