﻿#include <bits/stdc++.h>
#define ll long long
#define pb push_back
#define task "cowpatibility"
#define pll pair<ll, ll>
#define pii pair<pll, ll>
#define fi first
#define se second

using namespace std;
const ll mod = 1e9 + 7;
const ll N = 2e5 + 5;
const int base = 400;
ll n, m, t, k, T, ans, tong, lab[N], a[N], b[N], c[N], st[N * 4], sl[N * 4], d[N], u, v;
vector<ll> adj[N], kq;
string s;
bool cmp(const pll& x, const pll& y)
{
    if (x.fi / base == y.fi / base)
        return x.se < y.se;
    return (x.fi / base < y.fi / base);
}
struct matrix
{
    ll c[8][8];
    matrix()
    {
        memset(c, 0, sizeof(c));
    }
};
ll pw(ll k, ll n)
{
    ll total = 1;
    for (; n; n >>= 1)
    {
        if (n & 1)
            total = total * k % mod;
        k = k * k % mod;
    }
    return total;
}
matrix nhan(matrix a, matrix b)
{
    matrix res;
    for (int i = 1; i < 6; i++)
    {
        for (int j = 1; j < 6; j++)
        {
            for (int k = 1; k < 6; k++)
            {
                res.c[i][j] = (res.c[i][j] + a.c[i][k] * b.c[k][j] % m) % m;
            }
        }
    }
    return res;
}
void update(ll id, ll l, ll r, ll pos)
{
    if (l == r)
    {
        sl[id] = 1 - sl[id];
        if (sl[id])
            st[id] = kq[l - 1];
        else
            st[id] = 0;
        return;
    }
    ll mid = (l + r) / 2;
    if (mid >= pos)
        update(id * 2, l, mid, pos);
    else
        update(id * 2 + 1, mid + 1, r, pos);
    st[id] = st[id * 2] + st[id * 2 + 1];
    sl[id] = sl[id * 2] + sl[id * 2 + 1];
}
ll get(ll id, ll l, ll r, ll k)
{
    if (k == 0)
        return 0;
    if (sl[id] <= k)
        return st[id];
    ll mid = (l + r) / 2;
    if (sl[id * 2 + 1] <= k)
        return st[id * 2 + 1] + get(id * 2, l, mid, k - sl[id * 2 + 1]);
    else
        return get(id * 2 + 1, mid + 1, r, k);
}
ll lwr(ll x)
{
    return lower_bound(kq.begin(), kq.end(), x) - kq.begin() + 1;
}
set<ll> fir, lig;
void sol()
{
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i] >> d[i];
        kq.pb(d[i]);
    }
    sort(kq.begin(), kq.end());
    kq.erase(unique(kq.begin(), kq.end()), kq.end());
    for (int i = 1; i <= n; i++)
    {
        if (a[i] == 0)
        {
            if (d[i] > 0)
            {
                update(1, 1, n, lwr(d[i]));
                fir.insert(d[i]);
            }
            else
            {
                d[i] *= -1;
                update(1, 1, n, lwr(d[i]));
                fir.erase(d[i]);
            }
        }
        else
        {
            if (d[i] > 0)
            {
                ++tong;
                update(1, 1, n, lwr(d[i]));
                lig.insert(d[i]);
            }
            else
            {
                --tong;
                d[i] *= -1;
                update(1, 1, n, lwr(d[i]));
                lig.erase(d[i]);
            }
        }
        ans = st[1] + get(1, 1, n, tong);
        if (fir.empty() && tong > 0)
            ans -= (*lig.begin());
        else
        {
            ll l = lig.empty() ? -mod : (*lig.begin());
            ll r = fir.empty() ? -mod : (*fir.rbegin());
            if (!lig.empty() && !fir.empty() && l > r)
                ans += r - l;
        }

        cout << ans << '\n';
    }
}
int main()
{
    if (fopen(task ".in", "r"))
    {
        freopen(task ".in", "r", stdin);
        freopen(task ".out", "w", stdout);
    }
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int ntest = 1;
    // cin >> ntest;
    while (ntest-- > 0)
        sol();
}
// https://codeforces.com/problemset/problem/1493/E
