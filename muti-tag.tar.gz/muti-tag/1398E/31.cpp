﻿#include <bits/stdc++.h>

using namespace std;

// Problema E, Educational 93

#define fastio                                                                                     \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(NULL)
#define lli long long int
#define vi vector<int>
#define vlli vector<long long int>
#define pii pair<int, int>
#define plli pair<lli, lli>
#define rep(i, a, b) for (int i = (a); i <= (b); i++)
#define repa(i, a, b) for (int i = (a); i >= (b); i--)
#define repv(x, v) for (auto x : v)
#define debug(x) cout << #x << " = " << x << endl
#define debugsl(x) cout << #x << " = " << x << ", "
#define debugarr(x, a, b)                                                                          \
    cout << #x << " = [";                                                                          \
    rep(i, a, b) cout << x[i] << ", ";                                                             \
    cout << "]\n"
#define pb push_back
#define nl "\n"

#define tipox 0
#define tipoy 1

lli n, sumgrandes, sum, y, tipo, poder, maxx, miny, res;
set<lli> grandes, chicos, xs, ys;

int main()
{
    fastio;

    cin >> n;
    rep(i, 1, n)
    {
        cin >> tipo >> poder;
        if (poder > 0)
        {
            if (tipo == tipox)
                xs.insert(poder);
            else
                ys.insert(poder);
            sum += poder;

            // insertalo en los grandes y vacia hasta que sea igual al numero de y
            grandes.insert(poder);
            sumgrandes += poder;
        }
        else
        {
            poder = -poder;
            if (tipo == tipox)
                xs.erase(poder);
            else
                ys.erase(poder);
            sum -= poder;

            if (grandes.count(poder))
            {
                grandes.erase(poder);
                sumgrandes -= poder;
            }
            else
                chicos.erase(poder);
        }

        // ve que los grandes esten en el de grandes
        while (!grandes.empty() && !chicos.empty() && *grandes.begin() < *(--chicos.end()))
        {
            grandes.insert(*(--chicos.end()));
            sumgrandes += *(--chicos.end());
            chicos.erase(--chicos.end());
        }

        while (grandes.size() < ys.size())
        {
            grandes.insert(*(--chicos.end()));
            sumgrandes += *(--chicos.end());
            chicos.erase(--chicos.end());
        }

        while (grandes.size() > ys.size())
        {
            sumgrandes -= *grandes.begin();
            chicos.insert(*grandes.begin());
            grandes.erase(grandes.begin());
        }


        if (xs.size())
            maxx = *(--xs.end());
        else
            maxx = 0;

        if (ys.size())
            miny = *ys.begin();
        else
            miny = 0;

        if (miny > maxx)
        {
            // todos los mayores son ys
            res = sum + sumgrandes - miny + maxx;
            cout << res << nl;
        }
        else
        {
            cout << sum + sumgrandes << nl;
        }
    }

    return 0;
}
