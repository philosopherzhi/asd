﻿#pragma GCC optimize("Ofast")
#pragma GCC target("avx,avx2,fma")

#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/hash_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

#define LL long long
#define int long long
#define ull unsigned long long
#define fi first
#define se second
#define pll pair<LL, LL>
#define pii pair<int, int>
#define fastio ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
#define SZ(x) ((int)(x.size()))
#define LC (id << 1)
#define RC (id << 1 | 1)

constexpr int N = 5e5 + 9;
constexpr int M = 1e9 + 7;
#ifdef int
constexpr int INF = 0x3f3f3f3f3f3f3f3f;
constexpr int INF2 = 0xcfcfcfcfcfcfcfcf;
#else
constexpr int INF = 0x3f3f3f3f;
constexpr int INF2 = 0xcfcfcfcf;
#endif

struct BIT
{
    vector<int> c;
    BIT(int n)
        : c(n + 1, 0)
    {
    }
    inline int lowbit(int x)
    {
        return x & -x;
    }
    void add(int x, int v)
    {
        for (int i = x; i < SZ(c); i += lowbit(i))
            c[i] += v;
    }
    int sum(int x)
    {
        int res = 0;
        for (int i = x; i; i -= lowbit(i))
            res += c[i];
        return res;
    }
    int lower_bound(int v)
    {
        int sum = 0;
        int pos = 0;

        for (int i = 20; i >= 0; i--)
        {
            if (pos + (1 << i) < SZ(c) and sum + c[pos + (1 << i)] < v)
            {
                sum += c[pos + (1 << i)];
                pos += (1 << i);
            }
        }
        return pos + 1; // +1 because 'pos' will have position of largest value less than 'v'
    }
};

signed main()
{
    fastio;
    int n;
    cin >> n;
    int num[2] = { 0, 0 };
    vector<int> b;
    b.reserve(n);
    vector<pii> ops(n);
    for (auto & [ t, d ] : ops)
    {
        cin >> t >> d;
        if (d > 0)
            b.emplace_back(d);
    }
    sort(b.begin(), b.end());
    b.erase(unique(b.begin(), b.end()), b.end());
    multiset<int> light;
    BIT bit1(SZ(b)), bit2(SZ(b));
    for (auto & [ t, d ] : ops)
    {
        t ^= 1;
        if (d > 0)
        {
            int d2 = lower_bound(b.begin(), b.end(), d) - b.begin() + 1;
            bit1.add(d2, 1);
            bit2.add(d2, d);
            if (t == 0)
                light.emplace(d2);
            num[t]++;
        }
        else
        {
            int d2 = lower_bound(b.begin(), b.end(), -d) - b.begin() + 1;
            bit1.add(d2, -1);
            bit2.add(d2, d);
            if (t == 0)
                light.erase(light.find(d2));
            num[t]--;
        }
        if (num[0] == 0)
        {
            cout << bit2.sum(SZ(b)) << "\n";
        }
        else if (num[1] == 0)
        {
            int mini = bit1.lower_bound(1);
            cout << bit2.sum(SZ(b)) * 2 - b[mini - 1] << "\n";
        }
        else
        {
            int mini = *light.begin();
            bit1.add(mini, -1);
            bit2.add(mini, -b[mini - 1]);
            int minNum = num[1] - 1;
            int minPos = bit1.lower_bound(minNum);
            int minPosCnt = minNum - bit1.sum(minPos - 1);
            int minSum = bit2.sum(minPos - 1) + minPosCnt * b[minPos - 1];
            int maxSum = bit2.sum(SZ(b)) - minSum;
            bit1.add(mini, 1);
            bit2.add(mini, b[mini - 1]);
            cout << maxSum + bit2.sum(SZ(b)) << "\n";
        }
    }
    return 0;
}