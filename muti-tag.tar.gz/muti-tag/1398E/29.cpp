﻿/* Come ho fatto...
 *
 *
 * time: O();	memory: O()
 */

#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int N, tp, d;


int main()
{
    cin >> N;

    ll sum = 0, bonus = 0; // sum of damages of all spells; Bonus damage got by doubling
    set<int> F, L; // set of damages of known Fire and Lighting spells
    set<int> pow, others; // set of damages of most powerful spells we want to double

    for (int i = 0; i < N; ++i)
    {
        cin >> tp >> d;

        if (d > 0)
        {
            if (tp == 0)
            { // learning a Fire spell
                F.insert(d);
                pow.insert(d);
                bonus += d - *pow.begin();
                others.insert(*pow.begin());
                pow.erase(*pow.begin());
            }
            else
            { // learning a Lightning spell
                L.insert(d);
                others.insert(d);
                bonus += *others.rbegin();
                pow.insert(*others.rbegin());
                others.erase(*others.rbegin());
            }
        }
        else
        {
            if (tp == 0)
            { // forgetting a Fire spell
                F.erase(-d);
                if (pow.count(-d))
                {
                    bonus += d;
                    pow.erase(-d);
                    if (others.size())
                    {
                        bonus += *others.rbegin();
                        pow.insert(*others.rbegin());
                        others.erase(*others.rbegin());
                    }
                }
                else
                {
                    others.erase(-d);
                }
            }
            else
            { // forgetting a Lightning spell
                L.erase(-d);
                if (pow.count(-d))
                {
                    bonus += d;
                    pow.erase(-d);
                }
                else
                {
                    bonus -= *pow.begin();
                    others.erase(-d);
                    others.insert(*pow.begin());
                    pow.erase(*pow.begin());
                }
            }
        }
        sum += d;
        ll ans = sum;
        if (L.size() && *pow.begin() > *L.begin())
        { // we can double the most powerfuls spells
            ans += bonus;
        }
        else
        {
            if (others.size() == 0)
                ans += bonus - *pow.begin();
            else if (L.size() && others.size())
                ans += bonus - *pow.begin() + *others.rbegin();
        }
        cout << ans << endl;
    }

    return 0;
}
