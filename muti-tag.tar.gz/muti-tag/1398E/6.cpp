﻿#include <bits/stdc++.h>
using namespace std;

#define ll long long
const int N = 2e5 + 15;


ll dp[N];
int mlen[N];

set<int> s[2];

ll sum[2] = { 0, 0 };

set<int> g[2];

ll total = 0;
void insert(int tp, int d)
{
    g[tp].insert(d);
    s[1].insert(d);
    total += d;
}

void del(int tp, int d)
{
    g[tp].erase(d);
    total -= d;
    if (s[0].count(d))
    {
        s[0].erase(d);
        sum[0] -= d;
    }
    if (s[1].count(d))
    {
        s[1].erase(d);
    }
}

void solve()
{
    int n;
    scanf("%d ", &n);

    for (int i = 0; i < n; ++i)
    {
        int tp, d;
        scanf("%d %d ", &tp, &d);
        if (d < 0)
        {
            del(tp, -d);
        }
        else
        {
            insert(tp, d);
        }

        while (s[0].size() < g[1].size())
        {
            int x = *prev(s[1].end());
            s[1].erase(x);
            s[0].insert(x);
            sum[0] += x;
        }
        while (s[0].size() > g[1].size())
        {
            int x = *s[0].begin();
            s[0].erase(x);
            s[1].insert(x);
            sum[0] -= x;
        }
        while (s[0].size() > 0 && s[1].size() > 0)
        {
            if (*s[0].begin() < *s[1].rbegin())
            {
                int x = *s[0].begin(), y = *s[1].rbegin();
                s[0].erase(x), s[1].erase(y);
                s[0].insert(y), s[1].insert(x);
                sum[0] = sum[0] - x + y;
            }
            else
            {
                break;
            }
        }
        ll ret = total + sum[0];


        if (g[1].size() > 0)
        {
            int x = *g[1].begin();
            if (s[0].count(x))
            {
                ret -= x;
                if (g[0].size() > 0)
                    ret += *prev(g[0].end());
            }
        }
        printf("%lld\n", ret);
    }
}

int main()
{
    solve();
    return 0;
}
