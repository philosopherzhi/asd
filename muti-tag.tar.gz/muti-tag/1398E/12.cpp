﻿#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

template <class T>
using indexed_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

struct fenwick
{
    int n;
    vector<long long> fen;
    fenwick(int _)
        : n(_)
    {
        fen = vector<long long>(n + 1, 0);
    }
    void add(int i, long long v)
    {
        for (; i <= n; i += (i & -i))
            fen[i] += v;
    }
    long long sum(int i)
    {
        long long res = 0;
        for (; i > 0; i -= (i & -i))
            res += fen[i];
        return res;
    }
};

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int q;
    cin >> q;
    set<int> val;
    vector<int> ind;
    vector<pair<int, int>> queries;
    while (q--)
    {
        int t, d;
        cin >> t >> d;
        queries.emplace_back(t, d);
        d = abs(d);
        val.insert(d);
    }
    for (auto e : val)
        ind.push_back(e);
    auto id = [&](int x)
    {
        return lower_bound(ind.begin(), ind.end(), x) - ind.begin() + 1;
    };
    indexed_set<int> s;
    fenwick fire((int)ind.size());
    fenwick power((int)ind.size());
    long long res = 0;
    int cnt = 0;
    int total = 0;
    for (auto e : queries)
    {
        int t, d;
        tie(t, d) = e;
        res += d;
        total += (d / abs(d));
        if (t == 0)
            fire.add(id(abs(d)), d / abs(d));
        if (t == 1)
            cnt += d / abs(d);
        if (d > 0)
            s.insert(d);
        else
            s.erase(-d);
        power.add(id(abs(d)), d);
        if (total == 1 || cnt == 0)
        {
            cout << res << '\n';
            continue;
        }
        int lft = total - cnt;
        lft = *s.find_by_order(lft);
        lft = id(lft);
        if (fire.sum((int)ind.size()) - fire.sum(lft - 1) > 0 && cnt != total)
        {
            cout << res + power.sum((int)ind.size()) - power.sum(lft - 1) << '\n';
        }
        else
        {
            long long ret = res + power.sum((int)ind.size()) - power.sum(lft - 1)
                - *s.find_by_order(total - cnt);
            //		cout << *s.find_by_order(total - cnt) << '\n';
            //		cout << "ret : " << ret << '\n';
            lft = total - cnt - 1;
            if (lft < 0)
                lft = 1;
            else
                ret += *s.find_by_order(lft);
            cout << ret << '\n';
        }
    }
    return 0;
}
