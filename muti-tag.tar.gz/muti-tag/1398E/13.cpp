﻿#pragma GCC optimize("Ofast", "unroll-loops", "omit-frame-pointer", "inline")
#pragma GCC option("arch=native", "tune=native", "no-zero-upper")
#pragma GCC target("avx2")
#include <bits/stdc++.h>
using namespace std;
#define INF 2147483647
#define infL (1LL << 60)
#define inf (1 << 30)
#define inf9 (1000000000)
#define MOD 1000000007 // 998244353//1000000007
#define EPS 1e-9
#define Gr 9.8
#define PI acos(-1)
#define REP(i, n) for (int(i) = 0; (i) < (int)(n); (i)++)
#define REQ(i, n) for (int(i) = 1; (i) <= (int)(n); (i)++)
#define lch (rt << 1)
#define rch (rt << 1 | 1)
#define readmp(n)                                                                                  \
    for (int i = 0, u, v; i < n; i++)                                                              \
    {                                                                                              \
        scanf("%d%d", &u, &v);                                                                     \
        mp[u].push_back(v);                                                                        \
        mp[v].push_back(u);                                                                        \
    }
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef long double ld;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef ld ValType;
template <typename T>
void maxtt(T& t1, T t2)
{
    t1 = max(t1, t2);
}
template <typename T>
void mintt(T& t1, T t2)
{
    t1 = min(t1, t2);
}
#define MAX (200135)

bool debug = 0;
int n, m, k;
int dx[4] = { 0, 1, 0, -1 }, dy[4] = { 1, 0, -1, 0 };
string direc = "RDLU";
const ll MOD2 = (ll)MOD * (ll)MOD;
ll ln, lk, lm;
void etp(bool f = 0)
{
    puts(f ? "YES" : "NO");
    exit(0);
}
void addmod(int& x, int y, int mod = MOD)
{
    x += y;
    if (x >= mod)
        x -= mod;
    if (x < 0)
        x += mod;
    assert(x >= 0 && x < mod);
}
void et(int x = -1)
{
    printf("%d\n", x);
    exit(0);
}
ll fastPow(ll x, ll y, int mod = MOD)
{
    ll ans = 1;
    while (y > 0)
    {
        if (y & 1)
            ans = (x * ans) % mod;
        x = x * x % mod;
        y >>= 1;
    }
    return ans;
}
ll gcd1(ll x, ll y)
{
    return y ? gcd1(y, x % y) : x;
}


int t[MAX], d[MAX];
int val[MAX], cnt;
set<int> spl;
void hsh()
{
    map<int, int> mp;
    REQ(i, n) mp[abs(d[i])];
    for (auto& p : mp)
    {
        p.second = ++cnt;
        val[cnt] = p.first;
    }
    REQ(i, n)
    {
        int id = mp[abs(d[i])];
        d[i] = d[i] < 0 ? -id : id;
    }
}
ll T[MAX * 4];
int ts[MAX * 4];
void Up(int rt, int l, int r)
{
    T[rt] = T[lch] + T[rch];
    ts[rt] = ts[lch] + ts[rch];
}
void upt(int rt, int l, int r, int L, int fg)
{
    if (l == r)
    {
        T[rt] += fg * val[L];
        ts[rt] += fg;
        return;
    }
    int mid = (l + r) / 2;
    if (L <= mid)
        upt(lch, l, mid, L, fg);
    else
        upt(rch, mid + 1, r, L, fg);
    Up(rt, l, r);
}
ll qy(int rt, int l, int r, int C)
{
    if (ts[rt] <= C)
        return T[rt];
    if (l == r)
        return 0;
    int mid = (l + r) / 2;
    if (ts[rch] >= C)
        return qy(rch, mid + 1, r, C);
    else
        return qy(lch, l, mid, C - ts[rch]) + T[rch];
}


ll cal()
{
    ll tt = T[1];
    if (spl.empty())
        return tt;
    int smId = *spl.begin();
    upt(1, 1, cnt, smId, -1);
    int SZ = (int)spl.size();
    ll tmp = qy(1, 1, cnt, SZ);
    tt += tmp;
    upt(1, 1, cnt, smId, 1);
    return tt;
}
void fmain(int tid)
{
    scanf("%d", &n);
    REQ(i, n) scanf("%d%d", t + i, d + i);
    hsh();

    REQ(i, n)
    {
        if (d[i] > 0)
        { // add
            upt(1, 1, cnt, d[i], 1);
            if (t[i] == 1)
                spl.insert(d[i]);
        }
        else
        {
            upt(1, 1, cnt, -d[i], -1);
            if (t[i] == 1)
                spl.erase(-d[i]);
        }
        printf("%lld\n", cal());
    }
}
int main()
{
    int t = 1;
    //    scanf("%d", &t);
    //    init();
    REQ(i, t)
    {
        fmain(i);
    }
    return 0;
}
