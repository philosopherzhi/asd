﻿#include <bits/stdc++.h>


using namespace std;


mt19937 rnd(time(0));
#define ios                                                                                        \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(0);
#define fr first
#define sc second
#define pb push_back
#define all(x) x.begin(), x.end()
#define eb emplace_back
#define smin(x, y) x = min(x, y)
#define smax(x, y) x = max(x, y)
#define pii pair<int, int>
#define ld long double
#define int long long
#define pld pair<ld, ld>

const int N = 1e5 + 100;
const int inf = 1e18;
const int mod1 = 1e9 + 7;
const int mod2 = 998244353;


signed main()
{
    ios;
    int t;
    cin >> t;
    set<pii> s;
    set<pii> b;
    int sum = 0, balls = 0;
    int sumOfAll = 0;

    while (t--)
    {
        int tp, d;
        cin >> tp >> d;
        if (tp == 0)
        {
            if (d < 0)
            {
                d = -d;
                sumOfAll -= d;

                s.erase({ d, 0 });
                if (b.count({ d, 0 }))
                {
                    b.erase({ d, 0 });
                    sum -= d;
                    --balls;

                    auto q = *s.rbegin();
                    s.erase(q);

                    b.insert(q);
                    sum += q.fr;
                    if (q.sc == 0)
                        ++balls;
                };
            }
            else
            {
                sumOfAll += d;

                if (!b.empty() && d > (*b.begin()).fr)
                {
                    auto q = *b.begin();

                    b.insert({ d, 0 });
                    sum += d;
                    ++balls;

                    b.erase(q);
                    sum -= q.fr;
                    if (q.sc == 0)
                        --balls;

                    s.insert(q);
                }
                else
                    s.insert({ d, 0 });
            }
        }
        else
        {
            if (d < 0)
            {
                d = -d;
                sumOfAll -= d;

                if (b.count({ d, 1 }))
                {
                    b.erase({ d, 1 });
                    sum -= d;
                }
                else
                {
                    s.erase({ d, 1 });
                    auto q = *b.begin();

                    b.erase(q);
                    sum -= q.fr;
                    if (q.sc == 0)
                        --balls;

                    s.insert(q);
                }
            }
            else
            {
                sumOfAll += d;

                if (s.empty())
                {
                    b.insert({ d, 1 });
                    sum += d;
                }
                else
                {
                    auto q = *s.rbegin();
                    if (d > q.fr)
                    {
                        b.insert({ d, 1 });
                        sum += d;
                    }
                    else
                    {
                        s.insert({ d, 1 });
                        s.erase(q);

                        b.insert(q);
                        sum += q.fr;
                        if (q.sc == 0)
                            ++balls;
                    }
                }
            }
        }

        int res = sum;
        if (balls == 0)
        {
            if (!b.empty())
                res -= (*b.begin()).fr;
            if (!s.empty() && !b.empty())
                res += (*s.rbegin()).fr;
        }
        cout << max(0ll, res) + sumOfAll << '\n';
    }
}