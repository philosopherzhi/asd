﻿#include <bits/stdc++.h>

using namespace std;
#define rep(i, l, r) for (auto i = (l); i <= (r); ++i)
#define ll long long
#define N 1000010
int n, hs[N], ct, T;
pair<int, int> q[N];
ll sm[N << 2], tol[N << 2];
#define lson k << 1, l, m
#define rson k << 1 | 1, m + 1, r

inline void up(int k)
{
    sm[k] = sm[k << 1] + sm[k << 1 | 1], tol[k] = tol[k << 1] + tol[k << 1 | 1];
}

void add(int k, int l, int r, int x, int v)
{
    if (l == r)
    {
        sm[k] += v * hs[x], tol[k] += v;
        return;
    }
    int m = l + r >> 1;
    if (x <= m)
        add(lson, x, v);
    else
        add(rson, x, v);
    up(k);
}

multiset<int> s;

ll kth(int k, int l, int r, int K)
{
    if (tol[k] <= K)
        return sm[k];
    int m = l + r >> 1, rs = k << 1 | 1;
    if (tol[rs] >= K)
        return kth(rson, K);
    else
        return sm[rs] + kth(lson, K - tol[rs]);
}

inline void solve()
{
    ll ans = 0;
    rep(i, 1, T)
    {
        int x = q[i].second, op = q[i].first;
        if (x > 0)
        {
            ans += x;
            int o = lower_bound(hs + 1, hs + n + 1, x) - hs;
            add(1, 1, n, o, 1);
            if (op == 1)
                s.insert(o);
            if (!s.empty())
                add(1, 1, n, *s.begin(), -1);
            printf("%lld\n", ans + kth(1, 1, n, s.size()));
            if (!s.empty())
                add(1, 1, n, *s.begin(), 1);
        }
        else
        {
            ans += x;
            int o = lower_bound(hs + 1, hs + n + 1, -x) - hs;
            add(1, 1, n, o, -1);
            if (op == 1)
                s.erase(s.find(o));
            if (!s.empty())
                add(1, 1, n, *s.begin(), -1);
            printf("%lld\n", ans + kth(1, 1, n, s.size()));
            if (!s.empty())
                add(1, 1, n, *s.begin(), 1);
        }
    }
}

int main()
{
    T = 1;
    scanf("%d", &T);
    rep(i, 1, T) scanf("%d%d", &q[i].first, &q[i].second), hs[++ct] = abs(q[i].second);
    sort(hs + 1, hs + ct + 1);
    n = unique(hs + 1, hs + ct + 1) - hs - 1;
    solve();
}