﻿#include "bits/stdc++.h"
using namespace std;
const int N = 1e3 + 1;
int a, b, w, x, c, to[N], cycle[N];
bool chega(long long t)
{
    long long k, _a = a, _c = c - t, tt = 0, cnt = 0;
    memset(cycle, -1, sizeof cycle);
    for (k = b; t > 0; k = to[k])
    {
        --t;
        _a -= k < x;
        cycle[k] = tt++;
        if (cycle[to[k]] != -1)
        {
            tt = cycle[k] - cycle[to[k]] + 1;
            k = to[k];
            break;
        }
    }
    if (t == 0)
        return _a >= _c;
    for (int i = 0; i < tt; ++i, k = to[k])
        cnt += k < x;
    _a -= t / tt * cnt;
    t %= tt;
    for (int i = 0; i < t; ++i, k = to[k])
        _a -= k < x;
    return _a >= _c;
}
void solve()
{
    long long lo = 0, hi = 1000L * (0LL + c + a);
    while (lo < hi)
    {
        auto mid = (lo + hi) >> 1;
        if (chega(mid))
            hi = mid;
        else
            lo = mid + 1;
    }
    cout << hi << '\n';
}
signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cin >> a >> b >> w >> x >> c;
    for (int v = 0; v <= w; ++v)
    {
        if (v < x)
            to[v] = w - x + v;
        else
            to[v] = v - x;
    }
    solve();
    return 0;
}
