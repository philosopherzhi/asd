﻿#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const ll mod = 1000000007;

#define x first
#define y second

template <typename T>
istream& operator>>(istream& in, vector<T>& v)
{
    for (int i = 0; i < v.size(); i++)
    {
        in >> v[i];
    }
    return in;
}

template <typename T>
ostream& operator<<(ostream& out, vector<T> v)
{
    for (int i = 0; i < v.size(); i++)
    {
        out << v[i] << ' ';
    }
    return out;
}

ll calc(ll count, ll step, ll t, ll w, ll x, ll b)
{
    ll ans = t / count * step;
    t %= count;

    ll cnt = 0;

    while (t)
    {
        if (b < x)
        {
            b = w - x + b;
            cnt++;
        }
        else
            b -= x;
        t--;
    }

    return ans + cnt;
}

void solve()
{
    ll a, b, w, x, c;
    cin >> a >> b >> w >> x >> c;

    ll start = b;
    ll count = 0;
    ll step = 0;
    do
    {
        if (start < x)
        {
            start = w - x + start;
            step++;
        }
        else
            start -= x;
        count++;
    } while (start != b);

    ll l = 0, r = 1e18;

    cerr << count << ' ' << step << endl;
    while (l < r)
    {
        ll mid = (l + r) / 2;

        // printf("l = %lld, r = %lld, mid = %lld, calc = %lld\n", l, r, mid, calc(count, step, mid,
        // w, x, b));

        if (a - calc(count, step, mid, w, x, b) < c - mid)
            l = mid + 1;
        else
            r = mid;
    }

    cout << l;
}

int main()
{
#ifdef LOCAL
    freopen("input.in", "r", stdin);
    freopen("output.out", "w", stdout);
#endif
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int t = 1;
    //	cin >> t;
    while (t--)
    {
        solve();
    }
    return 0;
}