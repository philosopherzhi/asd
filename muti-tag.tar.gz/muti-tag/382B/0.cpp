﻿#include <bits/stdc++.h>
#define ll long long
#define endl "\n"
#define pb push_back
#define READ(FILE) freopen(FILE, "r", stdin)
#define WRITE(FILE) freopen(FILE, "w", stdout)
#define loop(i, s, e) for (int i = s; i < e; i++)
#define mego fast();
using namespace std;
void fast()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
}
ll lcm(ll x, ll y)
{
    return (x * y) / __gcd(x, y);
}
ll a, b, w, x, c, ans;
bool check(ll k)
{
    ll nb = (b - (k * x));
    ll na = a, ch = 0;
    if (nb <= 0)
    {
        ch = (abs(nb) / w) + ((abs(nb) % w) != 0);
    }
    return (c - k <= a - ch);
}
int main()
{
    mego cin >> a >> b >> w >> x >> c;
    // 1 2 3 2 6
    ll ta = a, tb = b, tc = c, ch = 0;
    int mns[w] = {};
    loop(i, 0, w)
    {
        tc--;
        tb -= x;
        if (tb < 0)
        {
            ta--;
            tb += w;
            ch++;
            mns[i]++;
        }
        // cout<<tb<<" "<<ta<<" "<<tc<<endl;
    }
    // cout<<ch;
    ll l = 0, r = 1e18;
    while (l < r)
    {
        ll mid = (l + r) / 2;
        ll cha = (mid / w);
        cha *= ch;
        loop(i, 0, (mid % w)) cha += mns[i];
        if (a - cha >= c - mid)
            r = mid;
        else
            l = mid + 1;
        // cout<<l<<" "<<r<<endl;
    }
    cout << r;
    return 0;
}
