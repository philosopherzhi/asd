﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    long long a, b, w, x, c;
    cin >> a >> b >> w >> x >> c;
    if (c <= a)
        cout << 0 << endl;
    else
    {
        long long ans = (ceil)((double)(a * w - w * c + b) / (double)(x - w));
        cout << ans << endl;
    }
    return 0;
}
