﻿#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll a, b, w, x, c, ans;

int main()
{
    cin >> a >> b >> w >> x >> c;
    if (c <= a)
    {
        cout << 0 << endl;
    }
    else
    {
        // b+=w-x;
        ans = ceil(1.0 * (x * (c - a) - b) / (w - x));
        cout << ans + c - a << endl;
    }
    return 0;
}
