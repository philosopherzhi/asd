﻿#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll INF = 1e15;
int main()
{
    ll a, b, w, c, x;
    cin >> a >> b >> w >> x >> c;
    ll l = 0, r = INF, res = INF;
    if (c <= a)
    {
        puts("0");
        return 0;
    }
    while (l <= r)
    {
        ll mid = l + r >> 1;
        //        cout<<mid<<endl;
        if (a >= c - (mid * (w - x) + b) / x)
        {
            r = mid - 1;
            res = mid;
        }
        else
            l = mid + 1;
    }
    //    cout<<res<<endl;

    res += (c - a);
    cout << res << endl;
}
