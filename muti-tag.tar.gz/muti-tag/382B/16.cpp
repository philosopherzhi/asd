﻿#include <bits/stdc++.h>
#define PI 3.141592653589793238462
using namespace std;
typedef long long ll;
typedef long double db;
ll vis[1005], p[1005], q[1005];
int main()
{
    ll a, b, w, x, c, num = 0;
    cin >> a >> b >> w >> x >> c;
    ll t = b, now = 1;
    while (!vis[t])
    {
        vis[t] = now;
        p[now] = p[now - 1] + t / x + 1;
        q[now] = q[now - 1] + 1;
        t = w - (x - t % x);
        now++;
    }
    for (int i = 1; i < now; i++)
    {
        if (c - p[i] <= a - q[i])
        {
            cout << p[i - 1] + (c - p[i - 1]) - (a - q[i - 1]) << endl;
            return 0;
        }
    }
    c -= p[vis[t] - 1];
    a -= q[vis[t] - 1];
    num += p[vis[t] - 1];
    ll dc = (p[now - 1] - p[vis[t] - 1]), da = (q[now - 1] - q[vis[t] - 1]),
       l = (c - a - 1) / (dc - da);
    num += l * dc;
    c -= l * dc, a -= l * da;
    while (c > a)
    {
        if (c - t / x <= a)
        {
            num += c - a;
            break;
        }
        c -= t / x + 1, a--;
        num += t / x + 1;
        t = w - (x - t % x);
    }
    cout << num << endl;
}