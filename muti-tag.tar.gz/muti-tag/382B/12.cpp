﻿#include <iostream>
long long a, b, w, x, c;
int main()
{
    std::cin >> a >> b >> w >> x >> c;
    std::cout << (a < c ? ((c - a) * x - b + (w - x - 1)) / (w - x) + c - a : 0);
} // hellobig_tq//hello