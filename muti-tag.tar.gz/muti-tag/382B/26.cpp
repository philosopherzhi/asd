﻿#include <algorithm>
#include <iostream>
#include <vector>
#include <cassert>
using namespace std;
const long long INF = 1LL << 60; // 1.15x10^18
template <class T>
T ceil(T a, T b)
{
    return a / b + !!(a % b);
}

void Arthur(long long& a, long long& b, long long w, long long x)
{
    if (b < x)
        a--, b += w;
    b -= x;
}

int main()
{
    long long a, b, w, x, c;
    cin >> a >> b >> w >> x >> c;
    auto check = [&](long long mid)
    {
        long long tmp = b - x * mid;
        if (tmp >= 0)
            return c - mid <= a;
        return c - mid <= a - ceil(-tmp, w);
    };
    auto binary_search = [&](long long ok, long long ng)
    {
        assert(check(ok) == true);
        assert(check(ng) == false);
        while (abs(ng - ok) > 1)
        {
            long long mid = (ng + ok) / 2;
            (check(mid) ? ok : ng) = mid;
        }
        return ok;
    };
    if (check(0))
        return !(cout << 0 << endl);
    cout << binary_search(INF, 0) << endl;
    return 0;
}
