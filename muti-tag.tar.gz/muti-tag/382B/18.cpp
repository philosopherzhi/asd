﻿#include <bits/stdc++.h>
using namespace std;
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/hash_policy.hpp>
//#pragma comment(linker, "/STACK:102400000,102400000")
using namespace __gnu_pbds;
#define _for(i, a, b) for (int i = (a); i < (b); ++i)
#define ms(a) memset(a, 0, sizeof(a))
#define ms_inf(a) memset(a, 0x3f, sizeof(a))
#define ms_ninf(a) memset(a, 0xcf, sizeof(a))
#define pb push_back
#define mp make_pair
#define fast ios::sync_with_stdio(0), cin.tie(0), cout.tie(0)
#define lc (o << 1)
#define rc (o << 1 | 1)
//#include<ext/pb_ds/priority_queue.hpp>
// typedef __gnu_pbds::priority_queue<no> heap;  //��ƫ��
typedef long long ll;
typedef unsigned long long ull;
ull MOD = 212370440130137957ll;
int mod = 1e9 + 7;
ll INF = 1e18;
const int maxn = 1e7 + 10;
const int maxl = 1e3 + 10;
const double PI = acos(-1.0);
const double eps = 1e-8;
int a, b, w, x, c;
ll ans;
inline void ch()
{
    if (c <= a)
    {
        cout << ans;
        exit(0);
    }
}
void tr()
{
    --c;
    ++ans;
    if (b >= x)
        b -= x;
    else
        b = w - (x - b), --a;
}
void tr(int& b)
{
    if (b >= x)
        b -= x;
    else
        b = w - (x - b);
}
int cy()
{
    int e = b;
    int cnt = 0;
    while (1)
    {
        tr(e);
        ++cnt;
        if (e == b)
        {
            return cnt;
        }
    }
}
int main()
{
    fast;
    cin >> a >> b >> w >> x >> c;
    _for(t, 0, 10000)
    {
        ch();
        tr();
    }
    int l = cy();
    ll da = a, dc = c;
    _for(t, 0, l)
    {
        ch();
        tr();
    }
    da -= a, dc -= c;
    ll d = dc - da;
    ll now = c - a;
    ll w = now / d;
    --w;
    w = max(0ll, w);
    c -= l * w, a -= w * da, ans += w * l;
    while (1)
    {
        ch();
        tr();
    }
}
