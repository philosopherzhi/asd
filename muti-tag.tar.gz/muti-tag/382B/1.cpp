﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    long long a, b, w, x, c;
    cin >> a >> b >> w >> x >> c;
    c -= a;
    w -= x;
    if (c <= 0)
        return 0 * printf("0\n");
    else
    {
        long long k = ceil((1.0 * (x * c - b)) / w);
        cout << c + k << endl;
    }
    return 0;
}
