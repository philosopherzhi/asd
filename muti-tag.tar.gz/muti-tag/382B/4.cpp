﻿#include <bits/stdc++.h>
#define int long long
using namespace std;

int a, b, w, x, c;

bool check(int k)
{
    int res = x * k - b;
    int aa;
    if (res < 0)
        aa = a;
    else
        aa = a - (res + w - 1) / w;
    return aa >= c - k;
}

signed main()
{
    // freopen("file.inp","r",stdin);
    cin >> a >> b >> w >> x >> c;
    int l = -1;
    int r = 1e18;
    while (r - l > 1)
    {
        int mid = (l + r) >> 1;
        if (check(mid))
            r = mid;
        else
            l = mid;
    }
    cout << r;
    return 0;
}
