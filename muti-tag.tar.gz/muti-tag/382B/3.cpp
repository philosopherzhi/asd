﻿#include <bits/stdc++.h>
//#include <ext/pb_ds/assoc_container.hpp>
//#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
// using namespace __gnu_pbds;

#define rep(i, a, b) for (ll i = (ll)(a); i < (ll)(b); i++)
#define pb push_back
#define mp make_pair
#define ff first
#define ss second
#define trace(x) cout << #x << ": " << x << endl
#define all(x) (x).begin(), (x).end()
#define sz(x) (x).size()
#define fill(x, v) memset(x, v, sizeof(x))
#define fastio                                                                                     \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0);                                                                                    \
    cout.tie(0);

typedef long long ll;
typedef unsigned long long ull;
typedef vector<ll> vi;
typedef pair<ll, ll> ii;
typedef vector<ii> vii;

const ll INF = 1LL << 62;

ll a, b, w, x, c;
ll sig[2000], tie[2000];
vi arr, cant;
bool check(ll n)
{
    ll ale = c - n;
    ll div = arr.size();
    ll aux = n / div;
    ll extra = aux * cant.back();
    extra = extra + cant[n % div];
    ll art = a - extra;
    if (b + x >= w)
        art++;
    //  trace(ale);
    // trace(art);
    return (ale <= art);
}

int main()
{
    cin >> a >> b >> w >> x >> c;
    ll ini = b;
    ll curr = ini;
    ll cantA = 1;
    if (b + x < w)
        cantA = 0;
    while (1)
    {
        //   cout << curr << " "  << cantA << endl;
        arr.pb(curr);
        cant.pb(cantA);
        if (curr >= x)
            curr -= x;
        else
        {
            curr = w - (x - curr);
            cantA++;
        }
        if (curr == ini)
            break;
    }

    ll low = 0;
    ll high = INF;
    while (low < high)
    {
        ll mid = (low + high) / 2LL;
        if (check(mid))
        {
            high = mid;
        }
        else
            low = mid + 1;
    }
    cout << low << endl;
    return 0;
}