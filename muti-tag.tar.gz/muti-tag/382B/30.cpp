﻿#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

template <typename T>
void out(T x)
{
    cout << x << endl;
    exit(0);
}
#define watch(x) cout << (#x) << " is " << (x) << endl

const int maxn = 1e6 + 5;

ll a, b, w, x, c;

struct node
{
    ll above, below, hi;
};

node get_cycle_len(ll b)
{
    ll hi = 0;
    for (int i = 0; i < 2000; i++)
    {
        if (b >= x)
        {
            b -= x;
        }
        else
        {
            b = w - (x - b);
        }
        hi = max(b, hi);
    }

    b = hi;
    ll b0 = hi;
    ll below = 0;
    ll above = 0;

    do
    {
        if (b0 >= x)
        {
            b0 -= x;
        }
        else
        {
            b0 = w - (x - b0);
        }
        above += b0 >= x;
        below += b0 < x;
    } while (b != b0);
    return { above, below, hi };
}


bool debug = true;
ll stupid(ll a, ll b, ll w, ll x, ll c)
{
    ll t = 0;
    if (debug)
        cout << endl << endl << "stupid" << endl;
    if (debug)
        cout << t << ": " << a << " " << b << " " << w << " " << x << " " << c << endl;
    while (c > a)
    {
        t++;
        c--;
        if (b >= x)
        {
            b -= x;
        }
        else
        {
            a--;
            b = w - (x - b);
        }
        if (debug)
            cout << t << ": " << a << " " << b << " " << w << " " << x << " " << c << endl;
    }
    if (debug)
        cout << endl << endl;
    return t;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    cin >> a >> b >> w >> x >> c;
    // stupid(a,b,w,x,c);

    if (c <= a)
        out(0);

    auto cycle = get_cycle_len(b);

    // cout<<cycle.above<<" "<<cycle.below<<" "<<cycle.hi<<endl;

    ll t = 0;
    while (b != cycle.hi)
    {
        if (c <= a)
            out(t);
        t++;
        c--;
        if (b >= x)
        {
            b -= x;
        }
        else
        {
            b = w - (x - b);
            a--;
        }
    }


    // if (debug) cout<<t<<": "<<a<<" "<<b<<" "<<w<<" "<<x<<" "<<c<<endl;
    ll iters = (c - a - 1) / cycle.above;
    // watch(iters); watch(cycle.above); watch(cycle.below);

    c -= iters * (cycle.above + cycle.below);
    a -= iters * cycle.below;

    b -= x * iters * (cycle.above + cycle.below);
    b += w * iters * cycle.below;

    t += iters * (cycle.above + cycle.below);

    // watch(t);
    // if (debug) cout<<t<<": "<<a<<" "<<b<<" "<<w<<" "<<x<<" "<<c<<endl;


    while (1)
    {
        if (c <= a)
            out(t);
        t++;
        c--;
        if (b >= x)
        {
            b -= x;
        }
        else
        {
            b = w - (x - b);
            a--;
        }
    }

    assert(0);

    return 0;
}
