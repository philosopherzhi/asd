﻿// time-limit: 1000
#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    long long a, b, w, x, c;
    cin >> a >> b >> w >> x >> c;
    long long inc = w - x;
    long long ans = LONG_LONG_MAX;
    long long lx = 0, rx = (long long)2e9 * 1000;
    vector<vector<long long>> dec(60, vector<long long>(w));
    vector<vector<int>> up(60, vector<int>(w));
    for (int i = 0; i < 60; i++)
    {
        for (int j = 0; j < w; j++)
        {
            if (i == 0)
            {
                up[i][j] = (j < x ? j + inc : j - x);
                dec[i][j] = (j < x ? 1 : 0);
            }
            else
            {
                up[i][j] = up[i - 1][up[i - 1][j]];
                dec[i][j] = dec[i - 1][j] + dec[i - 1][up[i - 1][j]];
            }
        }
    }
    auto check = [&](long long g)
    {
        long long a_dec = 0;
        int crr = b;
        for (long long i = 0; i < 60; i++)
        {
            if ((1LL << i) & g)
            {
                //				cout << "i : " << i << " crr : " << crr << '\n';
                a_dec += dec[i][crr];
                crr = up[i][crr];
                //				cout << a_dec << ' ';
            }
        }
        //		cout << '\n';
        long long new_a = a - a_dec;
        long long new_c = c - g;
        //		cout << new_a << ' ' << new_c << '\n';
        return new_c <= new_a;
    };
    while (lx <= rx)
    {
        long long g = lx + (rx - lx) / 2;
        if (check(g))
        {
            ans = g;
            rx = g - 1;
        }
        else
        {
            lx = g + 1;
        }
    }
    cout << ans << '\n';
    return 0;
}
