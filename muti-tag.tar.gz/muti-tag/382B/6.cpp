﻿#include <bits/stdc++.h>

using namespace std;

string str;
// int vn[100005] = {0};
// int l[500005] = {0};
// int r[500005] = {0};
// bool b[500005] = {0};

// int qn = 0;

struct myst
{
    int m, v, p;
    // char c;
    bool operator<(const myst a) const
    {
        return m == a.m ? v > a.v : m > a.m;
    }
};

priority_queue<myst> lq, rq;

int n, k, h;
myst val[100005];
const double gap = 0;
vector<int> v;
int temp[100005];
int fv[100005];

bool check(double d)
{
    int bs = k;
    for (int i = 0; i < n; ++i)
    {
        if (1.0 * bs * h <= val[i].v * (d + gap))
        {
            temp[k - bs] = val[i].p;
            bs--;
            if (bs == 0)
            {
                memcpy(fv, temp, k * sizeof(int));
                return true;
            }
        }
    }
    return false;
}

void output(double d)
{
    // int bs = k;
    // for (int i = 0; i < n; ++i) {
    // 	if (1.0 * bs * h <= val[i].v * (d + gap)) {
    // 		bs--;
    // 		v.push_back(val[i].p);
    // 		if (bs == 0)
    // 			break;
    // 	}
    // }
    for (int i = k - 1; i >= 0; i--)
        cout << fv[i] << " ";
    cout << endl;
}

double ef(double b, double e)
{
    if (b + gap >= e)
        return e;
    double half = (b + e) / 2;
    if (check(half))
        e = half;
    else
        b = half;
    return ef(b, e);
}

int main()
{
    int a, b, w, x, c;
    cin >> a >> b >> w >> x >> c;
    if (c <= a)
    {
        cout << 0 << endl;
        return 0;
    }
    vector<int> v;
    int val[1005] = { 0 };
    int gap = w - x;
    while (true)
    {
        if (val[b])
            break;
        val[b] = 1;
        if (b >= x)
            v.push_back(0);
        else
            v.push_back(1);
        b += gap;
        b %= w;
    }
    int circle = v.size();
    int cn = 0;
    for (int i = 0; i < circle; i++)
        if (v[i])
            cn++;
    gap = circle - cn;
    long long ret = 0;
    int round = (c - a) / gap;
    int yu = (c - a) % gap;
    ret = 1LL * round * circle;
    if (yu)
    {
        for (int i = 0; yu && i < circle; ++i)
        {
            ret++;
            if (!v[i])
            {
                yu--;
            }
        }
    }
    else
    {
        for (int i = circle - 1; i >= 0; i--)
            if (!v[i])
                break;
            else
                ret--;
    }
    cout << ret << endl;
    return 0;
}