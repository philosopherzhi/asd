﻿#include <bits/stdc++.h>
using namespace std;
long long pd(long long a, long long b)
{
    if (a % b != 0)
    {
        return a / b + 1;
    }
    else
    {
        return a / b;
    }
}
int main()
{
    long long a, b, w, x, c;
    cin >> a >> b >> w >> x >> c;
    long long ans = 0;
    if (c <= a)
    {
        cout << 0 << endl;
    }
    else
    {

        long long xx = c - a;
        long long t = pd(xx * x - b, w - x);
        cout << xx + t << endl;
    }

    return 0;
}
