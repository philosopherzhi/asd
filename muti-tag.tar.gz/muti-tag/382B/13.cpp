﻿#include <bits/stdc++.h>
#define pi acos(-1)
#define ll long long
#define pii pair<ll, ll>
#define debug(a) cout << a << '\n'
#define maxn 100009 /// I wanna be a marshmello
#define MOD 1000000007
#define F first
#define S second
#define rep(i, a, b) for (ll i = a; i < (b); ++i)
#define per(i, b, a) for (ll i = b - 1; i >= a; i--)
#define trav(a, x) for (auto& a : x)
#define allin(a, x) for (auto a : x)
#define all(x) begin(x), end(x)
#define sz(x) (ll)(x).size()
using namespace std;
const ll INF = 1e17 + 9;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    ll a, b, w, x, c;
    cin >> a >> b >> w >> x >> c;
    if (c <= a)
    {
        cout << 0 << '\n';
        return 0;
    }
    cout << c - a + (((c - a) * x - b) + w - x - 1) / (w - x) << '\n';
    return 0;
}