﻿#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")
#pragma GCC target("sse4")
#include "bits/stdc++.h"
using namespace std;
typedef long long ll;
#define int ll
#define all(x) x.begin(), x.end()
#define trav(i, a) for (auto& i : a)
inline int in()
{
    int x;
    scanf("%lld", &x);
    return x;
}
int32_t main()
{
    int a, b, w, x, c;
    cin >> a >> b >> w >> x >> c;
    int ans = 0;
    int d = x - w;
    if (a < c)
        ans = (((a - c) * w) + b + d + 1) / d;

    cout << ans;
}
