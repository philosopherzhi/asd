﻿#include <bits/stdc++.h>

using namespace std;

typedef long long tint;
typedef long double ld;

#define forsn(i, s, n) for (int i = s; i < int(n); i++)
#define forn(i, n) forsn(i, 0, n)
#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define NACHO                                                                                      \
    {                                                                                              \
        ios::sync_with_stdio(false);                                                               \
        cin.tie(nullptr);                                                                          \
    }
#define DBG(x) cerr << #x << " = " << (x) << endl;
#define dbg cerr << "HUH" << endl;

const int INF = 99009000;
const tint MOD = 1000000007;
const int N = 100001;

int main()
{
    NACHO;
    // Pensalo en base w!
    tint a, b, w, x, c;
    cin >> a >> b >> w >> x >> c;
    tint A = a * w + b;
    tint B = w * c;
    tint dif = B - A;
    if (dif <= 0)
        cout << 0 << "\n";
    else
        cout << (dif + w - x - 1) / (w - x) << "\n";
}
