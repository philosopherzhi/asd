﻿#include <bits/stdc++.h>
#include <array>
#define nguyendz the_best


#define ll long long
#define ld long double
#define pb push_back
#define all(n) n.begin(), n.end()
#define eb emplace_back
#define endl "\n"
#define pll pair<ll, ll>
#define YES cout << "YES" << endl;
#define NO cout << "NO" << endl;
#define ff first
#define ss second
#define setpre(x) fixed << setprecision(x)

using namespace std;
const ll maxn = 1e5 + 100;

const ll maxx = 1e13;
const ll mod1 = 1000000007;
const ll mod = 998244353;
priority_queue<pll, vector<pll>, greater<pll>> q;
vector<ll> adj[maxn];
vector<ll> adj1[maxn];
/*do not use "\n" in interactive problem
((x|y)-y) (x&(~y))
__gcd(fibo(x),fibo(y)=fibo(__gcd(x,y))
so luong tap hop gom d phan tu khac nhau dc tao tu k so phan biet la k mu d
a+b=(a^b)+2*(a&b)
giai 1 bai toan ve n cac cap (xi,yi) ta thuong swap(xi,yi) neu xi>yi ,  sort theo x1 roi chay tu
i->n va tim max hoac min 1-> i-1 cua yi dua tren DK:(xi<yi)*/


struct tk
{
    ll x, y;
};
tk a[maxn];
bool lf(tk a, tk b)
{
    return (a.x >= b.x);
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    ll a, b, w, x, c;
    cin >> a >> b >> w >> x >> c;
    ll t = w - x;
    ll h = 1e15;
    if (t < 1e9)
    {
        h = 1e15;
    }
    else
    {
        h = 1e9;
    }
    ll l = 0;
    ll kc = c - a;
    if (kc == 0)
    {
        cout << 0;
        return 0;
    }
    while (l <= h)
    {
        ll m = (l + h) / 2;
        ll k = b + m * t;
        ll mx1 = k / x;
        if (mx1 >= kc)
            h = m - 1;
        else
            l = m + 1;
    }
    // cout <<l<<endl;
    cout << l + kc;
}
