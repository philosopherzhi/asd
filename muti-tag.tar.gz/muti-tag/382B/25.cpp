﻿#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define __                                                                                         \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0);
#define fi first
#define se second
#define pb push_back
#define all(x) x.begin(), x.end()
#define forn(i, a, n) for (int i = a; i < n; i++)
typedef long long int lli;
typedef long double Double;
typedef pair<lli, lli> pii;
typedef vector<int> vi;
typedef vector<vi> vvi;

lli a, b, w, x, c;
lli operaciones, quita;

bool can(lli t)
{
    lli mov = 0;
    lli cc = c, ca = a, cb = b;
    c -= t;

    lli veces = t / operaciones;
    t -= veces * operaciones;
    a -= veces * quita;

    while (t > 0)
    {
        // cout << "t es " << t << endl;
        // cout << "b entra " << b << endl;
        if (b < x)
        {
            lli moves = abs(b - x) / (w - x);
            if (abs(b - x) % (w - x))
                moves++;
            moves = min(moves, t);
            b += moves * (w - x);
            a -= moves;
            t -= moves;
            // cout << "le quito a A " << moves <<" queda " << a << endl;
        }
        else
        {
            // cout << "es mayor\n";
            lli moves = abs(b - x + 1) / x;
            if (abs(b - x + 1) % x)
                moves++;
            moves = min(moves, t);
            t -= moves;
            b -= moves * (x);
            // cout << "la dejo pasar " << moves << " veces\n";
        }
    }
    // cout << "a sale " << a << " c sale " << c << endl;
    bool f = (c <= a);
    c = cc, a = ca, b = cb;
    return f;
}

int main()
{
    __ cin >> a >> b >> w >> x >> c;

    operaciones = 0ll, quita = 0ll;
    set<lli> s;
    lli cb = b, ca = a;
    vector<lli> last, prefo, prefquita;
    while (true)
    {
        if (s.find(b) != s.end())
        {
            // hallar donde empieza el ciclo
            for (int i = 0; i < last.size(); i++)
            {
                if (last[i] == b && i)
                {
                    operaciones -= prefo[i - 1];
                    quita -= prefquita[i - 1];
                    break;
                }
            }
            break;
        }

        last.pb(b);
        s.insert(b);

        if (b < x)
        {
            lli moves = abs(b - x) / (w - x);
            if (abs(b - x) % (w - x))
                moves++;
            b += moves * (w - x);
            operaciones += moves;
            quita += moves;
        }
        else
        {
            lli moves = abs(b - x + 1) / x;
            if (abs(b - x + 1) % x)
                moves++;
            b -= moves * (x);
            operaciones += moves;
        }
        prefo.pb(operaciones);
        prefquita.pb(quita);
    }

    b = cb, a = ca;

    lli ans = -1;
    lli l = 0, r = 1e15;
    while (l <= r)
    {
        lli m = (l + r) / 2ll;
        if (can(m))
        {
            ans = m;
            r = m - 1;
        }
        else
            l = m + 1;
    }
    cout << ans << endl;

    return 0;
}
