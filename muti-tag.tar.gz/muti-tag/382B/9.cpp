﻿#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn = 1e5 + 5;
ll a, b, w, x, c, ans;
inline bool ck(ll u)
{
    ll v = a - (b + u * x) / w;
    ll vv = c - u;
    return vv > v;
}
int main()
{
    cin.tie(0);
    cout.tie(0);
    ios::sync_with_stdio(false);
    cin >> a >> b >> w >> x >> c;
    ans = 1e18 + 5;
    ll l = 0, r = 1e18, mid;
    if (c <= a)
    {
        cout << 0 << endl;
        return 0;
    }
    b = w - b - 1;
    while (l <= r)
    {
        mid = (l + r) / 2;
        if (ck(mid))
            l = mid + 1;
        else
            r = mid - 1;
    }
    cout << l << endl;
    return 0;
}
