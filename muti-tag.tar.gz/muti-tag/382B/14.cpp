﻿//#pragma GCC optimize("Ofast")
//#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <set>
#include <queue>
#include <cmath>
#include <unordered_set>
#include <unordered_map>
#include <iomanip>
#include <deque>

using namespace std;

typedef long long li;
typedef long double ld;

const li MAX = 2e3 + 2;
li inf = (li)2e18;
li mod = (li)998244353;

li a, b, w, x, c;
li pref[MAX];
int main()
{
    ios::sync_with_stdio(0);
    cin >> a >> b >> w >> x >> c;
    li t = 0;
    while (b >= x)
    {
        if (c <= a)
            break;
        b -= x;
        c--;
        t++;
    }
    if (c <= a)
    {
        cout << t << "\n";
        return 0;
    }
    li cur = 2;
    li startval = b;
    pref[1] = 0;
    b = w + b - x;
    while (b != startval)
    {
        if (b >= x)
        {
            pref[cur] = pref[cur - 1] + 1;
            cur++;
            b -= x;
        }
        else
        {
            b = w + b - x;
            pref[cur] = pref[cur - 1];
            cur++;
        }
    }
    cur--;
    li uk1 = 1, uk2 = (li)1e18;
    while (uk2 - uk1 > 1)
    {
        li mid = (uk2 + uk1) / 2;
        li val = (mid / cur) * pref[cur];
        val += pref[mid % cur];
        if (val >= c - a)
            uk2 = mid;
        else
            uk1 = mid;
    }
    cout << uk2 + t;
    return 0;
}
