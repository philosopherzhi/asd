﻿#include <bits/stdc++.h>
using namespace std;
long long a, b, w, x, c;

int main()
{
    cin >> a >> b >> w >> x >> c;
    cout << ((a >= c) ? 0LL : (w * c - b - w * a + w - x - 1LL) / (w - x)) << endl;
}
