﻿/* ----- Code By Nilesh Gupta -----*/
#include <bits/stdc++.h>
#define ll long long
#define ld long double
#define pb push_back
#define mod 1000000009
#define vi vector<ll>
#define pp pair<ll, ll>
#define ff first
#define ss second
#define all(n) n.begin(), n.end()
#define INF 1e9

using namespace std;

void init()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
}

vi vec_n(ll n)
{
    vi v(n);
    for (ll i = 0; i < n; i++)
        cin >> v[i];
    return v;
}

int main()
{
    init();

    ll t = 1;
    cin >> t;
    while (t--)
    {
        ll q, d;
        cin >> q >> d;
        ll fac[10];
        for (ll i = 0; i < 10; i++)
            fac[i] = d * (i + 1);
        while (q--)
        {
            ll num;
            cin >> num;
            if (num >= 10 * d)
            {
                cout << "YES"
                     << "\n";
                continue;
            }
            bool fg = false;
            for (ll i = 0; i < 10; i++)
            {
                if (fac[i] > num)
                    break;
                if (fac[i] % 10 == num % 10)
                {
                    fg = true;
                    break;
                }
            }
            if (fg)
                cout << "YES"
                     << "\n";
            else
                cout << "NO"
                     << "\n";
        }
    }
}