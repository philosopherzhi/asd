﻿#include <bits/stdc++.h>
using namespace std;
bool nz(int dp[100], int a, int d)
{
    if (a - d <= 0)
    {
        if (a == d)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    if (dp[a] != -1)
    {
        return dp[a];
    }

    else
    {
        int t = a - d;
        int p = t / 10;
        bool b = 0;
        for (int i = 0; i < p + 1; i++)
        {
            b += nz(dp, t - (10 * i), d);
        }
        dp[a] = b;
        return dp[a];
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    //................................................................//
    int t;
    cin >> t;
    while (t--)
    {
        int n, d;
        cin >> n >> d;
        int dp[100];
        for (int i = 0; i < 100; i++)
        {
            dp[i] = -1;
        }
        while (n--)
        {
            int a;
            cin >> a;
            if (a >= 10 * d or (a - d) % 10 == 0)
            {
                cout << "YES" << endl;
            }
            else
            {
                if (nz(dp, a, d))
                {
                    cout << "YES" << endl;
                }
                else
                {
                    cout << "NO" << endl;
                }
            }
        }
    }


    return 0;
}