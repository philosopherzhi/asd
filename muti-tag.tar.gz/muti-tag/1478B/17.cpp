﻿#include <iostream>
#include <cmath>
#include <cstring>
using namespace std;
int get(int i, int d)
{
    if (i >= d * 10 || i % d == 0)
        return 1;
    while (i > 0)
    {
        i -= d;
        if (i % 10 == 0)
            return 1;
    }
    return 0;
}
int t, q, n, d;
int main()
{
    cin >> t;
    while (t--)
    {
        cin >> n >> d;
        while (n--)
        {
            cin >> q;
            if (get(q, d))
                cout << "YES" << endl;
            else
                cout << "NO" << endl;
        }
    }
}