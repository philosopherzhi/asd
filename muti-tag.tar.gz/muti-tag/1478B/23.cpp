﻿#include <bits/stdc++.h>
using namespace std;
#pragma GCC optimize("Ofast")
#pragma GCC target("avx,avx2,fma")
#define PI 2 * acos(0)
#define ones(n) __builtin_popcount(n)
#define FAST ios::sync_with_stdio(0), cin.tie(0), cout.tie(0)
#define debug(x) cerr << #x << " = " << x << '\n';
#define LOOP printf("LOOP!!")
#define INF (int)1e9
#define YES cout << "YES" << '\n';
#define NO cout << "NO" << '\n';
#define TIME cerr << "\nTime:" << 1000 * clock() / CLOCKS_PER_SEC << " ms\n";
#define READ freopen("input.txt", "r", stdin)
#define PRINT freopen("output.txt", "w", stdout);
#define print(a, b) printf("Case %d: %d\n", a, b)
#define all(x) (x).begin(), (x).end()
#define allr(x) (x).rbegin(), (x).rend()
#define ll long long
#define MOD 1000000007
#define TEST printf("Case %d: ", c++);
#define ull unsigned long long
bool getit(int n, int k)
{

    while (n)
    {
        if (n % 10 == k)
            return 1;
        n /= 10;
    }

    return 0;
}

int main()
{
    FAST;

    int t;
    cin >> t;
    while (t--)
    {

        int n, k;
        cin >> n >> k;
        while (n--)
        {
            int d;
            cin >> d;
            bool ok = false;

            for (int i = 1; i <= 500; i++)
            {

                if (getit(d, k))
                {
                    ok = true;
                    break;
                }
                d -= k;
            }

            ok ? puts("YES") : puts("NO");
        }
    }

    return 0;
}