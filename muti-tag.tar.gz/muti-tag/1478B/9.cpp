﻿#include <bits/stdc++.h>
typedef long long ll;
typedef long double re;
#define fr(i, l, n) for (ll i = l; i < n; i++)
#define al(fu) (fu).begin(), (fu).end()
#define alr(fu) (fu).rbegin(), (fu).rend()
#define skoree                                                                                     \
    ios::sync_with_stdio(0);                                                                       \
    cin.tie(0)
#define br cout << "\n"
#define pr(c) cout << c << "\n"
#define pr2(c1, c2) cout << c1 << ' ' << c2 << "\n"
#define pr3(c1, c2, c3) cout << c1 << ' ' << c2 << ' ' << c3 << "\n"
#define prv(v)                                                                                     \
    {                                                                                              \
        fr(qz, 0, v.size()) cout << (v)[qz] << ' ';                                                \
        br;                                                                                        \
    }
#define danet(b) cout << (b ? "Yes" : "No") << "\n"
using namespace std;
const ll nh = 100000, mod = 1000000007, mod1 = 998244353, nfi = 1000000000000000013;

int main()
{
    skoree;
    ll o0o;
    cin >> o0o;
    while (o0o--)
    {
        ll n, k;
        cin >> n >> k;
        while (n--)
        {
            ll a;
            cin >> a;
            if (a / 10 >= k)
            {
                danet(1);
                continue;
            }
            while (a > 0 && a % 10 != k)
                a -= k;
            danet(a >= 0);
        }
    }
    return 0;
}

/*
*/
