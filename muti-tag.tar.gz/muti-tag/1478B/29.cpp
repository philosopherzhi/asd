﻿#include <bits/stdc++.h>
using namespace std;
#define fo(i, n1, n2) for (int i = n1; i < n2; i++)
#define comp 1e-9
#define F first
#define S second
#define pb push_back
#define mp make_pair
typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pi;
string solve(int a, int k)
{

    if (a >= k * 10)
        return "YES";
    else
        for (int i = 1; i <= 9; i++)
        {
            if ((a - k * i) >= 0 && (a - k * i) % 10 == 0)
                return "YES";
        }

    return "NO";
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int t;
    cin >> t;
    while (t--)
    {
        int n, k;
        cin >> n >> k;
        int a[n];
        fo(i, 0, n) cin >> a[i];
        for (int i = 0; i < n; i++)
            cout << solve(a[i], k) << "\n";
    }
}