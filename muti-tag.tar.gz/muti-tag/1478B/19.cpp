﻿#include <bits/stdc++.h>
using namespace std;
#define int long long
#define pi (3.141592653589)
#define mod 1000000007
#define float double
#define pb push_back
#define mp make_pair
#define ff first
#define ss second
#define lb lower_bound
#define trav(a, x) for (auto& a : x)
#define ub upper_bound
#define all(x) x.begin(), x.end()
#define rev(i, n, init) for (int i = n; i >= init; i--)
#define rep(i, j, n) for (int i = j; i < n; i++)
typedef pair<int, int> PII;
typedef vector<int> VI;
typedef vector<PII> VPII;
typedef vector<VI> VVI;
typedef map<int, int> MPII;
typedef set<int> SETI;
typedef multiset<int> MSETI;
const long long INF = 1e18;
const int32_t M = 1e9 + 7;
const int32_t MM = 998244353;
const int N = 10000;


void solve()
{
    int q, d;
    cin >> q >> d;
    VI a(q);
    rep(i, 0, q) cin >> a[i];
    rep(i, 0, q)
    {
        if (a[i] >= 10 * d)
            cout << "YES\n";
        else
        {
            a[i] -= d;
            while (a[i] % 10 != 0 && a[i] > 0)
            {
                a[i] -= d;
            }
            if (a[i] % 10 == 0)
            {
                cout << "YES\n";
            }
            else
            {
                cout << "NO\n";
            }
        }
    }
}
int32_t main()
{
    ios_base::sync_with_stdio(false), cin.tie(nullptr), cout.tie(nullptr);
    // freopen("input.txt","r",stdin);
    // freopen("output.txt","w",stdout);
    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
    return 0;
}
