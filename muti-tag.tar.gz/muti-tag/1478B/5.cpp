﻿#include <bits/stdc++.h>
#define int long long int
#define endl '\n'
#define pb push_back
#define vect vector<int>
#define mod 998244353

using namespace std;


#undef int
int main()
{
#define int long long int
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int t;
    cin >> t;

    while (t--)
    {
        int q, d;
        cin >> q >> d;
        vect v(q);
        for (auto& i : v)
            cin >> i;

        if (d == 1)
        {
            for (auto i : v)
                cout << "YES" << endl;
            continue;
        }

        for (int i = 0; i < q; i++)
        {
            if (10 * d <= v[i])
            {
                cout << "YES" << endl;
                continue;
            }

            int flag = 0;
            for (int j = d; j <= v[i]; j += d)
            {

                if (j == v[i])
                {
                    flag = 1;
                    break;
                }

                int p = v[i] - j;
                while (p)
                {
                    int q = p % 10;
                    if (q == d)
                    {
                        flag = 1;
                        break;
                    }
                    p = p / 10;
                }
                if (flag)
                    break;
            }

            int p = v[i];
            while (p)
            {
                int q = p % 10;
                if (q == d)
                {
                    flag = 1;
                    break;
                }
                p = p / 10;
            }

            if (!flag)
                cout << "NO" << endl;
            else
                cout << "YES" << endl;
        }
    }

    return 0;
}