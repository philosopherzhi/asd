﻿#include <bits/stdc++.h>
typedef long long ll;
#define sz(x) (int) x.size()
#define all(x) x.begin(), x.end()

using namespace std;

int dp[101];

void solve()
{
    int q, d;
    cin >> q >> d;
    int a;
    while (q--)
    {
        cin >> a;
        if (a >= 10 * d)
        {
            cout << "YES" << endl;
            continue;
        }
        vector<int> lucky;
        for (int i = 0; i < a; i++)
            lucky.push_back(d + 10 * i);
        memset(dp, 0, sizeof dp);
        dp[0] = 1;
        for (int i = 1; i <= a; i++)
        {
            for (auto l : lucky)
            {
                if (i - l < 0)
                    continue;
                dp[i] += dp[i - l];
            }
        }
        if (dp[a] > 0)
            cout << "YES" << endl;
        else
            cout << "NO" << endl;
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin >> t;
    while (t--)
        solve();
    return 0;
}