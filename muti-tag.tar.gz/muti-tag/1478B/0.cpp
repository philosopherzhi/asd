﻿#include <stdio.h>
#include <stdlib.h>
typedef long long int ll;
int main()
{
    int t, i;
    scanf("%d", &t);
    for (i = 0; i < t; i++)
    {
        ll q, x, j, k;
        int d;
        scanf("%lld%d", &q, &d);
        ll mx = 10 * d;
        int mat[105] = { 0 };
        for (j = 0; j <= 10; j++)
        {
            mat[j * d] = 1;
        }
        for (j = 0; j <= 10; j++)
        {
            mat[j * 10 + d] = 1;
        }
        for (j = d + 1; j <= mx; j++)
        {
            mat[j] = mat[j] | mat[j - d];
        }
        for (j = 0; j < q; j++)
        {
            scanf("%lld", &x);
            if (x >= 10 * d)
            {
                printf("YES\n");
            }
            else if (mat[x] == 1)
            {
                printf("YES\n");
            }
            else
            {
                printf("NO\n");
            }
        }
    }
    return 0;
}