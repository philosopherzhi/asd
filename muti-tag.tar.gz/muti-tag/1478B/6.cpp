﻿#include <iostream>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        long long int n;
        cin >> n;
        long long int k;
        cin >> k;
        long long int arr[n];
        bool dp[n];
        for (int i = 0; i < n; i++)
        {
            cin >> arr[i];
            if (arr[i] >= 10 * k || arr[i] % k == 0)
            {
                dp[i] = true;
            }
            else
            {
                int num = arr[i];
                while (num >= k)
                {
                    if (num % k == 0)
                    {
                        dp[i] = true;
                        break;
                    }
                    num = num - 10;
                }
                if (num < k)
                    dp[i] = false;
            }
        }
        for (int i = 0; i < n; i++)
        {
            if (dp[i])
                cout << "YES" << endl;
            else
                cout << "NO" << endl;
        }
    }
    return 0;
}