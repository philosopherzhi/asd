﻿#include <bits/stdc++.h>
using namespace std;
typedef long long int lln;
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
#define fo(i, j, n) for (lln i = j; i < n; i++)
#define pb push_back
#define ff first
#define ss second
int f(lln n)
{
    if (n > 1)
    {
        lln f = 1;
        for (lln i = 2; i <= n; i++)
            f = f * i;
        return f;
    }
    else
        return 1;
}
bool isprime(lln n)
{
    if (n == 1)
        return false;
    else
    {
        for (lln i = 2; i <= sqrt(n); i++)
            if (n % i == 0)
                return false;
        return true;
    }
}
vector<pair<lln, lln> > primefac(lln n)
{
    vector<pair<lln, lln> > a;
    lln temp, test = 1, count;

    for (lln i = 2; i <= sqrt(n); i++)
    {
        if (n % i == 0 && isprime(i))
        {
            temp = n;
            count = 0;
            while (temp % i == 0)
            {
                count++;
                temp = temp / i;
            }
            a.pb({ i, count });
            test = pow(i, count) * test;
        }
    }
    if (test != n)
        a.pb({ n / test, 1 });
    return a;
}
vector<lln> fac(lln n)
{ // factors of n
    vector<lln> a;
    for (lln i = 1; i <= sqrt(n); i++)
    {
        if (n % i == 0)
        {
            if (i != n / i)
            {
                a.pb(i);
                a.pb(n / i);
            }
            else
                a.pb(i);
        }
    }
    return a;
}
bool sortbysec(const pair<lln, lln>& a, const pair<lln, lln>& b)
{
    return (a.second < b.second);
}
lln gcd(lln a, lln b) // b>a
{
    if (a == 0)
        return b;
    else if (b == 0)
        return a;
    else
        return gcd(b % a, a);
}
lln ncr(lln n, lln r)
{
    return (f(n) / (f(r) * f(n - r)));
}
vector<int> primev;
void SieveOfEratosthenes(int n)
{
    bool prime[n + 1];
    memset(prime, true, sizeof(prime));

    for (int p = 2; p * p <= n; p++)
    {
        if (prime[p] == true)
        {
            for (int i = p * p; i <= n; i += p)
                prime[i] = false;
        }
    }
    for (int p = 2; p <= n; p++)
        if (prime[p])
            primev.pb(p);
}
lln fibona(lln n)
{
    lln a[21];
    a[0] = 1;
    a[1] = 1;
    a[2] = 2;
    for (lln i = 3; i <= 20; i++)
        a[i] = a[i - 1] + a[i - 2];

    return a[n];
}
void solve()
{
    lln q, d;
    cin >> q >> d;
    while (q--)
    {
        lln n;
        cin >> n;
        if (n >= 10 * d || n % 10 == d || n % d == 0)
        {
            cout << "YES\n";
        }
        else
        {
            vector<lln> v;
            for (lln i = 0; i < d; i++)
                v.pb(10 * i + d);
            lln dp[10 * d] = {};
            dp[0] = 1;
            for (lln i = 0; i < 10 * d; i++)
            {
                for (lln j = 0; j < v.size(); j++)
                {
                    if ((i - v[j]) >= 0)
                        dp[i] = dp[i - v[j]] | dp[i];
                }
            }
            if (dp[n] == 1)
                cout << "YES\n";
            else
                cout << "NO\n";
        }
    }
}
int main()
{
    // For getting input from input.txt file
    // freopen("input.txt", "r", stdin);
    // Printing the Output to output.txt file
    // freopen("output.txt", "w", stdout);
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    // t=1;
    cin >> t;

    while (t--)
    {

        solve();
    }
    return 0;
}