﻿#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define deb(a) cerr << #a << " = " << a << "\n";
#define f first
#define s second
#define sz(s) (int)(s).size()
#define all(x) (x).begin(), (x).end()
#define file()                                                                                     \
    {                                                                                              \
        ifstream cin("input.txt");                                                                 \
        ofstream cout("output.txt");                                                               \
    }
#define correct(x, y, n, m) (0 <= (x) && (x) < (n) && 0 <= (y) && (y) < (m))
#define int long long

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;

const ll INF = 2e18;
const ll mod = 1e9 + 7;
const int inf = 1e9;
const ld EPS = 1e-8;
const ld Pi = acosl(-1);
const int P = 31;
const int dx[4] = { 0, 0, 1, -1 };
const int dy[4] = { 1, -1, 0, 0 };

int qqq = 1;

mt19937 rnd(chrono::steady_clock::now().time_since_epoch().count());

int n, q, d;

bool check(int n, int d)
{
    while (n)
    {
        if (n % 10 == d)
            return 1;
        n /= 10;
    }
    return 0;
}

void solve()
{
    cin >> q >> d;
    for (int i = 0, x; i < q; i++)
    {
        cin >> x;
        if (x >= d * 10)
        {
            cout << "YES\n";
        }
        else
        {
            bool f = 0;
            while (x > 0)
            {
                if (check(x, d))
                {
                    f = 1;
                    break;
                }
                x -= d;
            }
            if (x == 0 || f)
            {
                cout << "YES\n";
            }
            else
            {
                cout << "NO\n";
            }
        }
    }
}

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> qqq;
    while (qqq--)
    {
        solve();
    }
    return 0;
}
