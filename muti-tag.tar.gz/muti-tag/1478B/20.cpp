﻿#pragma GCC optimize("Ofast")
#pragma GCC target("avx,avx2,fma")
#pragma GCC optimization("unroll-loops")

#include <bits/stdc++.h>
#define readFast                                                                                   \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0);                                                                                    \
    cout.tie(0);
#define fin cin
#define ll long long
#define sz(x) (int)(x).size()
#define all(v) v.begin(), v.end()
#define output(x) ((int)x && cout << "YES\n") || cout << "NO\n";
using namespace std;


vector<string> vec_splitter(string s)
{
    s += ',';
    vector<string> res;
    while (!s.empty())
    {
        res.push_back(s.substr(0, s.find(',')));
        s = s.substr(s.find(',') + 1);
    }
    return res;
}
void debug_out(vector<string> __attribute__((unused)) args, __attribute__((unused)) int idx,
    __attribute__((unused)) int LINE_NUM)
{
    cerr << endl;
}
template <typename Head, typename... Tail>
void debug_out(vector<string> args, int idx, int LINE_NUM, Head H, Tail... T)
{
    if (idx > 0)
        cerr << ", ";
    else
        cerr << "Line(" << LINE_NUM << ") ";
    stringstream ss;
    ss << H;
    cerr << args[idx] << " = " << ss.str();
    debug_out(args, idx + 1, LINE_NUM, T...);
}
#ifdef LOCAL
#define debug(...) debug_out(vec_splitter(#__VA_ARGS__), 0, __LINE__, __VA_ARGS__)
#else
#define debug(...) 42
#endif

const int N = 1e4 + 5;
const int MOD = 1e9 + 7;
int t;
int n, v[N], d;


bool haveD(int x)
{
    while (x)
    {
        if (x % 10 == d)
            return true;
        x /= 10;
    }
    return false;
}

int main()
{
    // ifstream fin("date.in.txt");
    readFast;
    fin >> t;

    while (t--)
    {
        fin >> n >> d;
        for (int i = 1; i <= n; ++i)
            fin >> v[i];
        map<int, int> cifra;
        for (int i = 1; i <= 10; ++i)
        {
            if (cifra[i * d % 10] == 0)
                cifra[i * d % 10] = i * d;
            // cout << i * d % 10 << " " << i * d << '\n';
        }


        for (int i = 1; i <= n; ++i)
        {
            int x = v[i];

            if (v[i] < d * 10)
            {
                bool found = false;
                while (v[i])
                {
                    // cout <<v[i] << " " << cifra[v[i] % 10] << '\n';
                    if (cifra[v[i] % 10] != 0 && v[i] >= cifra[v[i] % 10])
                    {
                        found = true;
                        break;
                    }
                    v[i] /= 10;
                }
                output(found);
            }
            else
                output(true);
        }
    }

    return 0;
} /*stuff you should look for
       * int overflow, array bounds
       * special cases (n=1?)
       * do smth instead of nothing and stay organized
       * WRITE STUFF DOWN
       * DON'T GET STUCK ON ONE APPROACH
~Benq~*/
