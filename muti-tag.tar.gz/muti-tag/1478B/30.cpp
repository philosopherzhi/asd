﻿#include <bits/stdc++.h>
using namespace std;
#define fastio                                                                                     \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(NULL)
#define endl '\n'
#define ll long long int
#define append push_back

// vector<bool> sieve(ll n)
// {
//     vector<bool> prime(n + 1, true);
//     for (ll p = 2; p * p <= n; p++)
//     {
//         if (prime[p] == true)
//         {
//             for (ll i = p * p; i <= n; i += p)
//                 prime[i] = false;
//         }
//     }
//     prime[0] = false;
//     prime[1] = false;
//     return prime;
// }

void printvec(vector<ll>& v)
{
    for (ll elem : v)
    {
        cout << elem << " ";
    }
    cout << '\n';
}

void print2dvec(vector<vector<ll>>& v)
{
    for (vector<ll> vec : v)
    {
        for (ll elem : vec)
        {
            cout << elem << " ";
        }
        cout << '\n';
    }
}

bool check(ll i, ll d)
{
    ll n;
    while (i > 0)
    {
        n = i % 10;
        i = i / 10;
        if (n == d)
        {
            return true;
        }
    }
    return false;
}

void solve()
{
    ll t;
    cin >> t;
    while (t--)
    {
        ll q, d;
        cin >> q >> d;
        vector<ll> a(q + 1);
        bool ans;
        for (ll i = 1; i <= q; ++i)
        {
            ans = false;
            cin >> a[i];
            if (d == 1)
            {
                cout << "YES" << endl;
            }
            else if (a[i] % d == 0)
            {
                cout << "YES" << endl;
            }
            else if (a[i] >= d * 10)
            {
                cout << "YES" << endl;
            }
            else
            {
                while (a[i] > d)
                {
                    if (check(a[i], d))
                    {
                        // cout << "YES" << endl;
                        ans = true;
                        break;
                    }
                    a[i] -= d;
                }
                if (ans)
                    cout << "YES" << endl;
                else
                    cout << "NO" << endl;
            }
            // ans = check(a[i],d);
            // if(ans) cout << "YES" << endl;
            // else cout << "NO" << endl;
        }
    }
}

signed main()
{
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    fastio;
    solve();
    return 0;
}