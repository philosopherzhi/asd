﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, d;
        cin >> n >> d;
        int a[n];
        for (int i = 0; i < n; i++)
            cin >> a[i];
        for (int i = 0; i < n; i++)
        {
            if (a[i] >= d * 10 || a[i] >= 89)
            {
                cout << "YES\n";
                continue;
            }
            int f = 0;
            while (a[i] >= d)
            {
                int p = a[i] % 10;
                int aa = a[i] / 10;
                if (p == d || aa == d)
                {
                    f = 1;
                    break;
                }
                else
                {
                    a[i] -= d;
                }
            }
            if (f)
                cout << "YES\n";
            else
                cout << "NO\n";
        }
    }
}
