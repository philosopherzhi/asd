﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long int
#define Mod 1000000007
// int arr[];

bool check(int n, int d)
{
    string s = to_string(n);
    for (auto c : s)
    {
        if (c - 48 == d)
            return true;
    }
    return false;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    ll t;
    cin >> t;
    while (t--)
    {
        int q, d;
        cin >> q >> d;

        int x;
        while (q--)
        {
            cin >> x;

            if (x > 10 * d + d)
            {
                cout << "YES\n";
                continue;
            }

            bool f = 0;
            while (x >= d)
            {
                if (check(x, d))
                {
                    f = 1;
                    break;
                }
                x -= d;
            }

            cout << (f ? "YES" : "NO") << '\n';
        }
    }
    return 0;
}
