﻿#include <bits/stdc++.h>
#define ll long long

int main()
{
    using namespace std;
    int t;
    cin >> t;
    while (t--)
    {
        ll n, k;
        cin >> n >> k;
        ll ok = k;
        ll okk = k;
        ll ar[n + 2];
        for (ll i = 0; i < n; i++)
            cin >> ar[i];

        for (ll i = 0; i < n; i++)
        {
            if (ar[i] % ok == 0)
                cout << "Yes\n";
            else
            {
                ll x = ar[i];
                int flag = 0;
                while (x > 0)
                {
                    ll ck = x;
                    while (ck > 0)
                    {
                        if (ck % 10 == okk)
                        {
                            flag = 1;
                            break;
                        }
                        ck /= 10;
                    }
                    if (flag == 1)
                        break;
                    x -= k;
                    ck = x;
                }
                if (flag == 1)
                    cout << "Yes\n";
                else
                    cout << "No\n";
            }
        }
    }
}
