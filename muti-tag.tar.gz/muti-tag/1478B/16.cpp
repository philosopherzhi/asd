﻿#include <bits/stdc++.h>
#define sz size()
#define vec vector
#define pb push_back
#define ll long long
#define FAST                                                                                       \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0);                                                                                    \
    cout.tie(0);
#define F first
#define S second
#define pll pair<ll, ll>
#define ppl pair<pll, ll>
#define mp make_pair
#define minheap priority_queue<int, vector<int>, greater<int> >
const int mod = 1000000007;
using namespace std;
void cal()
{
    ll n, d;
    cin >> n >> d;
    vec<ll> v(n);
    for (int i = 0; i < n; i++)
        cin >> v[i];
    for (int i = 0; i < n; i++)
    {
        ll flag = 0;
        if (v[i] >= d * 10)
            flag = 1;
        else
        {
            while (v[i] >= d)
            {

                if (v[i] % d == 0)
                {
                    flag = 1;
                    break;
                }
                v[i] = v[i] - 10;
            }
        }
        if (flag)
            cout << "YES\n";
        else
            cout << "NO\n";
    }
}
int main()
{
    FAST;
    ll t;
    cin >> t;
    while (t--)
    {
        cal();
    }
}
