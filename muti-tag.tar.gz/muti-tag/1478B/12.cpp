﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ull unsigned long long
#define ld long double
#define pb push_back
#define PB pop_back
#define mp make_pair
#define ii pair<int, int>
#define vii vector<ii>
#define vi vector<int>
#define F first
#define S second
#define max3(a, b, c) max(a, max(b, c))
#define min3(a, b, c) min(a, min(b, c))
#define fastio ios_base::sync_with_stdio(false), cin.tie(NULL), cout.tie(NULL);
void pe()
{
    cout << endl;
}
template <class T1>
void pe(T1 e)
{
    cout << e << endl;
}
template <class T1, class T2>
void pe(T1 e1, T2 e2)
{
    cout << e1 << " " << e2 << endl;
}
template <class T1, class T2, class T3>
void pe(T1 e1, T2 e2, T3 e3)
{
    cout << e1 << " " << e2 << " " << e3 << endl;
}
template <class T1, class T2, class T3, class T4>
void pe(T1 e1, T2 e2, T3 e3, T4 e4)
{
    cout << e1 << " " << e2 << " " << e3 << " " << e4 << endl;
}
template <class T1, class T2, class T3, class T4, class T5>
void pe(T1 e1, T2 e2, T3 e3, T4 e4, T5 e5)
{
    cout << e1 << " " << e2 << " " << e3 << " " << e4 << " " << e5 << endl;
}
template <class T1>
void ps(T1 e)
{
    cout << e << " ";
}
template <class T1, class T2>
void ps(T1 e1, T2 e2)
{
    cout << e1 << " " << e2 << " ";
}
template <class T1, class T2, class T3>
void ps(T1 e1, T2 e2, T3 e3)
{
    cout << e1 << " " << e2 << " " << e3 << " ";
}
template <class T1, class T2, class T3, class T4>
void ps(T1 e1, T2 e2, T3 e3, T4 e4)
{
    cout << e1 << " " << e2 << " " << e3 << " " << e4 << " ";
}
template <class T1, class T2, class T3, class T4, class T5>
void ps(T1 e1, T2 e2, T3 e3, T4 e4, T5 e5)
{
    cout << e1 << " " << e2 << " " << e3 << " " << e4 << " " << e5 << " ";
}
const ll N = 1e9 + 1;
// const long double ep = 1e-6;
const ll mod = 1e9 + 7;
ll modular(ll x)
{
    return ((x % mod) + mod) % mod;
}
ll add(ll a, ll b)
{
    return (modular(a) + modular(b)) % mod;
}
ll mul(ll a, ll b)
{
    return (modular(a) * modular(b)) % mod;
}
/*int dx[] = {-1, 0, 1, -1, 1, -1, 0, 1};
int dy[] = {1, 1, 1, 0, 0, -1, -1, -1}; */
//	for (int i = 0; i < n; i++)
int n, d;
bool check(int num, unordered_map<int, bool>& M)
{
    if (M.find(num) != M.end())
        return M[num];
    int t = num;
    while (t)
    {
        int last = t % 10;
        if (last == d)
        {
            M[num] = true;
            return true;
        }
        t /= 10;
    }
    M[num] = false;
    return false;
}
void solve()
{
    unordered_map<int, bool> M;
    cin >> n >> d;
    int a[n];
    for (int i = 0; i < n; i++)
        cin >> a[i];
    for (int i = 0; i < n; i++)
    {
        int t = a[i];
        bool flag = false;
        while (t >= d)
        {
            if (check(t, M))
            {
                pe("YES");
                flag = true;
                break;
            }
            t -= d;
        }
        if (flag)
            continue;
        if (t < d)
        {
            pe("NO");
            flag = true;
        }
        if (flag)
            continue;
    }
}
int main()
{
    fastio int tests = 1;
    cin >> tests;
    while (tests--)
        solve();
}