﻿#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);
    int tc, q, d;
    cin >> tc;
    while (tc--)
    {
        cin >> q >> d;
        for (int i = 0; i < q; i++)
        {
            int x;
            cin >> x;
            bool flag = 0;
            if (x >= d * 10)
            {
                cout << "YES\n";
                continue;
            }
            while (x >= d)
            {
                if (x % d == 0)
                {
                    flag = 1;
                    break;
                }
                x -= 10;
            }
            cout << (flag ? "YES" : "NO") << "\n";
        }
    }
    return 0;
}
