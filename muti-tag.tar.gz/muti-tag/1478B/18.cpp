﻿#include <iostream>
#include <vector>
using namespace std;
int fun(vector<int>& coins, int amount)
{
    vector<vector<int> > dp(coins.size(), vector<int>(amount + 1, 1e9));
    for (int i = 0; i < coins.size(); i++)
        dp[i][0] = 0;
    for (int i = 0; i < coins.size(); i++)
    {
        for (int j = 1; j <= amount; j++)
        {
            if (i == 0)
                dp[i][j] = j % coins[i] ? 1e9 : j / coins[i];
            else
                dp[i][j] = j < coins[i] ? dp[i - 1][j] : min(dp[i - 1][j], 1 + dp[i][j - coins[i]]);
        }
    }
    return dp[dp.size() - 1][dp[0].size() - 1] == 1e9 ? -1 : dp[dp.size() - 1][dp[0].size() - 1];
}
int main()
{
    int t, n, i, d, x;
    cin >> t;
    while (t--)
    {
        cin >> n >> d;
        while (n--)
        {
            cin >> x;
            if (x >= d * 10)
                cout << "YES\n";
            else
            {
                if (x < d)
                    cout << "NO\n";
                else
                {
                    vector<int> V;
                    int p = d;
                    while (p <= x)
                    {
                        V.push_back(p);
                        p += 10;
                    }
                    p = fun(V, x);
                    p == -1 ? cout << "NO\n" : cout << "YES\n";
                }
            }
        }
    }
}