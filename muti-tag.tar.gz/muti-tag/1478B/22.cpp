﻿#include <bits/stdc++.h>
using namespace std;

map<int, int> mp;
int check(int n, int d)
{
    int x;
    while (n > 0)
    {
        x = n % 10;
        if (x == d)
            return 1;
        n /= 10;
    }
    return 0;
}

int recursive(int n, int d, int x)
{
    if (x > n)
        return 0;
    if (check(n - x, d) || (n - x) % d == 0)
        return 1;
    int sum = 0;
    for (int i = 0; i < 10 && !sum; i++)
        if (++mp[x * 10 + i] == 1)
            sum += recursive(n, d, x * 10 + i);
    if (sum)
        return 1;
    int y = pow(10, floor(log10(x)) + 1);
    if (y > n)
        return 0;
    for (int i = 1; i < 10; i++)
        if (++mp[y * i + x] == 1)
            sum += recursive(n, d, y * i + x);
    if (sum)
        return 1;
    return 0;
}


int main()
{
#ifndef ONLINE_JUDGE
    freopen("input1.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    int t;
    cin >> t;
    while (t--)
    {
        int n, d;
        cin >> n >> d;
        int a[n];
        for (int i = 0; i < n; i++)
            cin >> a[i];
        for (auto x : a)
        {
            mp.clear();
            int y = x, t, flag = 0;
            while (y > 0)
            {
                t = y % 10;
                if (t == d)
                {
                    cout << "YES\n";
                    flag = 1;
                    break;
                }
                y /= 10;
            }
            if (flag)
                continue;
            mp[d]++;
            (recursive(x, d, d)) ? cout << "YES\n" : cout << "NO\n";
        }
    }
    return 0;
}