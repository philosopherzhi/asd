﻿#include <bits/stdc++.h>

using namespace std;

int main()

{

    int t, n, a, b, c, i, j, d;

    cin >> t;

    while (t--)
    {

        cin >> n >> d;

        while (n--)
        {
            cin >> a;
            c = 0;

            if (a >= d * 10)
                c = 1;

            if (c == 0)
            {
                while (a >= d)
                {

                    if (a % d == 0)
                    {
                        c = 1;
                        break;
                    }
                    a -= 10;
                }
            }

            if (c)
                cout << "YES\n";

            else
                cout << "NO\n";
        }
    }
}
