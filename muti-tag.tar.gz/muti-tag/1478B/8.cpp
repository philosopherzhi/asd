﻿//
// Created by sharm on 01-04-2021.
//

#include <iostream>
#include <string>

using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int a, b;
        cin >> a >> b;
        long int arr[a];
        for (int i = 0; i < a; i++)
        {
            cin >> arr[i];
        }
        //        vector<long int> nos;
        //        long int count = b;
        //        long int max_element_in_array = *max_element(arr, arr + a);
        //        cout << max_element_in_array << endl;
        //        while (count <= max_element_in_array) {
        //            nos.push_back(count);
        //            count += 10;
        //        }
        //        for ( auto i : nos){
        //            cout << i<< endl;
        //        }
        string s1 = to_string(b);
        char c = s1[0];
        for (int i = 0; i < a; i++)
        {

            int flag = 0;
            long int z = arr[i];
            while (z > 0)
            {
                string s = to_string(z);
                if (s.find(c) < s.length())
                {
                    cout << "YES" << endl;
                    flag = 1;
                    break;
                }
                z -= b;
            }
            if (flag == 0)
            {
                cout << "NO" << endl;
            }
        }
    }
}
//
// 2
// 3 7
// 24 25 27
// 10 7
// 51 52 53 54 55 56 57 58 59 60