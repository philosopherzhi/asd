﻿#include <bits/stdc++.h>
using namespace std;


#define F first
#define S second
#define pb push_back
#define gap ' '
#define fastIO                                                                                     \
    {                                                                                              \
        ios_base::sync_with_stdio(false);                                                          \
        cin.tie(NULL);                                                                             \
    }
#define Inf 1e18
#define all(v) v.begin(), v.end()
#define For(i, a, b) for (ll i = a; i < b; ++i)
#define Rof(i, a, b) for (ll i = a; i >= b; --i)
#define endl "\n"
#define yes cout << "YES\n"
#define no cout << "NO\n"


typedef long long ll;
typedef vector<ll> vl;
typedef pair<ll, ll> pll;
typedef map<ll, ll> mll;
typedef multimap<ll, ll> mmll;


ll ok(string a)
{
    string s = a;
    stack<char> st;
    ll n = s.size();
    For(i, 0, n)
    {
        if (st.empty())
        {
            st.push(s[i]);
        }
        else
        {
            if (s[i] == ')' and st.top() == '(')
                st.pop();
            else
                st.push(s[i]);
        }
    }

    return st.size() == 0;
}


void solve()
{
    ll t;
    t = 1;
    cin >> t;
t:
    while (t--)
    {
        ll n, d;
        cin >> n >> d;
        while (n--)
        {
            ll a;
            cin >> a;
            ll ok = 0;
            if (a >= 10 * d)
                ok = 1;
            else
            {
                while (a >= d)
                {
                    a -= d;
                    if (a % 10 == 0)
                    {
                        ok = 1;
                        break;
                    }
                }
            }

            if (ok)
                yes;
            else
                no;
        }
    }
}


int main()
{
    fastIO solve();


    return 0;
}
