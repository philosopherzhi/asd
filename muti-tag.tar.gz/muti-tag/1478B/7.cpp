﻿#include <bits/stdc++.h>
using namespace std;
#define int long long
bool isSpecial(int p, int d)
{
    while (p > 0)
    {
        if (p % 10 == d)
            return 1;
        p = p / 10;
    }
    return 0;
}
void solve()
{
    int n, d, x, y, p, q;
    cin >> n >> d;
    for (int i = 0; i < n; i++)
    {
        cin >> p;
        if (isSpecial(p, d) or p % d == 0 or p > 11 * d)
            cout << "YES\n";
        else
        {
            int x = 0;
            for (int j = 2; j < 10; j++)
            {
                if (p % 10 == (j * d) % 10 && j * d <= p)
                {
                    x = 1;
                    cout << "YES\n";
                    break;
                }
            }
            if (x == 0)
                cout << "NO\n";
        }
    }
}
int32_t main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    int t;
    cin >> t;
    while (t--)
    {
        solve();
    }
}