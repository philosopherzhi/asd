﻿// Created by ...
#include <bits/stdc++.h>


#define db1(x) cout << #x << "=" << x << '\n'
#define db2(x, y) cout << #x << "=" << x << "," << #y << "=" << y << '\n'
#define db3(x, y, z)                                                                               \
    cout << #x << "=" << x << "," << #y << "=" << y << "," << #z << "=" << z << '\n'
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repA(i, a, n) for (int i = a; i <= (n); ++i)
#define repD(i, a, n) for (int i = a; i >= (n); --i)

using namespace std;
using ll = long long;

bool solve(string expr)
{
    stack<char> s;
    char x;

    // Traversing the Expression
    for (int i = 0; i < expr.length(); i++)
    {
        if (expr[i] == '(' || expr[i] == '[' || expr[i] == '{')
        {
            // Push the element in the stack
            s.push(expr[i]);
            continue;
        }

        // IF current current character is not opening
        // bracket, then it must be closing. So stack
        // cannot be empty at this point.
        if (s.empty())
            return false;

        switch (expr[i])
        {
            case ')':

                // Store the top element in a
                x = s.top();
                s.pop();
                if (x == '{' || x == '[')
                    return false;
                break;

            case '}':

                // Store the top element in b
                x = s.top();
                s.pop();
                if (x == '(' || x == '[')
                    return false;
                break;

            case ']':

                // Store the top element in c
                x = s.top();
                s.pop();
                if (x == '(' || x == '{')
                    return false;
                break;
        }
    }

    // Check Empty Stack
    return (s.empty());
}
bool prime(int n)
{
    // Corner case
    if (n <= 1)
        return false;

    // Check from 2 to n-1
    for (int i = 2; i < n; i++)
        if (n % i == 0)
            return false;

    return true;
}

bool check(ll n, ll m)
{
    while (n != 0)
    {
        ll one = n % 10;
        if (one == m)
            return true;
        else
        {
            n = n / 10;
        }
    }
    return false;
}
int main()
{
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output1.txt", "w", stdout);
#endif
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int t;
    cin >> t;
    // cout << t << endl;
    while (t--)
    {
        ll n, m;
        cin >> n >> m;
        ll i, j;
        ll a[n], b[n];
        map<ll, ll> mp;
        ll ans = 0;
        for (i = 0; i < n; i++)
        {
            cin >> a[i];
            // ans = max(ans, ++mp[a[i]]);
            // mp[a[i]].push_back(i);
        }
        for (i = 0; i < n; i++)
        {
            while (a[i] > 0)
            {
                if (check(a[i], m))
                {
                    cout << "YES" << endl;
                    break;
                }
                else
                {
                    a[i] -= m;
                }
            }
            if (a[i] <= 0)
            {
                cout << "NO" << endl;
            }
        }
        // cout << ans << endl;
    }
    return 0;
}
