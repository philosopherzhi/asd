﻿#include <iostream>
#include <bits/stdc++.h>
#include <math.h>
#define pii pair<int, int>
#define pll pair<long long, long long>
#define pq priority_queue
#define vi vector<int>
#define vl vector<long long>
#define vc vector<char>
#define mii map<int, int>
#define pb push_back
#define PI 3.14159265358979323846
typedef long long ll;
using namespace std;

bool contains(ll a, ll d)
{
    while (a != 0)
    {
        ll dig = a % 10;
        if (dig == d)
            return true;
        a /= 10;
    }
    return false;
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int t;
    cin >> t;
    while (t--)
    {
        ll q, d;
        cin >> q >> d;
        ll arr[q];
        for (int i = 0; i < q; i++)
            cin >> arr[i];
        for (int i = 0; i < q; i++)
        {
            bool good = false;
            while (arr[i] >= d)
            {
                if (contains(arr[i], d))
                {
                    good = true;
                    break;
                }
                arr[i] -= d;
            }
            if (good)
                cout << "YES"
                     << "\n";
            else
                cout << "NO"
                     << "\n";
        }
    }

    return 0;
}
