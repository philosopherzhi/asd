﻿#include <bits/stdc++.h>
using namespace std;

#define int long long
#define double long double

const double PI = 3.14159265358979323846;
const int INF = 9223372036854775807 / 2;
const int mod = 1e9 + 7;

int fastPow(int b, int e)
{
    int r = 1;
    while (e)
    {
        if (e % 2 == 1)
        {
            r *= b;
            r %= mod;
        }
        b *= b;
        b %= mod;
        e /= 2;
    }
    return r;
}
int pgcd(int a, int b)
{
    if (a % b == 0)
        return b;
    else
        return pgcd(b, a % b);
}
int sign(int a)
{
    if (a < 0)
    {
        return -1;
    }
    if (a == 0)
    {
        return 0;
    }
    return 1;
}
bool isPrime(int a)
{
    if (a <= 1)
    {
        return false;
    }
    int f = a;
    for (int i = 2; i * i <= f; i++)
    {
        if (a % i == 0)
        {
            return false;
        }
    }
    return true;
}
int toInt(string s)
{
    int tot = 0;
    for (int i = s.size() - 1; i >= 0; i--)
    {
        tot += ((s[i] - '0') % mod) * fastPow(10, i);
        tot %= mod;
    }
    return tot;
}
string toString(int a)
{
    string s = "";
    while (a)
    {
        s = (char)('0' + a % 10) + s;
        a /= 10;
    }
    return s;
}

signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);

    int n, m;
    cin >> n >> m;

    vector<int> w(n + 1);

    for (int i = 1; i <= n; i++)
    {
        cin >> w[i];
    }

    vector<int> degree(n + 1);
    vector<int> visited(n + 1);

    vector<vector<pair<int, int> > > Graph(n + 1);

    for (int i = 0; i < m; i++)
    {
        int a, b;
        cin >> a >> b;

        Graph[a].push_back({ b, i });
        Graph[b].push_back({ a, i });

        degree[a]++;
        degree[b]++;
    }

    queue<int> q;

    for (int i = 1; i <= n; i++)
    {
        if (degree[i] <= w[i])
        {
            q.push(i);
        }
    }

    vector<int> ans;

    while (!q.empty())
    {

        int node = q.front();
        q.pop();

        if (visited[node])
            continue;

        visited[node] = true;

        // cout << "HERE " << node << endl;

        for (pair<int, int> a : Graph[node])
        {
            if (visited[a.first])
                continue;

            degree[a.first]--;
            ans.push_back(a.second);

            if (degree[a.first] <= w[a.first])
            {
                q.push(a.first);
            }
        }
    }

    if ((int)ans.size() == m)
    {
        reverse(ans.begin(), ans.end());
        cout << "ALIVE" << endl;

        for (int a : ans)
        {
            cout << a + 1 << ' ';
        }
        cout << '\n';
    }
    else
    {
        cout << "DEAD" << endl;
    }
}
