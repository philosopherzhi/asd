﻿#include <bits/stdc++.h>
#define fast                                                                                       \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0);                                                                                    \
    cout.tie(0)
#define pi pair<int, int>
using namespace std;

queue<int> q;
stack<int> answer;
const int N = 2e5 + 5;
map<int, vector<int>> love;
int plates, friends, w[N], x[N], y[N], s[N], done[N], in_queue[N];

int main()
{
    fast;
    cin >> plates >> friends;

    for (int i = 1; i <= plates; i++)
        cin >> w[i];

    for (int i = 1; i <= friends; i++)
    {
        cin >> x[i] >> y[i];
        s[x[i]]++;
        s[y[i]]++;
        love[x[i]].push_back(i);
        love[y[i]].push_back(i);
    }

    for (int i = 1; i <= plates; i++)
        if (s[i] <= w[i] && s[i] != 0)
            q.push(i), in_queue[i] = 1;

    while (!q.empty())
    {
        int food = q.front();
        q.pop();
        if (s[food] == 0)
            continue;
        for (auto people : love[food])
        {
            if (!done[people])
            {
                answer.push(people);
                done[people] = 1;
                if (x[people] == food)
                    swap(x[people], y[people]);
                s[x[people]]--;
                if (in_queue[x[people]])
                    continue;
                if (s[x[people]] <= w[x[people]] && s[x[people]] != 0)
                    q.push(x[people]), in_queue[x[people]] = 1;
            }
        }
    }
    if (answer.size() != friends)
        cout << "DEAD\n";
    else
    {
        cout << "ALIVE\n";
        while (!answer.empty())
        {
            cout << answer.top() << " ";
            answer.pop();
        }
    }
}
