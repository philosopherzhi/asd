﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ull unsigned long long
#define pii pair<int, int>
#define mii map<int, int>
#define pb push_back
#define mk make_pair
const int inf = 0x3f3f3f3f;
const ll mod = 1000000007;
const ll linf = 0x3f3f3f3f3f3f3f3f;
#define deb(k) cerr << #k << ": " << k << "\n";
#define fastcin cin.tie(0)->sync_with_stdio(0);
#define st first
#define nd second
#define MAXN 1000100
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

vector<int> ans;
int w[100100];
vector<pii> g[100100];
int cnt[100100];
bool vis[200100];
bool plate[100100];

void solve()
{
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
        cin >> w[i];
    for (int i = 1; i <= m; i++)
    {
        int a, b;
        cin >> a >> b;
        g[a].pb({ b, i });
        g[b].pb({ a, i });
        cnt[a]++;
        cnt[b]++;
    }
    queue<int> q;
    for (int i = 1; i <= n; i++)
    {
        if (cnt[i] <= w[i])
        {
            q.push(i);
            plate[i] = 1;
        }
    }
    while (!q.empty())
    {
        int x = q.front();
        q.pop();
        for (auto v : g[x])
        {
            if (vis[v.second])
                continue;
            vis[v.second] = 1;
            ans.pb(v.second);
            cnt[v.first]--;
            if (cnt[v.first] <= w[v.first] && !plate[v.first])
            {
                plate[v.first] = 1;
                q.push(v.first);
            }
        }
    }
    if ((int)ans.size() != m)
        cout << "DEAD\n";
    else
    {
        cout << "ALIVE\n";
        reverse(ans.begin(), ans.end());
        for (auto p : ans)
            cout << p << " ";
        cout << "\n";
    }
}

int main()
{
    fastcin;
    solve();
    return 0;
}
