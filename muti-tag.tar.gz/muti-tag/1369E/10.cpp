﻿#include <bits/stdc++.h>
#define fi first
#define se second
#define mp make_pair
using namespace std;
const int N = 1e5 + 5;
const int M = 2e5 + 5;

vector<pair<int, int>> adj[N];

pair<int, int> p[M];

int a[N];
int cnt[N];
int n, m;

bool vis[M];

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    // freopen("file.inp","r",stdin);
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
        cin >> a[i];

    for (int i = 1; i <= m; i++)
    {
        int u, v;
        cin >> u >> v;
        adj[u].push_back(mp(v, i));
        adj[v].push_back(mp(u, i));
        cnt[u]++;
        cnt[v]++;
    }

    vector<int> ans;
    queue<int> q;

    for (int i = 1; i <= n; i++)
        if (cnt[i] <= a[i])
        {
            q.push(i);
        }

    while (q.size())
    {
        int u = q.front();
        q.pop();

        for (pair<int, int> to : adj[u])
        {
            int v = to.fi;
            int id = to.se;
            if (vis[id])
                continue;

            cnt[v]--;
            ans.push_back(id);
            vis[id] = true;
            if (cnt[v] <= a[v])
                q.push(v);
        }
    }
    reverse(ans.begin(), ans.end());
    if (ans.size() == m)
    {
        cout << "ALIVE\n";
        for (int x : ans)
            cout << x << " ";
    }
    else
        cout << "DEAD";

    return 0;
}
