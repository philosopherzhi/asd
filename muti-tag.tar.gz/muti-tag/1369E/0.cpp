﻿#include <bits/stdc++.h>

#define ll long long
#define fr first
#define sc second
#define pii pair<int, int>
#define all(v) v.begin(), v.end()

using namespace std;
const int MN = 2e5 + 7;

int x[MN], y[MN], s[MN], w[MN], mark[MN], colmark[MN];

vector<int> v[MN], a;
vector<pii> f;

priority_queue<pii, vector<pii>, greater<pii>> pq;

signed main()
{
    ios::sync_with_stdio(false);
    cin.tie();
    cout.tie();
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
        cin >> w[i];
    for (int i = 0; i < m; i++)
    {
        cin >> x[i] >> y[i];
        s[x[i]]++;
        s[y[i]]++;
        v[x[i]].push_back(i);
        v[y[i]].push_back(i);
    }
    for (int i = 1; i <= n; i++)
    {
        if (s[i])
            pq.push({ max(0, s[i] - w[i]), i });
        else
            colmark[i] = 1;
    }

    while (pq.size())
    {
        auto q = pq.top();
        pq.pop();
        if (q.fr != max(0, s[q.sc] - w[q.sc]))
            continue;
        if (q.fr > 0)
        {
            cout << "DEAD\n";
            exit(0);
        }
        int id = q.sc;
        vector<int> wt;
        for (auto u : v[id])
        {
            if (mark[u])
                continue;
            a.push_back(u);
            if (x[u] == id)
                swap(x[u], y[u]);
            if (!colmark[x[u]])
                wt.push_back(x[u]);
            mark[u] = 1;
        }
        sort(all(wt));
        for (int i = 0; i < wt.size(); i++)
        {
            s[wt[i]]--;
            if (i == wt.size() - 1 || wt[i + 1] != wt[i])
            {
                if (s[wt[i]])
                {
                    if (max(0, s[wt[i]] - w[wt[i]]) == 0)
                        colmark[wt[i]] = 1;
                    pq.push({ max(0, s[wt[i]] - w[wt[i]]), wt[i] });
                }
            }
        }
    }
    cout << "ALIVE\n";
    for (int i = 0; i < a.size() / 2; i++)
        swap(a[i], a[a.size() - i - 1]);
    for (auto u : a)
    {
        cout << u + 1 << ' ';
    }
    cout << '\n';
}