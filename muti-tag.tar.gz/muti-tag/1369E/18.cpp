﻿/*=====================

 # Author: Moon_Sun
 # Blog : chaos1018.rinue.top
 # Mail : chaoyangranran@outlook.com

======================*/
#include <bits/stdc++.h>
using namespace std;
template <typename T>
inline void read(T& a)
{
    T w = 1;
    a = 0;
    char ch = getchar();
    for (; ch < '0' || ch > '9'; ch = getchar())
        if (ch == '-')
            w = -1;
    for (; ch >= '0' && ch <= '9'; ch = getchar())
        a = (a * 10) + (ch - '0');
    a *= w;
}
template <typename T>
inline void ckmax(T& a, T b)
{
    a = a > b ? a : b;
}
template <typename T>
inline void ckmin(T& a, T b)
{
    a = a < b ? a : b;
}
const int MAX = 2e5 + 10;
int w[MAX];
struct node
{
    int x, y;
} s[MAX];
struct edge
{
    int to, nex;
} e[MAX << 1];
int head[MAX], cnt;
inline void add(int u, int v)
{
    e[++cnt].to = v;
    e[cnt].nex = head[u];
    head[u] = cnt;
}
int get(int xx, int xxx)
{
    return s[xx].x == xxx ? s[xx].y : s[xx].x;
}
queue<int> q;
int vis[MAX], Ans[MAX], Vis[MAX];
int main()
{
    int n, m;
    read(n);
    read(m);
    for (int i = 1; i <= n; ++i)
        read(w[i]);
    for (int i = 1; i <= m; ++i)
    {
        read(s[i].x);
        read(s[i].y);
        add(s[i].x, i + n);
        add(s[i].y, i + n);
        w[s[i].x]--;
        w[s[i].y]--;
    }
    for (int i = 1; i <= n; ++i)
        if (w[i] >= 0)
        {
            q.push(i);
            vis[i] = 1;
        }
    int num = 0;
    while (!q.empty())
    {
        int u = q.front();
        q.pop();
        for (int i = head[u]; i; i = e[i].nex)
        {
            int v = e[i].to;
            v -= n;
            if (Vis[v])
                continue;
            Vis[v] = 1;
            int xxx = get(v, u);
            Ans[++num] = v;
            w[xxx]++;
            if (w[xxx] >= 0 && !vis[xxx])
            {
                q.push(xxx);
                vis[xxx] = 1;
            }
        }
    }
    if (num == m)
    {
        puts("ALIVE");
        for (int i = m; i >= 1; --i)
            cout << Ans[i] << " ";
    }
    else
        puts("DEAD");
}
