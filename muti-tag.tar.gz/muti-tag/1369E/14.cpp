﻿#include <cmath>
#include <queue>
#include <cstdio>
#include <vector>
#include <string>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N = 200005;
const int mod = 1e9 + 7;


int t, n, m, ans, len;
int a[N], b[N], c[N], f[N], x[N], y[N], res[N];

vector<int> g[N];
queue<int> q;

void topo()
{
    for (int i = 1; i <= n; ++i)
        if (a[i] >= b[i])
            f[i] = 1, q.push(i);
    int cnt = 0;
    while (!q.empty())
    {
        int tmp = q.front();
        q.pop();
        ++cnt;
        for (int i = 0; i < g[tmp].size(); ++i)
        {
            int u = g[tmp][i];
            if (!c[u])
                c[u] = 1, res[++len] = u;
            --b[x[u]], --b[y[u]];
            if (a[x[u]] >= b[x[u]] && !f[x[u]])
                f[x[u]] = 1, q.push(x[u]);
            if (a[y[u]] >= b[y[u]] && !f[y[u]])
                f[y[u]] = 1, q.push(y[u]);
        }
    }
    if (cnt == n)
    {
        puts("ALIVE");
        for (int i = m; i >= 1; --i)
            cout << res[i] << " ";
    }
    else
        puts("DEAD");
}

void solve()
{
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    for (int i = 1; i <= m; ++i)
    {
        cin >> x[i] >> y[i];
        ++b[x[i]], ++b[y[i]];
        g[x[i]].push_back(i);
        g[y[i]].push_back(i);
    }
    topo();
}

int main()
{
    //    ios::sync_with_stdio(false);
    //    cin.tie(0);
    solve();
    return 0;
}
