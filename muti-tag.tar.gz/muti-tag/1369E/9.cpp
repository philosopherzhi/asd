﻿#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <queue>
#include <map>

using namespace std;

const int MAXN = 2e5 + 5;

int N, M, w[MAXN], sz[MAXN];
bool used[MAXN], pushed[MAXN];
map<int, vector<int> > like;
pair<int, int> likes[MAXN];

int main()
{

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin >> N >> M;
    for (int i = 0; i < N; i++)
    {
        cin >> w[i];
    }
    for (int i = 0; i < M; i++)
    {
        int a, b;
        cin >> a >> b;
        a--;
        b--;
        likes[i] = make_pair(a, b);
        like[a].push_back(i);
        like[b].push_back(i);
        sz[a]++;
        sz[b]++;
    }
    vector<int> nxt;
    for (auto it : like)
    {
        if (sz[it.first] <= w[it.first])
        {
            nxt.push_back(it.first);
            pushed[it.first] = true;
        }
    }
    vector<int> seq;
    while (nxt.size() != 0)
    {
        int key = nxt.back();
        nxt.pop_back();
        for (int x : like[key])
        {
            if (!used[x])
            {
                used[x] = true;
                seq.push_back(x);
                sz[likes[x].first]--;
                sz[likes[x].second]--;
                if (!pushed[likes[x].first] && sz[likes[x].first] <= w[likes[x].first])
                {
                    nxt.push_back(likes[x].first);
                    pushed[likes[x].first] = true;
                }
                if (!pushed[likes[x].second] && sz[likes[x].second] <= w[likes[x].second])
                {
                    nxt.push_back(likes[x].second);
                    pushed[likes[x].second] = true;
                }
            }
        }
    }
    if (seq.size() == M)
    {
        cout << "ALIVE\n";
        for (int i = M - 1; i >= 0; i--)
        {
            cout << seq[i] + 1 << " ";
        }
    }
    else
    {
        cout << "DEAD\n";
    }
}