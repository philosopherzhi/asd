﻿#include <bits/stdc++.h>
using namespace std;
const int maxn = 2e5 + 10;
int w[maxn], s[maxn];
bool flag[maxn];
struct node
{
    int a, b;
} q[maxn];
vector<int> v[maxn];
vector<int> ans;
queue<int> Q;
void dfs(int pos)
{
    for (int id : v[pos])
    {
        if (flag[id])
            continue;
        flag[id] = 1;
        ans.push_back(id);
        if (q[id].a == pos)
        {
            s[q[id].b]++;
            if (s[q[id].b] == 0)
                Q.push(q[id].b);
        }
        else
        {
            s[q[id].a]++;
            if (s[q[id].a] == 0)
                Q.push(q[id].a);
        }
    }
}
int main()
{
    int n, m;
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= n; i++)
        scanf("%d", &w[i]), s[i] = w[i];
    for (int i = 1; i <= m; i++)
    {
        scanf("%d%d", &q[i].a, &q[i].b), s[q[i].a]--, s[q[i].b]--;
        v[q[i].a].push_back(i);
        v[q[i].b].push_back(i);
    }
    for (int i = 1; i <= n; i++)
        if (s[i] >= 0)
            Q.push(i);
    while (Q.size())
    {
        int id = Q.front();
        Q.pop();
        dfs(id);
    }
    if (ans.size() != m)
    {
        printf("DEAD\n");
        return 0;
    }
    printf("ALIVE\n");
    for (int i = m - 1; i >= 0; i--)
        printf("%d ", ans[i]);
}