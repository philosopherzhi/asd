﻿/*
Author: Ritik Patel
*/

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& LIBRARIES &&&&&&&&&&&&&&&&&&&&&&&&&&&

#include <bits/stdc++.h>
using namespace std;

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& DEFINES &&&&&&&&&&&&&&&&&&&&&&&&&&&

#define int long long int
// #define ll long long int
#define all(i) i.begin(), i.end()
#define SZ(a) (int) a.size()

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& CODE &&&&&&&&&&&&&&&&&&&&&&&&&&&

void solve()
{
    int n, m;
    cin >> n >> m;
    vector<pair<int, int>> a(m + 1), g[n + 1];
    vector<int> cnt(n + 1, 0), freq(n + 1, 0);
    for (int i = 1; i <= n; ++i)
        cin >> cnt[i];
    for (int i = 1; i <= m; ++i)
    {
        cin >> a[i].first >> a[i].second;
        freq[a[i].first]++, freq[a[i].second]++;
        g[a[i].first].emplace_back(a[i].second, i);
        g[a[i].second].emplace_back(a[i].first, i);
    }
    vector<bool> vis(n + 1, 0), rem(m + 1, 0);
    queue<int> q;
    for (int i = 1; i <= n; ++i)
        if (freq[i] <= cnt[i])
            q.push(i), vis[i] = 1;
    vector<int> ans;
    while (!q.empty())
    {
        int v = q.front();
        q.pop();
        for (const auto & [ to, pid ] : g[v])
        {
            if (!rem[pid])
            {
                rem[pid] = 1, freq[to]--;
                ans.emplace_back(pid);
                if (freq[to] <= cnt[to] and !vis[to])
                    q.push(to), vis[to] = 1;
            }
        }
    }
    if (ans.size() < m)
    {
        cout << "DEAD\n";
        return;
    }
    cout << "ALIVE\n";
    reverse(ans.begin(), ans.end());
    for (auto& x : ans)
        cout << x << " ";
    cout << '\n';
}

int32_t main()
{
    // freopen("input.txt","r",stdin);
    // freopen("output.txt","w",stdout);
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int T = 1;
    // cin >> T;
    for (int i = 1; i <= T; ++i)
    {
        // cout << "Case #" << i << ": ";
        solve();
    }
    return 0;
}

/*
Sample inp
*/