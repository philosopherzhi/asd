﻿#include <bits/stdc++.h>
#define ll long long
#define B break
#define C continue
#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define lb lower_bound
#define ub upper_bound
#define gc getchar
#define pc putchar
#define kg putchar(' ')
#define hh putchar('\n')
#define mem(a, b) memset(a, b, sizeof(a))
#define _for(i, a, b) for (int i = (a); i <= (b); i++)
#define _rep(i, a, b) for (int i = (a); i >= (b); i--)
//#define int __int128
#define int long long
using namespace std;
inline int rd()
{
    int x = 0, f = 1;
    char ch = gc();
    while (ch < '0' || ch > '9')
    {
        if (ch == '-')
            f = -1;
        ch = gc();
    }
    while (ch >= '0' && ch <= '9')
    {
        x = x * 10 + ch - '0';
        ch = gc();
    }
    return x * f;
}
char chhh[200];
inline void rt(int x)
{
    int cnt = 0, tmp = x > 0 ? x : -x;
    if (!x)
    {
        pc('0');
        return;
    }
    if (x < 0)
        pc('-');
    while (tmp > 0)
    {
        chhh[cnt++] = tmp % 10 + '0';
        tmp /= 10;
    }
    while (cnt > 0)
        pc(chhh[--cnt]);
}
int a[100010], s[100010], b[200010], ans[200010];
vector<pair<int, int>> e[100010];
queue<int> q;
signed main()
{
    // int main(){
    int n = rd(), m = rd();
    _for(i, 1, n)
    {
        a[i] = rd();
    }
    _for(i, 1, m)
    {
        int u = rd(), v = rd();
        s[u]++, s[v]++;
        e[u].pb({ v, i });
        e[v].pb({ u, i });
    }
    _for(i, 1, n)
    {
        if (s[i] <= a[i])
            q.push(i);
    }
    int cnt = 0;
    while (!q.empty())
    {
        int u = q.front();
        q.pop();
        for (auto v : e[u])
        {
            if (!b[v.se])
            {
                b[v.se] = 1;
                ans[++cnt] = v.se;
                s[v.fi]--;
                if (s[v.fi] <= a[v.fi])
                    q.push(v.fi);
            }
        }
    }
    if (cnt != m)
    {
        puts("DEAD");
        return 0;
    }
    puts("ALIVE");
    _rep(i, m, 1)
    {
        rt(ans[i]), kg;
    }
    return 0;
}
