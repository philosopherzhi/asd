﻿#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define ff first
#define ss second

const ll mod = (ll)1e9 + 7;

const ll maxs = 2e6 + 5;
ll root[maxs];


inline ll add(ll a, ll b)
{
    ll c = ((a % mod) + (b % mod)) % mod;
    return c;
}

inline ll mult(ll a, ll b)
{
    ll c = ((a % mod) * (b % mod)) % mod;
    return c;
}
class cmp
{
    bool operator()(const ll& a, const ll& b)
    {
        return a < b;
    }
};
void init()
{
    iota(root, root + maxs, 0);
}
ll find(ll u)
{
    ll f;
    if (root[u] == u)
        return u;
    else
    {
        ll f = find(root[u]);
        root[u] = f;
        return f;
    }
}
void Union(ll x, ll y)
{
    ll u = find(x);
    ll v = find(y);
    root[v] = u;
}
ll power(ll x, ll y, ll p)
{
    ll res = 1;
    x = x % p;
    while (y > 0)
    {
        if (y & 1)
            res = (res * x) % p;

        y = y >> 1;
        x = (x * x) % p;
    }
    return res;
}
void update(vector<ll>& BIT, ll ind, ll val)
{
    // ind : 1 based
    // val - arr[i] or count
    while (ind < BIT.size())
    {
        BIT[ind] += val;
        ind += (ind & (-ind));
    }
}
ll query(vector<ll>& BIT, ll ind)
{
    ll sum = 0;
    while (ind > 0)
    {
        sum += BIT[ind];
        ind -= (ind & (-ind));
    }
    return sum;
}


int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    ll t, n, i, k, y, x, j, m, w;
    cin >> n >> m;
    vector<ll> arr(n + 1);
    vector<pair<ll, ll>> str(m + 1);
    map<ll, set<ll>> g;
    map<ll, ll> cnt;
    set<ll> s;

    for (i = 1; i <= n; i++)
    {
        cin >> arr[i];
    }

    for (i = 1; i <= m; i++)
    {
        cin >> str[i].ff >> str[i].ss;
        g[str[i].ff].insert(i);
        g[str[i].ss].insert(i);
        cnt[str[i].ff]++;
        cnt[str[i].ss]++;
    }
    queue<ll> q;
    for (i = 1; i <= n; i++)
    {
        if (cnt[i] <= arr[i])
            q.push(i);
    }
    vector<ll> ans;
    while (!q.empty())
    {
        auto it = q.front();
        q.pop();
        for (auto i : g[it])
        {
            if (!s.count(i))
            {
                ans.push_back(i);
                s.insert(i);
                cnt[str[i].ff]--;
                cnt[str[i].ss]--;
                if (cnt[str[i].ff] == arr[str[i].ff])
                    q.push(str[i].ff);
                if (cnt[str[i].ss] == arr[str[i].ss])
                    q.push(str[i].ss);
            }
        }
    }

    if (ans.size() < m)
    {
        cout << "DEAD" << endl;
    }
    else
    {
        cout << "ALIVE" << endl;
        for (i = m - 1; i >= 0; i--)
        {
            cout << ans[i] << " ";
        }
    }


    return 0;
}
