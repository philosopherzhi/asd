﻿#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;

const int N = 2e5 + 25;
int w[N], x[N], y[N];
vector<int> g[N];
bool vn[N], vm[N];

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout << setprecision(32);

    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
    {
        cin >> w[i];
    }
    for (int i = 1; i <= m; i++)
    {
        cin >> x[i] >> y[i];
        g[x[i]].push_back(i);
        g[y[i]].push_back(i);
        w[x[i]]--;
        w[y[i]]--;
    }
    vector<int> ans, free;
    memset(vn, false, sizeof(vn));
    memset(vm, false, sizeof(vm));
    for (int i = 1; i <= n; i++)
    {
        if (w[i] >= 0)
            free.push_back(i);
    }
    while (!free.empty())
    {
        int u = free.back();
        free.pop_back();
        vm[u] = true;
        while (!g[u].empty())
        {
            int id = g[u].back();
            g[u].pop_back();
            if (!vn[id])
            {
                vn[id] = true;
                ans.push_back(id);
                w[x[id]]++;
                w[y[id]]++;
                if (w[x[id]] >= 0 && !vm[x[id]])
                    free.push_back(x[id]);
                if (w[y[id]] >= 0 && !vm[y[id]])
                    free.push_back(y[id]);
            }
        }
    }
    if (ans.size() != m)
    {
        cout << "DEAD" << '\n';
    }
    else
    {
        cout << "ALIVE" << '\n';
        while (!ans.empty())
        {
            cout << ans.back() << ' ';
            ans.pop_back();
        }
        cout << '\n';
    }

    return 0;
}