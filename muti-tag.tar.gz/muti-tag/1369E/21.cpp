﻿#include <bits/stdc++.h>
using namespace std;
#define N 100005
#define NN 200005
#define For(i, x, y) for (i = x; i <= (y); i++)
struct node
{
    int next, to, w;
} e[400005];
bool vis[NN];
queue<int> que;
int b[NN], head[N], w[N], deg[N], g;
int read()
{
    int A;
    bool K;
    char C;
    C = A = K = 0;
    while (C < '0' || C > '9')
        K |= C == '-', C = getchar();
    while (C > '/' && C < ':')
        A = (A << 3) + (A << 1) + (C ^ 48), C = getchar();
    return (K ? -A : A);
}
inline void add(int u, int v, int w)
{
    e[++g].w = w;
    e[g].to = v;
    e[g].next = head[u];
    head[u] = g;
}
int main()
{
    int n, m, x, y, i, u, v, cnt = 0;
    n = read(), m = read();
    For(i, 1, n) w[i] = read();
    For(i, 1, m)
    {
        x = read(), y = read();
        add(x, y, i), add(y, x, i);
        deg[x]++;
        deg[y]++;
    }
    For(i, 1, n) if (w[i] >= deg[i]) deg[i] = -1, que.push(i);
    while (!que.empty())
    {
        u = que.front();
        for (i = head[u]; i; i = e[i].next)
            if (!vis[e[i].w])
            {
                v = e[i].to;
                deg[v]--;
                vis[e[i].w] = 1;
                b[++cnt] = e[i].w;
                if (deg[v] == w[v])
                    que.push(v);
            }
        que.pop();
    }
    if (cnt < m)
        puts("DEAD"), exit(0);
    puts("ALIVE");
    For(i, 1, m) printf("%d ", b[m - i + 1]);
    return 0;
}