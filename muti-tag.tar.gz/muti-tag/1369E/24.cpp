﻿#include <bits/stdc++.h>
using namespace std;
int w[100003], cnt[100003], n, m, sum[200003];
vector<int> ans, v[100003], ok;
bool vis[200003], used[100003];
int main()
{
    cin >> n >> m;
    for (int i = 0; i < n; i++)
        scanf("%d", w + i);
    for (int i = 0; i < m; i++)
    {
        int x, y;
        scanf("%d%d", &x, &y);
        x--;
        y--;
        cnt[x]++;
        cnt[y]++;
        v[x].push_back(i);
        v[y].push_back(i);
        sum[i] = x + y;
    }
    for (int i = 0; i < n; i++)
        if (cnt[i] <= w[i])
        {
            ok.push_back(i);
            used[i] = 1;
        }
    while (ok.size())
    {
        int nw = ok.back();
        ok.pop_back();
        for (int i = 0; i < v[nw].size(); i++)
        {
            if (vis[v[nw][i]])
                continue;
            vis[v[nw][i]] = 1;
            ans.push_back(v[nw][i]);
            cnt[sum[v[nw][i]] - nw]--;
            if (!used[sum[v[nw][i]] - nw] && cnt[sum[v[nw][i]] - nw] <= w[sum[v[nw][i]] - nw])
            {
                ok.push_back(sum[v[nw][i]] - nw);
                used[sum[v[nw][i]] - nw] = 1;
            }
        }
    }
    if (ans.size() != m)
    {
        cout << "DEAD";
        return 0;
    }
    cout << "ALIVE\n";
    while (ans.size())
        cout << ans.back() + 1 << ' ', ans.pop_back();
}