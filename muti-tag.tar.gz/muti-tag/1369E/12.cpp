﻿#include <iostream>
#include <cstring>
#include <cstdio>
#include <climits>
#include <algorithm>
#include <queue>
#include <vector>
#define pii pair<int, int>
#define mp make_pair
#define pb push_back
#define fi first
#define se second
using namespace std;
inline int read()
{
    int f = 1, ans = 0;
    char c = getchar();
    while (c < '0' || c > '9')
    {
        if (c == '-')
            f = -1;
        c = getchar();
    }
    while (c >= '0' && c <= '9')
    {
        ans = ans * 10 + c - '0';
        c = getchar();
    }
    return f * ans;
}
const int MAXN = 2e5 + 11;
vector<pii> vec[MAXN];
int N, M, W[MAXN], Ans[MAXN], vis[MAXN];
queue<int> que;
int main()
{
    N = read(), M = read();
    for (int i = 1; i <= N; i++)
        W[i] = read();
    for (int i = 1; i <= M; i++)
    {
        int u = read(), v = read();
        vec[u].pb(mp(v, i)), vec[v].pb(mp(u, i));
        W[u]--, W[v]--;
    }
    for (int i = 1; i <= N; i++)
        if (W[i] >= 0)
            que.push(i);
    while (!que.empty())
    {
        int xx = que.front();
        que.pop();
        for (auto p : vec[xx])
        {
            if (vis[p.se])
                continue;
            vis[p.se] = 1;
            Ans[++Ans[0]] = p.se;
            W[p.fi]++;
            if (W[p.fi] >= 0)
                que.push(p.fi);
        }
    }
    if (Ans[0] != M)
        printf("DEAD\n");
    else
    {
        printf("ALIVE\n");
        for (int i = M; i >= 1; i--)
            printf("%d ", Ans[i]);
        printf("\n");
    }
    return 0;
}