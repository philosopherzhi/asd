﻿#include <bits/stdc++.h>
using namespace std;
const int maxn = 5e5 + 888;
int saveori[maxn];
int n, m;
vector<int> G[maxn];
vector<int> ID[maxn];
map<int, int> vis;

void solve()
{
    scanf("%d %d", &n, &m);
    for (int i = 1; i <= n; i++)
        scanf("%d", &saveori[i]);
    for (int i = 1; i <= m; i++)
    {
        int a, b;
        scanf("%d %d", &a, &b);
        ID[a].push_back(i);
        ID[b].push_back(i);
        G[a].push_back(b);
        G[b].push_back(a);
        saveori[a]--;
        saveori[b]--;
    }

    queue<int> q;
    vector<int> ans;
    for (int i = 1; i <= n; i++)
        if (saveori[i] >= 0)
        {
            q.push(i);
        }

    while (!q.empty())
    {
        int nowid = q.front();
        q.pop();
        for (int i = 0; i < G[nowid].size(); i++)
        {
            int d = G[nowid][i];
            if (!vis[ID[nowid][i]])
            {
                ans.push_back(ID[nowid][i]);
                vis[ID[nowid][i]] = 1;
            }
            saveori[d]++;
            if (saveori[d] == 0)
            {
                q.push(d);
            }
        }
    }
    if (ans.size() != m)
    {
        puts("DEAD");
        return;
    }
    puts("ALIVE");
    reverse(ans.begin(), ans.end());
    for (int aa : ans)
    {
        printf("%d ", aa);
    }
    puts("");
}

signed main()
{
    // freopen("in.txt", "r", stdin);
    solve();
}
