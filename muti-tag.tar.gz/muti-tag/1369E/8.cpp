﻿#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
#define For(i, l, r) for (int i = (int)(l); i <= (int)(r); i++)
#define Rep(i, r, l) for (int i = (int)(r); i >= (int)(l); i--)
#define pb push_back
#define mem(a) memset((a), 0, sizeof(a))
#define fi first
#define se second
inline char gc()
{
    static char buf[100000], *p1 = buf, *p2 = buf;
    return p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 100000, stdin), p1 == p2) ? EOF : *p1++;
}
#define gc getchar
inline ll read()
{
    ll x = 0;
    char ch = gc();
    bool positive = 1;
    for (; !isdigit(ch); ch = gc())
        if (ch == '-')
            positive = 0;
    for (; isdigit(ch); ch = gc())
        x = x * 10 + ch - '0';
    return positive ? x : -x;
}
inline void write(ll a)
{
    if (a < 0)
    {
        a = -a;
        putchar('-');
    }
    if (a >= 10)
        write(a / 10);
    putchar('0' + a % 10);
}
inline void writeln(ll a)
{
    write(a);
    puts("");
}
inline void wri(ll a)
{
    write(a);
    putchar(' ');
}
int n, m, w[200020], x[200020], y[200020];
int h[200020], ver[400040], nxt[400040], tot;
int num[200020];
queue<int> q;
int vis[200020];
int ren[200020];
int ans[200020], all;
void add(int x, int y)
{
    ver[++tot] = y;
    nxt[tot] = h[x];
    h[x] = tot;
}
int main()
{
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
    {
        w[i] = read();
    }
    for (int i = 1; i <= m; i++)
    {
        x[i] = read(), y[i] = read();
        num[x[i]]++;
        num[y[i]]++;
        add(x[i], i);
        add(y[i], i);
    }
    for (int i = 1; i <= n; i++)
    {
        if (num[i] <= w[i])
        {
            vis[i] = 1;
            q.push(i);
        }
    }
    while (!q.empty())
    {
        int X = q.front();
        q.pop();
        for (int i = h[X]; i != 0; i = nxt[i])
        {
            if (ren[ver[i]] == 1)
                continue;
            ren[ver[i]] = 1;
            ans[++all] = ver[i];
            num[x[ver[i]]]--;
            num[y[ver[i]]]--;
            if (vis[x[ver[i]]] == 0 && num[x[ver[i]]] <= w[x[ver[i]]])
            {
                vis[x[ver[i]]] = 1;
                q.push(x[ver[i]]);
            }
            if (vis[y[ver[i]]] == 0 && num[y[ver[i]]] <= w[y[ver[i]]])
            {
                vis[y[ver[i]]] = 1;
                q.push(y[ver[i]]);
            }
        }
    }
    if (all == m)
    {
        cout << "ALIVE" << endl;
        for (int i = all; i >= 1; i--)
        {
            wri(ans[i]);
        }
    }
    else
    {
        cout << "DEAD" << endl;
    }
    return 0;
}