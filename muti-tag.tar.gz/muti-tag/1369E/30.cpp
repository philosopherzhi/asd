﻿#include <iostream>
#include <bits/stdc++.h>
using namespace std;
vector<int> freq;
vector<int> dem;
vector<bool> out;
vector<vector<int>> sets;
vector<int> good; // good sets
vector<int> outs; // sets already done
struct person
{
    int id;
    int f;
    int s;
};
vector<person> people;
void swap(int& a, int& b)
{
    int temp;
    temp = a;
    a = b;
    b = temp;
}
int main()
{
    int n, m;
    cin >> n >> m;
    freq.resize(n + 1);
    dem.resize(n + 1);
    for (int i = 1; i <= n; i++)
    {
        cin >> freq[i];
    }
    out.resize(m);
    sets.resize(n + 1); // each set of people eat the same plate

    int x, y;
    for (int k = 0; k <= m - 1; k++)
    {
        cin >> x >> y;
        person p;
        p.id = k;
        p.f = x;
        p.s = y;
        dem[x]++;
        dem[y]++;
        people.push_back(p);
        sets[x].push_back(k);
        sets[y].push_back(k);
    }
    int num = 0;
    for (int l = 1; l <= n; l++)
    {
        if (freq[l] >= dem[l])
        {
            good.push_back(l);
        }
    }

    vector<int> ending;
    bool h = 1;
    while (true)
    {
        if (num == m)
            break;
        int l = good.size();
        if (l == 0)
        {
            h = 0;
            break;
        }
        for (auto p : sets[good[l - 1]])
        {
            if (!out[p])
            {
                num++;
                out[p] = true;
                int one = people[p].f;
                int two = people[p].s;
                if (one != good[l - 1])
                {
                    dem[one]--;
                    if (freq[one] >= dem[one])
                    {
                        good.push_back(one);
                    }
                }
                else
                {
                    dem[two]--;
                    if (freq[two] >= dem[two])
                    {
                        good.push_back(two);
                    }
                }

                ending.push_back(p);
            }
        }
        swap(good[l - 1], good[good.size() - 1]);
        good.pop_back();
    }
    if (!h)
    {
        cout << "DEAD"
             << "\n";
    }
    else
    {
        cout << "ALIVE"
             << "\n";
        for (int f = m - 1; f >= 0; f--)
        {
            cout << ending[f] + 1 << " ";
        }
        cout << "\n";
    }


    return 0;
}
