﻿#include <bits/stdc++.h>

using namespace std;

#define DEB if (0)
typedef long long LL;
typedef pair<int, int> pii;
priority_queue<pii> q;

const int N = 100010;
const int M = 200010 << 1;
int st[N], e[N], a[N];
int b[M], nex[M], uid[M];
int tot = 0;

void add(int x, int y, int z)
{
    b[++tot] = y;
    uid[tot] = z;
    e[x]++;
    nex[tot] = st[x];
    st[x] = tot;
}

int n, m;
vector<int> ans;

void ex()
{
    if ((int)ans.size() != m)
    {
        puts("DEAD");
        exit(0);
    }
    puts("ALIVE");
    for (int i = (int)ans.size() - 1; i >= 0; --i)
        printf("%d%c", ans[i], " \n"[i == 0]);
    exit(0);
}

bool vis[N];

int main()
{
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= n; ++i)
        scanf("%d", a + i);
    for (int i = 1; i <= m; ++i)
    {
        int u, v;
        scanf("%d%d", &u, &v);
        add(u, v, i);
        add(v, u, i);
    }
    for (int i = 1; i <= n; ++i)
        q.push({ a[i] - e[i], i });
    while (!q.empty())
    {
        pii top = q.top();
        q.pop();
        if (vis[top.second])
            continue;
        if (top.first < 0)
            ex();
        int x = top.second;
        DEB printf("deal node %d\n", x);
        for (int i = st[x]; i; i = nex[i])
        {
            int y = b[i];
            if (vis[y])
                continue;
            e[x]--;
            e[y]--;
            ans.push_back(uid[i]);
            DEB printf("append person %d to ans\n", uid[i]);
        }
        for (int i = st[x]; i; i = nex[i])
        {
            int y = b[i];
            if (vis[y])
                continue;
            q.push({ a[y] - e[y], y });
            DEB printf("push node %d to queue\n", y);
        }
        vis[x] = true;
    }
    ex();
    return 0;
}