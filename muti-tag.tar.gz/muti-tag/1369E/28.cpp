﻿#include <iostream>
#include <set>
#include <vector>
using namespace std;
int a[200010], x[200010], y[200010];
vector<int> v[200010], ans;
set<int> s, t;
int main()
{
    int i, n, m;
    cin >> n >> m;
    for (i = 0; i < n; i++)
        cin >> a[i];
    for (i = 0; i < m; i++)
    {
        cin >> x[i] >> y[i];
        x[i]--;
        y[i]--;
        a[x[i]]--;
        a[y[i]]--;
        v[x[i]].push_back(i);
        v[y[i]].push_back(i);
    }
    for (i = 0; i < m; i++)
    {
        if (a[x[i]] >= 0 || a[y[i]] >= 0)
            s.insert(i);
    }
    while (s.size())
    {
        int j = *s.begin();
        s.erase(j);
        ans.push_back(j);
        t.insert(j);
        a[x[j]]++;
        a[y[j]]++;
        if (a[x[j]] >= 0)
        {
            for (int z : v[x[j]])
            {
                if (!t.count(z))
                    s.insert(z);
            }
            v[x[j]].clear();
        }
        if (a[y[j]] >= 0)
        {
            for (int z : v[y[j]])
            {
                if (!t.count(z))
                    s.insert(z);
            }
            v[y[j]].clear();
        }
    }
    if (ans.size() == m)
    {
        cout << "ALIVE" << endl;
        for (i = m - 1; i >= 0; i--)
            cout << ans[i] + 1 << " ";
        cout << endl;
    }
    else
    {
        cout << "DEAD" << endl;
    }
}