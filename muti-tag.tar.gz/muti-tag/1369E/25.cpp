﻿#include <bits/stdc++.h>
using namespace std;
const int maxn = 2e5 + 10;

vector<pair<int, int> > vec[maxn];
vector<int> ans;
int w[maxn], vis[maxn], vis2[maxn];
int sum[maxn];
int n, m;
queue<int> que;

bool bfs()
{
    for (int i = 1; i <= n; i++)
        if (sum[i] <= w[i])
        {
            que.emplace(i);
            vis2[i] = 1;
        }
    while (!que.empty())
    {
        int x = que.front();
        que.pop();
        for (auto& tmp : vec[x])
        {
            int v = tmp.first, y = tmp.second;
            if (!vis[v])
                ans.emplace_back(v);
            vis[v] = 1;
            if (--sum[y] <= w[y] && !vis2[y])
            {
                vis2[y] = 1;
                que.emplace(y);
            }
        }
    }
    return (int)ans.size() == m;
}

int main()
{
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= n; i++)
        scanf("%d", &w[i]);
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        scanf("%d%d", &x, &y);
        ++sum[x];
        ++sum[y];
        vec[x].emplace_back(i, y);
        vec[y].emplace_back(i, x);
    }
    if (!bfs())
        printf("DEAD\n");
    else
    {
        printf("ALIVE\n");
        for (int i = m - 1; i >= 0; i--)
            printf("%d%c", ans[i], i ? ' ' : '\n');
    }
    return 0;
}
