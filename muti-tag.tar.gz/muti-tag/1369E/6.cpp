﻿#include <bits/stdc++.h>
using namespace std;
#define int long long
#define ll long long
#define pii pair<int, int>
#define mk(x, y) make_pair(x, y)
inline ll read()
{
    ll x = 0;
    char ch = getchar();
    bool f = 0;
    for (; !isdigit(ch); ch = getchar())
        if (ch == '-')
            f = 1;
    for (; isdigit(ch); ch = getchar())
        x = x * 10 + ch - '0';
    return f ? -x : x;
}
void write(ll x)
{
    if (x < 0)
        putchar('-'), x = -x;
    if (x >= 10)
        write(x / 10);
    putchar(x % 10 + '0');
}
void writeln(ll x)
{
    write(x);
    putchar('\n');
}
void writep(ll x)
{
    write(x);
    putchar(' ');
}

int const N = 2e5 + 3;
int n, m, w[N], x[N], y[N], sum[N], vis[N], Vis[N], ans[N];
vector<int> v[N];
queue<int> q;

signed main()
{
    //	freopen("meal.in","r",stdin);
    //	freopen("meal.out","w",stdout);
    n = read();
    m = read();
    for (int i = 1; i <= n; i++)
        w[i] = read();
    for (int i = 1; i <= m; i++)
        x[i] = read(), y[i] = read(), sum[x[i]]++, sum[y[i]]++, v[x[i]].push_back(i),
        v[y[i]].push_back(i);
    for (int i = 1; i <= n; i++)
        if (sum[i] <= w[i])
        {
            Vis[i] = 1;
            for (int j = 0; j < v[i].size(); j++)
                if (!vis[v[i][j]])
                    vis[v[i][j]] = i, q.push(v[i][j]);
        }
    int tot = 0;
    while (!q.empty())
    {
        int u = q.front();
        q.pop();
        ans[++tot] = u;
        if (vis[u] != x[u])
            swap(x[u], y[u]);
        sum[y[u]]--;
        if (sum[y[u]] <= w[y[u]] && !Vis[y[u]])
        {
            Vis[y[u]] = 1;
            for (int i = 0; i < v[y[u]].size(); i++)
                if (!vis[v[y[u]][i]])
                    vis[v[y[u]][i]] = y[u], q.push(v[y[u]][i]);
        }
    }
    if (tot == m)
    {
        puts("ALIVE");
        for (int i = m; i; i--)
            writep(ans[i]);
    }
    else
        puts("DEAD");
    return 0;
}
/*
3 3
1 2 1
1 2
2 3
1 3
*/