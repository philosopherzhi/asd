﻿#include <bits/stdc++.h>
#define N 400010
#define ll long long
#define ull unsigned long long
#define mo (ll)((ll)1e9 + 7)
#define squ(x) ((x) * (x))
#define db double
#define all(x) x.begin(), x.end()
#define cmax(a, b) a = max(a, b)
#define cmin(a, b) a = min(a, b)
#define rep(i, l, r) for (register int i = l; i <= r; ++i)
#define drep(i, r, l) for (register int i = r; i >= l; --i)
#define pb push_back
#define inline inline __attribute__((always_inline))
using namespace std;

inline ll read()
{
    ll x = 0, f = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9')
    {
        if (ch == '-')
            f = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9')
    {
        x = x * 10 + ch - '0';
        ch = getchar();
    }
    return x * f;
}
int w[N], s[N], A[N][2];
bool guest[N], vis[N];
vector<int> v[100010], ans;
int main()
{
    int n = read(), m = read();
    rep(i, 1, n) w[i] = read();
    rep(i, 1, m)
    {
        int x = read(), y = read();
        A[i][0] = x, A[i][1] = y;
        v[x].pb(i), v[y].pb(i);
        ++s[x], ++s[y];
    }
    set<pair<int, int> > S;
    rep(i, 1, n) S.insert(make_pair(s[i] - w[i], i));
    while (!S.empty() && (*S.begin()).first <= 0)
    {
        auto x = *S.begin();
        S.erase(S.begin());
        // x.second -> kind of food
        if (vis[x.second])
            continue;
        vis[x.second] = 1;
        for (int y : v[x.second])
            if (!guest[y])
            {
                guest[y] = 1;
                ans.pb(y);
                int p = (x.second == A[y][0]) ? A[y][1] : A[y][0];
                if (!vis[p])
                    S.insert(make_pair((--s[p]) - w[p], p));
            }
    }
    if (ans.size() == m)
    {
        puts("ALIVE");
        reverse(ans.begin(), ans.end());
        for (int x : ans)
            printf("%d ", x);
    }
    else
        puts("DEAD");
    return 0;
}