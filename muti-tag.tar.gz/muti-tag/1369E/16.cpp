﻿#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <map>
#include <string>
#include <iomanip>
#include <set>
using namespace std;
#define int long long
void solve()
{
    int n, m;
    cin >> n >> m;
    vector<int> w(n);
    for (int i = 0; i < n; ++i)
    {
        cin >> w[i];
    }
    vector<pair<int, int>> a(m);
    vector<vector<int>> g(n);
    vector<int> cnt(n);
    vector<int> used(m);
    for (int i = 0; i < m; ++i)
    {
        cin >> a[i].first >> a[i].second;
        --a[i].first, --a[i].second;
        g[a[i].first].push_back(i);
        g[a[i].second].push_back(i);
        cnt[a[i].first]++;
        cnt[a[i].second]++;
    }
    vector<int> usedv(n);
    queue<int> q;
    for (int i = 0; i < n; ++i)
    {
        if (g[i].size() <= w[i])
        {
            q.push(i);
            usedv[i] = 1;
        }
    }
    vector<int> ans;
    while (!q.empty())
    {
        int num = q.front();
        q.pop();
        for (auto u : g[num])
        {
            if (used[u])
                continue;
            ans.push_back(u + 1);
            used[u] = 1;
            int v1 = a[u].first;
            int v2 = a[u].second;
            cnt[v1]--;
            cnt[v2]--;
            if (!usedv[v1] && cnt[v1] <= w[v1])
            {
                usedv[v1] = 1;
                q.push(v1);
            }
            swap(v1, v2);
            if (!usedv[v1] && cnt[v1] <= w[v1])
            {
                usedv[v1] = 1;
                q.push(v1);
            }
        }
        g[num].clear();
    }
    if (ans.size() == m)
    {
        cout << "ALIVE\n";
        reverse(ans.begin(), ans.end());
        for (auto i : ans)
            cout << i << ' ';
        return;
    }
    cout << "DEAD";
}
int32_t main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int tt = 1;
    while (tt--)
    {
        solve();
    }
}
