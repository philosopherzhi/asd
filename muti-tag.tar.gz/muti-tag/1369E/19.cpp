﻿#include <bits/stdc++.h>
using namespace std;


int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    long long n, m;
    cin >> n >> m;


    long long w[n];

    long long s[n];

    memset(s, 0, sizeof(s));

    for (long long i = 0; i < n; i++)
        cin >> w[i];

    vector<pair<long long, long long> > friends;

    vector<long long> food[n];

    for (long long i = 0; i < n; i++)
    {
        vector<long long> vv;
        food[i] = vv;
    }

    for (long long i = 0; i < m; i++)
    {
        long long x, y;
        cin >> x >> y;
        x--;
        y--;
        friends.push_back(make_pair(x, y));
        food[x].push_back(i);
        food[y].push_back(i);
        s[x]++;
        s[y]++;
    }


    stack<long long> result;

    long long erasedFriends[m];

    long long erasedFood[n];


    memset(erasedFriends, 0, sizeof(erasedFriends));

    memset(erasedFood, 0, sizeof(erasedFood));

    priority_queue<pair<long long, long long> > pq;

    for (long long i = 0; i < n; i++)
    {

        pq.push(make_pair(w[i] - s[i], i));
    }


    long long erased = 0;

    while (!pq.empty())
    {
        pair<long long, long long> curp = pq.top();
        pq.pop();

        long long ind = curp.second;
        long long value = curp.first;

        if (erasedFood[ind] == 0)
        {
            if (value < 0)
                break;
            for (long long j = 0; j < food[ind].size(); j++)
            {
                if (erasedFriends[food[ind][j]] == 0)
                {
                    long long friendInd = food[ind][j];
                    s[friends[friendInd].first]--;
                    s[friends[friendInd].second]--;
                    pq.push(make_pair(w[friends[friendInd].first] - s[friends[friendInd].first],
                        friends[friendInd].first));
                    pq.push(make_pair(w[friends[friendInd].second] - s[friends[friendInd].second],
                        friends[friendInd].second));
                    erasedFriends[friendInd] = 1;
                    result.push(friendInd + 1);
                    erased++;
                }
            }

            erasedFood[ind] = 1;
        }
        else
        {
            continue;
        }
    }


    if (erased == m)
    {
        cout << "ALIVE" << endl;
        long long sz = result.size();
        for (long long i = 0; i < sz; i++)
        {
            cout << result.top() << " ";
            result.pop();
        }
    }
    else
    {
        cout << "DEAD" << endl;
    }


    return 0;
}