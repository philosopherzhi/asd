﻿#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define ii pair<int, int>
#define vi vector<int>
#define pb push_back
#define fast                                                                                       \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0);
#define f first
#define s second
const int mod = 1e9 + 7;
const int inf = 1e9 + 10;
const int N = 5e2 + 10;
int a[N][N], x[N * N], y[N * N], t[N * N];

int main()
{
    fast;
    int n, m, k, q;
    cin >> n >> m >> k >> q;
    for (int i = 0; i < q; i++)
        cin >> x[i] >> y[i] >> t[i];
    int l = 0, r = inf, res = inf;
    while (l <= r)
    {
        int ans = inf;
        memset(a, 0, sizeof(a));
        int mid = (l + r) / 2;
        for (int i = 0; i < q; i++)
        {
            if (t[i] <= mid)
                a[x[i]][y[i]] = 1;
        }
        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= m; j++)
            {
                a[i][j] += (a[i - 1][j] + a[i][j - 1] - a[i - 1][j - 1]);
            }
        }
        for (int i = k; i <= n; i++)
        {
            for (int j = k; j <= m; j++)
            {
                int cnt = a[i][j] + a[i - k][j - k] - a[i][j - k] - a[i - k][j];
                if (cnt == k * k)
                    ans = mid;
            }
        }
        res = min(ans, res);
        if (ans == inf)
            l = mid + 1;
        else
            r = mid - 1;
    }
    if (res == inf)
        cout << -1 << '\n';
    else
        cout << res << '\n';
    return 0;
}