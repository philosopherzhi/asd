﻿/* -*- coding: utf-8 -*-
 *
 * 0846D.cc: D. Monitor
 */

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <list>
#include <queue>
#include <deque>
#include <algorithm>
#include <numeric>
#include <utility>
#include <complex>
#include <functional>

using namespace std;

/* constant */

const int MAX_H = 500;
const int MAX_W = 500;
const int MAX_E2 = 1 << 10; // = 1024
const int INF = 1 << 30;

/* typedef */

template <typename T, const int MAX_E2>
struct SegTree2D
{
    int e2;
    T nodes[MAX_E2][MAX_E2];
    SegTree2D()
    {
    }

    void init(int n)
    {
        for (e2 = 1; e2 < n; e2 <<= 1)
            ;
    }

    T& geti(int i0, int i1)
    {
        return nodes[e2 - 1 + i0][e2 - 1 + i1];
    }
    void seti(int i0, int i1, T v)
    {
        geti(i0, i1) = v;
    }

    void setall()
    {
        for (int j0 = e2 - 2; j0 >= 0; j0--)
        {
            int k00 = j0 * 2 + 1, k01 = k00 + 1;
            for (int j1 = e2 - 2; j1 >= 0; j1--)
            {
                int k10 = j1 * 2 + 1, k11 = k10 + 1;
                nodes[j0][j1] = max(
                    max(nodes[k00][k10], nodes[k00][k11]), max(nodes[k01][k10], nodes[k01][k11]));
            }
        }
    }

    T max_range(
        int r00, int r01, int r10, int r11, int k0, int k1, int i00, int i01, int i10, int i11)
    {
        if (r01 <= i00 || i01 <= r00 || r11 <= i10 || i11 <= r10)
            return 0;
        if (r00 <= i00 && i01 <= r01 && r10 <= i10 && i11 <= r11)
            return nodes[k0][k1];

        int im0 = (i00 + i01) / 2, im1 = (i10 + i11) / 2;
        int k00 = k0 * 2 + 1, k01 = k00 + 1;
        int k10 = k1 * 2 + 1, k11 = k10 + 1;

        T v00 = max_range(r00, r01, r10, r11, k00, k10, i00, im0, i10, im1);
        T v01 = max_range(r00, r01, r10, r11, k00, k11, i00, im0, im1, i11);
        T v10 = max_range(r00, r01, r10, r11, k01, k10, im0, i01, i10, im1);
        T v11 = max_range(r00, r01, r10, r11, k01, k11, im0, i01, im1, i11);
        return max(max(v00, v01), max(v10, v11));
    }
    T max_range(int r00, int r01, int r10, int r11)
    {
        return max_range(r00, r01, r10, r11, 0, 0, 0, e2, 0, e2);
    }
};

/* global variables */

SegTree2D<int, MAX_E2> st;

/* subroutines */

/* main */

int main()
{
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);

    int h, w, k, q;
    scanf("%d%d%d%d", &h, &w, &k, &q);

    st.init(max(h, w));

    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
            st.seti(y, x, INF);

    while (q--)
    {
        int yi, xi, ti;
        scanf("%d%d%d", &yi, &xi, &ti);
        yi--, xi--;
        st.seti(yi, xi, ti);
    }
    st.setall();

    int mint = INF;
    for (int y = 0; y + k <= h; y++)
        for (int x = 0; x + k <= w; x++)
        {
            int t = st.max_range(y, y + k, x, x + k);
            if (mint > t)
                mint = t;
        }

    printf("%d\n", (mint < INF) ? mint : -1);
    return 0;
}
