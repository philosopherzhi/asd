﻿#include <bits/stdc++.h>
using namespace std;
const int inf = 1e9 + 7;
int n, m, p, q, ans = inf;
int e[505][505], maxx[505][505];
int main()
{
    memset(e, 0x3f, sizeof(e));
    scanf("%d%d%d%d", &n, &m, &p, &q);
    for (int i = 1; i <= q; i++)
    {
        int x, y, z;
        scanf("%d%d%d", &x, &y, &z);
        e[x][y] = z;
    }
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m - p + 1; j++)
            for (int k = j; k < j + p; k++)
                maxx[i][j] = max(maxx[i][j], e[i][k]);
    for (int i = 1; i <= n - p + 1; i++)
        for (int j = 1; j <= m - p + 1; j++)
        {
            int maxn = 0;
            for (int k = i; k < i + p; k++)
                maxn = max(maxx[k][j], maxn);
            ans = min(maxn, ans);
        }
    if (ans >= inf)
        printf("-1");
    else
        printf("%d\n", ans);
    return 0;
}
