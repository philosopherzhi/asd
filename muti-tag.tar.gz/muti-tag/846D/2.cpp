﻿#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define mp make_pair
#define pb push_back
#define sc second
#define fr first
#define scl(n) scanf("%lld", &n)
#define scll(n, m) scanf("%lld%lld", &n, &m)
#define scs(ch) scanf("%s", ch)
#define pll pair<ll, ll>

set<ll> st;
set<ll>::iterator it;

ll tmp[502][502], ara[502][502], n, m, p, q;


bool op(ll val)
{
    ll i, j, k, x, y, z;
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= m; j++)
        {
            tmp[i][j] = tmp[i][j - 1] + tmp[i - 1][j] - tmp[i - 1][j - 1];
            if (ara[i][j] <= val)
            {
                tmp[i][j]++;
            }
            if (i < p || j < p)
                continue;
            x = i - p;
            y = j - p;
            z = tmp[i][j] - tmp[i][y] - tmp[x][j] + tmp[x][y];
            if (z == p * p)
                return true;
        }
    }

    return false;
}

int main()
{
    ll test, t, i, j, k, a, b, c, x, y, z;

    scll(n, m);
    scll(p, q);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= m; j++)
        {
            ara[i][j] = (1e9) + 10;
        }
    }
    for (i = 1; i <= q; i++)
    {
        scll(a, b);
        scl(c);
        ara[a][b] = c;
    }
    ll lo, hi, mid;
    lo = 0;
    hi = 1e9;
    hi++;
    z = -1;
    while (lo <= hi)
    {
        mid = (lo + hi) / 2;
        if (op(mid))
        {
            z = mid;
            hi = mid - 1;
        }
        else
        {
            lo = mid + 1;
        }
    }
    cout << z << endl;

    return 0;
}
