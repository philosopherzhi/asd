﻿#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int map[505][505], maxx[505][505];
int main()
{
    memset(map, 0x3f, sizeof(map));
    int n, m, k, q, ans = 2e9;
    scanf("%d%d%d%d", &n, &m, &k, &q);
    for (int i = 1; i <= q; i++)
    {
        int x, y, z;
        scanf("%d%d%d", &x, &y, &z);
        map[x][y] = z;
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= m - k + 1; j++)
        {
            for (int qwq = j; qwq < j + k; qwq++)
                maxx[i][j] = max(maxx[i][j], map[i][qwq]);
        }
    }
    for (int i = 1; i <= n - k + 1; i++)
    {
        for (int j = 1; j <= m - k + 1; j++)
        {
            int maxn = 0;
            for (int qwq = i; qwq < i + k; qwq++)
                maxn = max(maxx[qwq][j], maxn);
            ans = min(maxn, ans);
        }
    }
    if (ans > 1e9)
        cout << -1;
    else
        cout << ans;
    return 0;
}
