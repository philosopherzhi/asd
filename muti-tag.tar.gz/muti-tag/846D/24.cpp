﻿#include <bits/stdc++.h>
using namespace std;
inline int read()
{
    int x = 0, f = 1;
    char c = getchar();
    while (c < '0' || c > '9')
    {
        if (c == '-')
            f = 0;
        c = getchar();
    }
    while (c >= '0' && c <= '9')
        x = (x << 3) + (x << 1) + (c ^ 48), c = getchar();
    return f ? x : -x;
}
int n, m, k, q, a[505][505], t[505][505], ans = 0x3f3f3f3f;
signed main()
{
    n = read(), m = read(), k = read(), q = read();
    memset(a, 0x3f, sizeof(a));
    while (q--)
    {
        int x = read(), y = read(), t = read();
        a[x][y] = t;
    }
    for (int i = 1; i <= n; i++)
        for (int j = 1; j + k - 1 <= m; j++)
            for (int l = 0; l < k; l++)
                t[i][j] = max(t[i][j], a[i][j + l]);
    for (int i = 1; i + k - 1 <= n; i++)
    {
        for (int j = 1; j + k - 1 <= m; j++)
        {
            int tim = 0;
            for (int l = 0; l < k; l++)
                tim = max(tim, t[i + l][j]);
            ans = min(ans, tim);
        }
    }
    printf("%d", ans == 0x3f3f3f3f ? -1 : ans);
    return 0;
}
