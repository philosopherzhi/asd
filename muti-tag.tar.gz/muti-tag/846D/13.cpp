﻿#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <functional>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <unordered_map>
#include <vector>
#define lowbit(x) ((x) & -(x))
#define endl "\n"
using namespace std;
typedef pair<int, int> pii;
typedef long long ll;
typedef unsigned long long ull;
const int N = 1e6 + 10, NN = 5e2 + 10, INF = 0x3f3f3f3f, LEN = 20;
const ll MOD = 1e9 + 7;
const ull seed = 31;
inline int read()
{
    int x = 0, f = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9')
    {
        if (ch == '-')
            f = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9')
    {
        x = (x << 1) + (x << 3) + (ch ^ 48);
        ch = getchar();
    }
    return x * f;
}
struct A
{
    int x, y, val;
} a[N];
int n, m, k, q;
int sum[NN][NN];
void init()
{
}
bool check(int x)
{
    memset(sum, 0, sizeof sum);
    for (int i = 1; i <= q; ++i)
        if (a[i].val <= x)
            sum[a[i].x][a[i].y] = 1;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m; ++j)
        {
            sum[i][j] += sum[i - 1][j] + sum[i][j - 1] - sum[i - 1][j - 1];
            if (i >= k && j >= k
                && sum[i][j] - sum[i - k][j] - sum[i][j - k] + sum[i - k][j - k] == k * k)
                return true;
        }
    return false;
}
int main()
{
    // ios::sync_with_stdio(false);
    // cin.tie(0);
    // cout.tie(0);
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
    n = read();
    m = read();
    k = read();
    q = read();
    for (int i = 1; i <= q; ++i)
    {
        a[i].x = read();
        a[i].y = read();
        a[i].val = read();
    }
    int l = 0, r = 1e9;
    while (l <= r)
    {
        int mid = (l + r) >> 1;
        if (check(mid))
            r = mid - 1;
        else
            l = mid + 1;
    }
    if (r == 1e9)
        puts("-1");
    else
        printf("%d\n", r + 1);
    return 0;
}
