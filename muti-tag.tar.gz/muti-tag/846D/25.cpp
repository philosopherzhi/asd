﻿#include <bits/stdc++.h>

using namespace std;

#define ffor(i, o, f) for (int i = o; i < f; i++)
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define F first
#define S second
#define PI 3.14159265358979323846264338327950
#define endl '\n'
#define lcm(a, b) (a * b) / __gcd(a, b)
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<pii> vii;
typedef vector<vi> gi;
typedef vector<ll> vll;
typedef map<int, int> mii;
const int INF = int(1e9 + 7);

int n, m, k, q;
vector<pair<int, pii> > v;
int M[505][505];

bool broken(int t)
{
    int mx = 0;
    memset(M, 0, sizeof(M));
    ffor(i, 0, v.size())
    {
        if (v[i].F <= t)
            M[v[i].S.F][v[i].S.S] = 1;
    }
    ffor(i, 1, n + 1)
    {
        ffor(j, 1, m + 1)
        {
            M[i][j] = M[i][j] + M[i - 1][j] + M[i][j - 1] - M[i - 1][j - 1];
        }
    }
    ffor(i, k, n + 1)
    {
        ffor(j, k, m + 1)
        {
            mx = max(mx, M[i][j] - M[i - k][j] - M[i][j - k] + M[i - k][j - k]);
        }
    }
    if (mx >= k * k)
        return true;
    return false;
}

int main() // IBMG
{
    // ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    // freopen("","r",stdin);
    // freopen("","w",stdout);
    int x, y, t;
    cin >> n >> m >> k >> q;
    ffor(i, 0, q)
    {
        cin >> x >> y >> t;
        v.pb(mp(t, mp(x, y)));
    }
    sort(all(v));
    int lo = 0, hi = 1e9, mid, ans = -1;
    while (lo <= hi)
    {
        mid = (lo + hi) / 2;
        if (broken(mid))
        {
            hi = mid - 1;
            ans = mid;
        }
        else
            lo = mid + 1;
    }
    cout << ans << endl;
    return 0;
}