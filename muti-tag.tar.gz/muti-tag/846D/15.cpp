﻿#include <bits/stdc++.h>
using namespace std;
#define Go_                                                                                        \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(0);                                                                                    \
    cout.tie(0);
#define ll long long int
#define llu long long unsigned int
#define pii pair<int, int>
#define PII pair<ll, ll>

const int Max = 1e9 + 100;
const ll MAX = 1e18 + 500;
const int sz = 510;

int sum[sz][sz];
int ara[sz][sz];
int n, m;

void init()
{
    memset(sum, 0, sizeof sum);
    for (int i = 1; i <= m; i++)
        sum[0][i] = ara[0][i];
    for (int i = 1; i <= n; i++)
        sum[i][0] = ara[i][0];

    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= m; j++)
        {
            sum[i][j] = sum[i - 1][j] + sum[i][j - 1] - sum[i - 1][j - 1] + ara[i][j];
        }
    }
}

int query(int x, int y, int k)
{
    int X = x + k - 1, Y = y + k - 1;
    int tot = sum[X][Y] - sum[X][y - 1] - sum[x - 1][Y] + sum[x - 1][y - 1];
    return tot;
}
int main()
{
    Go_ int a, b, c, i, j, k, q, p, x, y, ct, ct1, l, r, x1, y1, mn, h, sum1, in, z, mid, mx;
    char ch;
    double d;
    string str1, str2, str;
    bool bl, bl1;
    int t, cs = 1;

    cin >> n >> m >> k >> q;

    pii pip[q];
    int time[q];

    for (int i = 0; i < q; i++)
        cin >> pip[i].first >> pip[i].second >> time[i];

    l = 0, r = Max;
    mn = Max;

    while (l <= r)
    {
        int mid = (l + r) / 2;
        memset(ara, 0, sizeof ara);
        for (int i = 0; i < q; i++)
        {
            if (time[i] <= mid)
                ara[pip[i].first][pip[i].second] = 1;
        }

        init();

        bool bl = false;
        for (int i = 1; i <= n && !bl; i++)
        {
            for (int j = 1; j <= m; j++)
            {
                if ((i + k - 1) <= n && (j + k - 1) <= m && query(i, j, k) == (k * k))
                {
                    bl = true;
                    break;
                }
            }
        }

        if (bl)
        {
            mn = min(mn, mid);
            r = mid - 1;
        }
        else
            l = mid + 1;
    }

    if (mn >= Max)
        cout << "-1\n";
    else
        cout << mn << '\n';
}
