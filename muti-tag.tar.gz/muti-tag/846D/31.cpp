﻿#include <bits/stdc++.h>

#define D(x) cout << #x << " = " << x << "\n"
#define II()                                                                                       \
    (                                                                                              \
        {                                                                                          \
            int a;                                                                                 \
            read(a);                                                                               \
            a;                                                                                     \
        })
#define LL()                                                                                       \
    (                                                                                              \
        {                                                                                          \
            ll a;                                                                                  \
            read(a);                                                                               \
            a;                                                                                     \
        })
#define DD()                                                                                       \
    (                                                                                              \
        {                                                                                          \
            double a;                                                                              \
            scanf("%lf", &a);                                                                      \
            a;                                                                                     \
        })

using namespace std;

/* ordered set !!
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
template <typename T> using o_set = tree<T, null_type, less<T>, rb_tree_tag,
tree_order_statistics_node_update>;
*/

// Fast Reader
template <class T>
inline bool read(T& x)
{
    int c = getchar();
    int sgn = 1;
    while (~c && c < '0' || c > '9')
    {
        if (c == '-')
            sgn = -1;
        c = getchar();
    }
    for (x = 0; ~c && '0' <= c && c <= '9'; c = getchar())
        x = x * 10 + c - '0';
    x *= sgn;
    return ~c;
}

typedef long long ll;
typedef vector<int> VI;
typedef vector<VI> VVI;

const int INF = 2e9;
const int MX = 505;
const int MOD = 1000000007;
const double PI = acos(-1.0);

/*_______________________________________________*/
int n, m, k, q;
struct pix
{
    int x, y, t;
    pix(){};
    pix(int x, int y, int t)
        : x(x)
        , y(y)
        , t(t){};
    bool operator<(const pix& p) const
    {
        return t < p.t;
    }
};

vector<pix> pixArr;
int checkArr[MX][MX];

bool check(int pos)
{
    memset(checkArr, 0, sizeof(checkArr));
    for (int i = 0; i <= pos; i++)
        checkArr[pixArr[i].x][pixArr[i].y] = 1;

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if (i > 0)
                checkArr[i][j] += checkArr[i - 1][j];
            if (j > 0)
                checkArr[i][j] += checkArr[i][j - 1];
            if (i > 0 && j > 0)
                checkArr[i][j] -= checkArr[i - 1][j - 1];
        }
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            int temp = checkArr[i][j];
            if (i - k > -1)
                temp -= checkArr[i - k][j];
            if (j - k > -1)
                temp -= checkArr[i][j - k];
            if (i - k > -1 && j - k > -1)
                temp += checkArr[i - k][j - k];
            if (temp == k * k)
                return true;
        }
    }
    return false;
}

int main()
{
    n = II();
    m = II();
    k = II();
    q = II();

    for (int i = 0; i < q; i++)
    {
        int x = II() - 1, y = II() - 1, t = II();
        pixArr.push_back(pix(x, y, t));
    }

    sort(pixArr.begin(), pixArr.end());

    int ans = -1;
    int l = 0, r = q - 1;
    while (l <= r)
    {
        int mid = (l + r) / 2;
        if (check(mid))
        {
            ans = pixArr[mid].t;
            r = mid - 1;
        }
        else
            l = mid + 1;
    }

    printf("%d\n", ans);

    return 0;
}