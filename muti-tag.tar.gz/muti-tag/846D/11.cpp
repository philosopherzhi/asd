﻿// nani?
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp> // Common file
#include <ext/pb_ds/tree_policy.hpp> // Including tree_order_statistics_node_update

//#define pi acos(-1);
#define fs first
#define sc second
#define pb push_back
#define mp make_pair
#define f(i, a, b) for (int i = a; i < b; i++)
#define sor(a) sort(a.begin(), a.end())
#define rsor(a) sort(a.rbegin(), a.rend())
#define fastio                                                                                     \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0)
typedef long long ll;
typedef long double ld;
using namespace std;
using namespace __gnu_pbds;
const ll inf = 1e18 + 7;
const ll MOD = 1e9 + 7;
const ll mod = 1e9;
// ac cmtr;
const int MX = 1e6 + 5;
const int LG = 25;
// const int INF = int(1e9);
// const li INF64 = li(1e18);

typedef tree<pair<ll, pair<ll, ll> >, null_type, less<pair<ll, pair<ll, ll> > >, rb_tree_tag,
    tree_order_statistics_node_update> ordered_set;

#define trace(...) fff(#__VA_ARGS__, __VA_ARGS__)
template <typename t>
void fff(const char* x, t&& val1)
{
    cout << x << " : " << val1 << "\n";
}
template <typename t1, typename... t2>
void fff(const char* x, t1&& val1, t2&&... val2)
{
    const char* xd = strchr(x + 1, ',');
    cout.write(x, xd - x) << " : " << val1 << " | ";
    fff(xd + 1, val2...);
}
//---------------------------

ll n, m, k, q;
vector<pair<pair<ll, ll>, ll> > v;
ll a[505][505], acum[505][505], acm[505][505];

bool ok(ll time)
{
    f(i, 0, 505)
    {
        f(j, 0, 505)
        {
            a[i][j] = 0;
            acum[i][j] = 0;
            acm[i][j] = 0;
        }
    }
    f(i, 0, v.size())
    {
        if (v[i].sc <= time)
        {
            a[v[i].fs.fs][v[i].fs.sc] = 1;
        }
    }
    f(i, 1, n + 1) acum[i][m] = a[i][m];
    f(i, 1, n + 1)
    {
        for (int j = m - 1; j >= 1; j--)
        {
            acum[i][j] = acum[i][j + 1] + a[i][j];
        }
    }
    f(i, 1, m + 1) acm[n][i] = acum[n][i];
    f(i, 1, m + 1)
    {
        for (int j = n - 1; j >= 1; j--)
        {
            acm[j][i] = acm[j + 1][i] + acum[j][i];
        }
    }
    /*f(i,1,n+1){
            f(j,1,m+1){
            cout << acm[i][j] << " ";
    }
  cout << endl;
}*/
    bool ok = 0;
    f(i, 1, n - k + 2)
    {
        f(j, 1, m - k + 2)
        {
            ll rep = acm[i][j] + acm[i + k][j + k] - acm[i][j + k] - acm[i + k][j];
            if (rep == k * k)
                return 1;
        }
    }
    return 0;
}

int main()
{
    fastio;
    cin >> n >> m >> k >> q;
    ll mx = -1;
    f(i, 0, q)
    {
        ll a, b, c;
        cin >> a >> b >> c;
        v.pb({ { a, b }, c });
        mx = max(mx, c);
    }
    // trace(mx);
    // trace(ok(8));
    if (ok(mx) == 0)
    {
        cout << -1 << endl;
        return 0;
    }
    ll l = 0, r = 1e18;
    while (l < r)
    {
        ll mid = (l + r) / 2;
        if (ok(mid))
            r = mid;
        else
            l = mid + 1;
    }
    /*while((fin-ini) > 1){
        ll mid  = (ini+fin) >> 1;
        if(ok(mid)) fin = mid;
        else ini = mid;
    }*/
    cout << r << endl;
}