﻿#pragma GCC target("avx2")
// #pragma GCC optimization ("O3")
#pragma GCC optimization("unroll-loops")

#include <iostream>
#include <array>
#include <algorithm>
#include <vector>
#include <bitset>
#include <set>
#include <unordered_set>
#include <cmath>
#include <complex>
#include <deque>
#include <iterator>
#include <numeric>
#include <map>
#include <unordered_map>
#include <queue>
#include <stack>
#include <string>
#include <tuple>
#include <utility>
#include <limits>
#include <iomanip>
#include <functional>
#include <cassert>
// #include <atcoder/all>
using namespace std;

using ll = long long;
template <class T>
using V = vector<T>;
template <class T, class U>
using P = pair<T, U>;
using vll = V<ll>;
using vii = V<int>;
using vvll = V<vll>;
using vvii = V<V<int> >;
using PII = P<int, int>;
using PLL = P<ll, ll>;
#define RevREP(i, n, a) for (ll i = n; i > a; i--) // (a,n]
#define REP(i, a, n) for (ll i = a; i < n; i++) // [a,n)
#define rep(i, n) REP(i, 0, n)
#define ALL(v) v.begin(), v.end()
#define eb emplace_back
#define pb push_back
#define sz(v) int(v.size())

template <class T>
inline bool chmax(T& a, T b)
{
    if (a < b)
    {
        a = b;
        return true;
    }
    return false;
}
template <class T>
inline bool chmin(T& a, T b)
{
    if (a > b)
    {
        a = b;
        return true;
    }
    return false;
}
template <class A, class B>
ostream& operator<<(ostream& out, const P<A, B>& p)
{
    return out << '(' << p.first << ", " << p.second << ')';
}
template <class A>
ostream& operator<<(ostream& out, const V<A>& v)
{
    out << '[';
    for (int i = 0; i < int(v.size()); i++)
    {
        if (i)
            out << ", ";
        out << v[i];
    }
    return out << ']';
}

const long long MOD = 1000000007;
const long long HIGHINF = (long long)1e18;
const int INF = (int)1e9;

int main()
{
    cin.tie(0);
    ios::sync_with_stdio(false);
    int n, m, k, q;
    cin >> n >> m >> k >> q;
    V<P<PII, int> > xyt(q);
    rep(i, q)
    {
        cin >> xyt[i].first.first >> xyt[i].first.second >> xyt[i].second;
    }
    sort(ALL(xyt), [&](P<PII, int>& i, P<PII, int>& j)
        {
            return i.second < j.second;
        });

    int low = 0, high = INF + 7;
    while (low < high)
    {
        vvii imos(n + 1, vii(m + 1, 0));
        int mid = (low + high) >> 1;
        rep(i, q)
        {
            if (xyt[i].second > mid)
                break;
            auto[x, y] = xyt[i].first;
            imos[x][y]++;
        }
        rep(i, n + 1) REP(j, 1, m + 1) imos[i][j] += imos[i][j - 1];
        rep(j, m + 1) REP(i, 1, n + 1) imos[i][j] += imos[i - 1][j];

        bool ok = false;
        REP(i, k, n + 1) REP(j, k, m + 1)
        {
            if (imos[i][j] - imos[i - k][j] - imos[i][j - k] + imos[i - k][j - k] == k * k)
            {
                ok = true;
                break;
            }
        }

        if (ok)
            high = mid;
        else
            low = mid + 1;
    }
    cout << (low > INF ? -1 : low) << '\n';
    return 0;
}
