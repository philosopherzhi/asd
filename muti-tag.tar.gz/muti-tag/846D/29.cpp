﻿#include "bits/stdc++.h"
using namespace std;

#define fast                                                                                       \
    ios_base::sync_with_stdio(false);                                                              \
    cin.tie(NULL);                                                                                 \
    cout.tie(NULL);
#define ll long long
#define pb push_back
#define ff first
#define ss second
#define all(v) v.begin(), v.end()
#define test()                                                                                     \
    int tt;                                                                                        \
    cin >> tt;                                                                                     \
    while (tt--)
#define nl cout << "\n"
#define sz(v) ((int)(v).size())

const int MOD = 1e9 + 7;
void solve()
{
    int n, m, k, q;
    cin >> n >> m >> k >> q;
    vector<vector<int>> query(q);
    for (int i = 0; i < q; i++)
    {
        int x, y, t;
        cin >> x >> y >> t;
        query[i] = { t, x, y };
    }
    sort(all(query));
    int l = 0, r = 1e9 + 5;
    int ans = -1;
    while (l <= r)
    {
        int mid = l + (r - l) / 2;
        int cnt[n][m] = {};
        for (int i = 0; i < q; i++)
        {
            if (query[i][0] > mid)
                break;
            cnt[query[i][1] - 1][query[i][2] - 1]++;
        }
        for (int col = 1; col < m; col++)
            cnt[0][col] += cnt[0][col - 1];
        for (int row = 1; row < n; row++)
            cnt[row][0] += cnt[row - 1][0];
        for (int row = 1; row < n; row++)
        {
            for (int col = 1; col < m; col++)
            {
                cnt[row][col] += cnt[row - 1][col] + cnt[row][col - 1] - cnt[row - 1][col - 1];
            }
        }
        bool flag = false;
        for (int row = k - 1; row < n; row++)
        {
            for (int col = k - 1; col < m; col++)
            {
                int x = cnt[row][col];
                x -= (col - k >= 0 ? cnt[row][col - k] : 0);
                x -= (row - k >= 0 ? cnt[row - k][col] : 0);
                x += (row - k >= 0 and col - k >= 0 ? cnt[row - k][col - k] : 0);
                if (x >= k * k)
                {
                    flag = true;
                    break;
                }
            }
            if (flag)
                break;
        }
        if (flag)
            ans = mid, r = mid - 1;
        else
            l = mid + 1;
    }
    cout << ans;
}
int main()
{
    fast;
#ifndef ONLINE_JUDGE
    freopen("inputf.in", "r", stdin);
    freopen("outputf.in", "w", stdout);
#endif
    // test()
    solve();
}
