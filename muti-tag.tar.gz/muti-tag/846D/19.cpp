﻿#include <bits/stdc++.h>
using namespace std;
const int NR = 505;
void Min(int& x, int y)
{
    x = min(x, y);
}
void Max(int& x, int y)
{
    x = max(x, y);
}
int read()
{
    int x = 0, f = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9')
    {
        if (ch == '-')
            f = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9')
    {
        x = (x << 3) + (x << 1) + (ch ^ 48);
        ch = getchar();
    }
    return x * f;
}
int n, m, k, q;
struct Nd
{
    int x, y, t;
    bool operator<(const Nd& A) const
    {
        return t < A.t;
    }
} Q[NR * NR];
int sum[NR][NR];
int getsum(int r1, int c1, int r2, int c2)
{
    return sum[r1][c1] - sum[r1][c2 - 1] - sum[r2 - 1][c1] + sum[r2 - 1][c2 - 1];
}
bool check(int x)
{
    memset(sum, 0, sizeof(sum));
    for (int i = 1; i <= q; i++)
    {
        if (Q[i].t > x)
            break;
        sum[Q[i].x][Q[i].y]++;
    }
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            sum[i][j] = sum[i - 1][j] + sum[i][j - 1] - sum[i - 1][j - 1] + sum[i][j];
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            if (i >= k && j >= k && getsum(i, j, i - k + 1, j - k + 1) == k * k)
                return 1;
    return 0;
}
int main()
{
    n = read(), m = read(), k = read(), q = read();
    for (int i = 1; i <= q; i++)
        Q[i].x = read(), Q[i].y = read(), Q[i].t = read();
    sort(Q + 1, Q + q + 1);
    int l = 0, r = 1000000000, ans = -1;
    while (l <= r)
    {
        int mid = (l + r) / 2;
        if (check(mid))
            ans = mid, r = mid - 1;
        else
            l = mid + 1;
    }
    check(8);
    printf("%d\n", ans);
    return 0;
}
