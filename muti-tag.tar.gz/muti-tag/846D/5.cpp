﻿#include <bits/stdc++.h>
#define rep(i, a, b) for (register int i = (a); i <= (b); ++i)
#define req(i, a, b) for (register int i = (a); i >= (b); --i)
#define rep_(i, a, b) for (register int i = (a); i < (b).size(); ++i)
#define F(a) rep(a, 1, n)
#define M(a, b) memset(a, b, sizeof a)
#define DC                                                                                         \
    int T;                                                                                         \
    cin >> T;                                                                                      \
    while (T--)
#define ll long long
#define Z(a) sort(a + 1, a + n + 1)
using namespace std;
const unsigned _mod = 998244353;
const unsigned mod = 1e9 + 7;
const ll infi = 0x3f3f3f3f3f3f3fll;
const int inf = 0x3f3f3f3f;
void rd(auto& x)
{
    x = 0;
    int f = 1;
    char ch = getchar();
    while (ch < 48 || ch > 57)
    {
        if (ch == 45)
            f = -1;
        ch = getchar();
    }
    while (ch >= 48 && ch <= 57)
        x = x * 10 + ch - 48, ch = getchar();
    x *= f;
}
ll ksm(ll x, ll y = mod - 2, ll m = mod)
{
    ll ret = 1;
    while (y)
    {
        if (y & 1)
            ret = ret * x % m;
        y >>= 1ll;
        x = x * x % m;
    }
    return ret;
}
ll qpow(ll x, ll y)
{
    ll ret = 1;
    while (y)
    {
        if (y & 1ll)
            ret = ret * x;
        y >>= 1ll;
        x = x * x;
    }
    return ret;
}
/*
    [[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
    [[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
    [[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
*/
#define max(a, b) (a > b ? a : b)
#define min(a, b) (a < b ? a : b)
int n, m, k, q, ans = inf, s, x, y, z, a[1010][1010], mx[1010][1010];
int main()
{
    M(a, 0x3f);
    cin >> n >> m >> k >> q;
    rep(i, 1, q) rd(x), rd(y), rd(z), a[x][y] = z;
    F(i) rep(j, 1, m - k + 1) rep(_, 1, k) mx[i][j] = max(mx[i][j], a[i][j + _ - 1]);
    rep(i, 1, n - k + 1) rep(j, 1, m - k + 1)
    {
        s = 0;
        rep(_, 1, k) s = max(s, mx[i + _ - 1][j]);
        ans = min(ans, s);
    }
    cout << (ans == inf ? -1 : ans) << '\n';
    return 0;
}