﻿#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 510, M = N * N;

int sum[N][N];
int n, m, k, q;
struct E
{
    int x, y, t;

    bool operator<(const E temp) const
    {
        return t < temp.t;
    }
} edgs[M];


bool check(int mid)
{
    memset(sum, 0, sizeof sum);
    for (int i = 1; i <= mid; i++)
        sum[edgs[i].x][edgs[i].y] = 1;

    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            sum[i][j] += sum[i - 1][j] + sum[i][j - 1] - sum[i - 1][j - 1];


    for (int i = k; i <= n; i++)
        for (int j = k; j <= m; j++)
            if (sum[i][j] - sum[i - k][j] - sum[i][j - k] + sum[i - k][j - k] == k * k)
                return true;

    return false;
}


int main()
{
    scanf("%d %d %d %d", &n, &m, &k, &q);
    for (int i = 1; i <= q; i++)
    {
        int a, b, c;
        scanf("%d %d %d", &a, &b, &c);
        edgs[i] = { a, b, c };
    }

    sort(edgs + 1, edgs + 1 + q);

    int l = 1, r = q;
    while (l < r)
    {
        int mid = l + r >> 1;
        if (check(mid))
            r = mid;
        else
            l = mid + 1;
    }

    if (!check(q))
        printf("-1");
    else
        printf("%d", edgs[l].t);

    return 0;
}