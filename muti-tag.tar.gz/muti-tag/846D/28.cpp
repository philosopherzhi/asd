﻿#include <bits/stdc++.h>
using namespace std;

int main()
{

    int n, m, k, q;
    cin >> n >> m >> k >> q;

    vector<pair<int, pair<int, int> > > ar(q);
    for (auto& i : ar)
    {
        cin >> i.second.first >> i.second.second >> i.first;
    }
    sort(ar.begin(), ar.end());

    int lo = 0, hi = q - 1, mid, ans = -1;

    while (lo <= hi)
    {
        mid = (hi + lo) >> 1;

        vector<vector<int> > mat(n + 1, vector<int>(m + 1));
        for (int i = 0; i <= mid; i++)
            mat[ar[i].second.first][ar[i].second.second] = 1;

        bool f = false;
        for (int i = 1; i <= n and !f; i++)
        {
            for (int j = 1; j <= m; j++)
            {
                mat[i][j] = mat[i][j] + mat[i - 1][j] + mat[i][j - 1] - mat[i - 1][j - 1];
                if (i >= k and j >= k
                    and mat[i][j] - mat[i - k][j] - mat[i][j - k] + mat[i - k][j - k] == k * k)
                {
                    f = true;
                    break;
                }
            }
        }

        if (f)
        {
            ans = ar[mid].first;
            hi = mid - 1;
        }
        else
            lo = mid + 1;
    }

    cout << ans << endl;

    return 0;
}
