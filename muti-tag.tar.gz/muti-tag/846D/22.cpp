﻿#include <bits/stdc++.h>
using namespace std;
int n, m, k, p;
struct Node
{
    int x, y, t;
} a[250010];
bool cmp(Node x, Node y)
{
    return x.t < y.t;
}
int b[510][510];
int s[510][510];
bool check()
{
    memset(s, 0, sizeof(s));
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= m; j++)
        {
            s[i][j] = s[i - 1][j] + s[i][j - 1] - s[i - 1][j - 1] + b[i][j];
        }
    }
    for (int i = 1; i <= n - k + 1; i++)
    {
        for (int j = 1; j <= m - k + 1; j++)
        {
            int t1, t2;
            t1 = i + k - 1;
            t2 = j + k - 1;
            if (s[t1][t2] - s[i - 1][t2] - s[t1][j - 1] + s[i - 1][j - 1] == k * k)
            {
                return 1;
            }
        }
    }
    return 0;
}
int main()
{
    scanf("%d%d%d%d", &n, &m, &k, &p);
    for (int i = 1; i <= p; i++)
    {
        scanf("%d%d%d", &a[i].x, &a[i].y, &a[i].t);
    }
    sort(a + 1, a + p + 1, cmp);
    int f = 0;
    for (int i = 1; i <= p; i++)
    {
        b[a[i].x][a[i].y] = 1;
        if (i % 100 == 0)
        {
            if (check())
            {
                f = i;
                break;
            }
        }
    }
    if (!check())
    {
        cout << "-1\n";
        return 0;
    }
    else if (!f)
        f = p;
    memset(b, 0, sizeof(b));
    for (int i = 1; i <= f; i++)
    {
        b[a[i].x][a[i].y] = 1;
        if (i >= f - 100)
        {
            if (check())
            {
                cout << a[i].t;
                cout << endl;
                return 0;
            }
        }
    }
    return 0;
}
