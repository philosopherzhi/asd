﻿#include <bits/stdc++.h>

using namespace std;

#define LL long long
#define DD double
#define Pb push_back
#define Bp pop_back
#define Pf push_front
#define Fp pop_front
#define Ub upper_bound
#define Lb lower_bound
#define Bs binary_search
#define In insert
#define Mp make_pair
#define All(x) x.begin(), x.end()
#define mem(a, b) memset(a, b, sizeof(a))
#define fast                                                                                       \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0)
#define X first
#define Y second

const int mx1 = 15;
const int mx2 = 505;
const int mx3 = 1005;
const int mx4 = 30005;
const int mx5 = 250005;
const int mx6 = 1000005;

typedef vector<int> Vi;
typedef vector<DD> Vd;
typedef vector<bool> Vb;
typedef vector<Vi> VVi;
typedef pair<int, int> Pii;
typedef pair<DD, DD> Pdd;
typedef vector<Pii> Vpi;
typedef vector<Pdd> Vpd;
typedef queue<int> Qi;
typedef stack<int> Si;
typedef deque<int> Di;

int _toggle(int N, int pos)
{
    return N = N ^ (1 << pos);
}
int _set(int N, int pos)
{
    return N = N | (1 << pos);
}
int _reset(int N, int pos)
{
    return N = N & ~(1 << pos);
}
bool _check(int N, int pos)
{
    return (bool)(N & (1 << pos));
}
bool _upper(char a)
{
    return a >= 'A' && a <= 'Z';
}
bool _lower(char a)
{
    return a >= 'a' && a <= 'z';
}
bool _digit(char a)
{
    return a >= '0' && a <= '9';
}

int dx[] = { 1, -1, 0, 0, -1, -1, 1, 1 };
int dy[] = { 0, 0, 1, -1, -1, 1, -1, 1 };

///******************************************************///

int t, n, m, k, q, a[mx2][mx2], x[mx5], y[mx5];
Vpi id;

bool check(int N)
{
    mem(a, 0);
    for (int i = 0; i <= N; i++)
    {
        int j = id[i].Y;
        a[x[j]][y[j]] = 1;
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= m; j++)
        {
            a[i][j] += a[i][j - 1] + a[i - 1][j] - a[i - 1][j - 1];
        }
    }
    for (int i = k; i <= n; i++)
    {
        for (int j = k; j <= m; j++)
        {
            int now = a[i][j] - a[i - k][j] - a[i][j - k] + a[i - k][j - k];
            if (now == k * k)
            {
                return 1;
            }
        }
    }
    return 0;
}

void solve()
{
    cin >> n >> m >> k >> q;
    for (int i = 1; i <= q; i++)
    {
        cin >> x[i] >> y[i] >> t;
        id.Pb({ t, i });
    }
    sort(All(id));
    if (!check(q - 1))
    {
        cout << -1 << '\n';
        return;
    }
    int lo = 0, hi = q - 1, mid;
    while (lo <= hi)
    {
        mid = (lo + hi) >> 1;
        if (check(mid))
        {
            hi = mid - 1;
        }
        else
        {
            lo = mid + 1;
        }
    }
    cout << id[lo].X << '\n';
}

int main()
{
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
    fast;
    int tc = 1;
    // cin >> tc;
    while (tc--)
    {
        solve();
    }
}