﻿#include <bits/stdc++.h>
#define ll long long
using namespace std;
const ll INF = 0x7F7F7F7F7F7F7F7F;
ll brk[510][510], maxn[510][510];
int main()
{
    ll n, m, k, q, i, j, kk, res = INF;
    memset(brk, 0x7F, sizeof(brk));
    scanf("%lld %lld %lld %lld", &n, &m, &k, &q);
    for (i = 1; i <= q; i++)
    {
        ll x, y, t;
        scanf("%lld %lld %lld", &x, &y, &t);
        brk[x][y] = t;
    }
    for (i = 1; i <= n; i++)
        for (j = 1; j <= m - k + 1; j++)
            for (kk = 0; kk < k; kk++)
                maxn[i][j] = max(maxn[i][j], brk[i][j + kk]);
    for (i = 1; i <= n - k + 1; i++)
        for (ll j = 1; j <= m - k + 1; j++)
        {
            ll maxt = 0;
            for (kk = 0; kk < k; kk++)
                maxt = max(maxt, maxn[i + kk][j]);
            res = min(res, maxt);
        }
    if (res > 1e9)
    {
        printf("-1");
        return 0;
    }
    printf("%lld", res);
    return 0;
}
