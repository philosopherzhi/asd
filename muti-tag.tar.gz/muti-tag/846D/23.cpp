﻿#include <bits/stdc++.h>
#define f first
#define s second
#define fore(i, a, b) for (int i = (a), ThxMK = (b); i < ThxMK; ++i)
#define pb push_back
#define all(s) begin(s), end(s)
#define _                                                                                          \
    ios_base::sync_with_stdio(0);                                                                  \
    cin.tie(0);                                                                                    \
    cout.tie(0);
#define sz(s) int(s.size())
#define ENDL '\n'
#define vv(type, name, h, ...) vector<vector<type>> name(h, vector<type>(__VA_ARGS__))
#define vvv(type, name, h, w, ...)                                                                 \
    vector<vector<vector<type>>> name(h, vector<vector<type>>(w, vector<type>(__VA_ARGS__)))
using namespace std;
template <class t>
using vc = vector<t>;
template <class t>
using vvc = vc<vc<t>>;
typedef long long lli;
typedef pair<int, int> ii;
typedef vector<int> vi;
#define deb(x) cout << #x ": " << (x) << endl;

lli gcd(lli a, lli b)
{
    return (b ? gcd(b, a % b) : a);
}
lli lcm(lli a, lli b)
{
    if (!a || !b)
        return 0;
    return a * b / gcd(a, b);
}
int popcount(lli x)
{
    return __builtin_popcountll(x);
}

// mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
// int rnd(int n){return uniform_int_distribution<int>(0, n-1)(rng);}

lli poww(lli a, lli b)
{
    lli res = 1;
    while (b)
    {
        if (b & 1)
            res = res * a;
        a = a * a;
        b /= 2;
    }
    return res;
}

vvc<int> graph(int n, int m, bool dir = 1)
{
    vv(int, v, n + 1, 0);
    fore(i, 0, m)
    {
        int a, b;
        cin >> a >> b;
        v[a].pb(b);
        if (dir)
            v[b].pb(a);
    }
    return v;
}
template <typename T>
static constexpr T inf = numeric_limits<T>::max() / 2;
// ---- コーディングはここから！ ('-')7
#define MAXN 1024
#define op(a, b) (max(a, b))
#define NEUT 0

int n, m;
int a[MAXN][MAXN], st[2 * MAXN][2 * MAXN];
void build()
{
    fore(i, 0, n) fore(j, 0, m) st[i + n][j + m] = a[i][j];
    fore(i, 0, n) for (int j = m - 1; j; --j) st[i + n][j]
        = op(st[i + n][j << 1], st[i + n][j << 1 | 1]);
    for (int i = n - 1; i; --i)
        fore(j, 0, 2 * m) st[i][j] = op(st[i << 1][j], st[i << 1 | 1][j]);
}
void upd(int x, int y, int v)
{
    st[x + n][y + m] = v;
    for (int j = y + m; j > 1; j >>= 1)
        st[x + n][j >> 1] = op(st[x + n][j], st[x + n][j ^ 1]);
    for (int i = x + n; i > 1; i >>= 1)
        for (int j = y + m; j; j >>= 1)
            st[i >> 1][j] = op(st[i][j], st[i ^ 1][j]);
}
int query(int x0, int x1, int y0, int y1)
{
    int r = NEUT;
    for (int i0 = x0 + n, i1 = x1 + n; i0 < i1; i0 >>= 1, i1 >>= 1)
    {
        int t[4], q = 0;
        if (i0 & 1)
            t[q++] = i0++;
        if (i1 & 1)
            t[q++] = --i1;
        fore(k, 0, q) for (int j0 = y0 + m, j1 = y1 + m; j0 < j1; j0 >>= 1, j1 >>= 1)
        {
            if (j0 & 1)
                r = op(r, st[t[k]][j0++]);
            if (j1 & 1)
                r = op(r, st[t[k]][--j1]);
        }
    }
    return r;
}

void solve()
{
    int k, q;
    cin >> n >> m >> k >> q;
    n++, m++;
    fore(i, 0, n) fore(j, 0, m) a[i][j] = inf<int>;
    fore(i, 0, q)
    {
        int aa, bb, c;
        cin >> aa >> bb >> c;
        a[aa][bb] = c;
    }
    build();
    int mn = inf<int>;
    fore(i, 1, n) fore(j, 1, m)
    {
        int d = i + k;
        int r = j + k;
        if (d > n or r > m)
            continue;
        int u = query(i, d, j, r);
        if (u < inf<int>)
            mn = min(mn, u);
    }
    if (mn == inf<int>)
        mn = -1;
    cout << mn << ENDL;
}

int main()
{
    _
        //	int t; cin>>t; while(t--)
        solve();
}
