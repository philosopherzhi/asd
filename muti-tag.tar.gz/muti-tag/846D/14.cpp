﻿#include <bits/stdc++.h>
#include <iostream>
#define pb push_back
using namespace std;
typedef long long ll;
const int mxN = 502;
ll a[mxN][mxN];
vector<ll> rowMax[mxN];
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int m, n, k, q;
    cin >> m >> n >> k >> q;
    for (int j = 0; j < m; j++)
        for (int i = 0; i < n; i++)
            a[j][i] = 1e10;
    for (int i = 0; i < q; i++)
    {
        int y, x;
        ll t;
        cin >> y >> x >> t;
        y--, x--;
        a[y][x] = t;
    }
    deque<pair<int, ll>> current;
    for (int j = 0; j < m; j++)
    {
        for (int i = 0; i < n; i++)
        {
            while (current.size() && current.back().second <= a[j][i])
                current.pop_back();
            while (current.size() && current.front().first + k <= i)
                current.pop_front();
            current.push_back({ i, a[j][i] });
            if (i >= k - 1)
            {
                rowMax[j].push_back(current.front().second);
            }
        }
        current.clear();
    }
    ll ans = 1e10;
    for (int i = 0; i < rowMax[0].size(); i++)
    {
        for (int j = 0; j < m; j++)
        {
            while (current.size() && current.back().second <= rowMax[j][i])
                current.pop_back();
            while (current.size() && current.front().first + k <= j)
                current.pop_front();
            current.push_back({ j, rowMax[j][i] });
            if (j >= k - 1)
            {
                ans = min(ans, current.front().second);
            }
        }
        current.clear();
    }
    if (ans == 1e10)
        cout << "-1";
    else
        cout << ans;
}
/**
5 9 3 0
2 7 4 4 8 5 4 9 4
0 0 2 5 4 5 7 2 1
8 9 3 5 3 0 0 7 5
3 2 0 5 9 6 6 7 4
7 8 7 9 9 3 0 6 4

*/
