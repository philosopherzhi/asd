﻿#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
const int N = 510;
int mx[N + 10][N + 10];
int a[N + 10][N + 10];
int main()
{
    int n, m, k, q;
    scanf("%d%d%d%d", &n, &m, &k, &q);
    memset(a, 0x3f, sizeof(a));
    for (int i = 1; i <= q; i++)
    {
        int x, y, z;
        scanf("%d%d%d", &x, &y, &z);
        a[x][y] = z;
    }
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            mx[i][j] = a[i][j];
    for (int l = 2; l <= k; l++)
    {
        for (int i = 1; i + l - 1 <= n; i++)
            for (int j = 1; j + l - 1 <= m; j++)
                mx[i][j] = max(max(mx[i + 1][j], mx[i][j + 1]), max(a[i][j], mx[i + 1][j + 1]));
    }
    //	for(int i=1;i+k-1<=n;i++)
    //	{
    //		for(int j=1;j+k-1<=m;j++) printf("%d ",mx[i][j]);
    //		puts("");
    //	}
    int ans = 0x3f3f3f3f;
    for (int i = 1; i + k - 1 <= n; i++)
        for (int j = 1; j + k - 1 <= m; j++)
            ans = min(ans, mx[i][j]);
    if (ans == 0x3f3f3f3f)
        printf("-1");
    else
        printf("%d", ans);
    return 0;
}