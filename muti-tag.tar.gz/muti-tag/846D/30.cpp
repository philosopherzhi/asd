﻿#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll MAX = 1e9 + 1;
struct pixel
{
    int x, y, ti;
};
bool ord(pixel a, pixel b)
{
    return a.ti < b.ti;
}
vector<pixel> tv;
int n, m, k, q;
int pan[510][510];
bool check(int t)
{
    for (int i = 0; i <= n; i++)
        for (int j = 0; j <= m; j++)
            pan[i][j] = 0;
    for (int i = 0; i < q; i++)
    {
        if (tv[i].ti <= t)
            pan[tv[i].x][tv[i].y]++;
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= m; j++)
        {
            pan[i][j] += pan[i - 1][j] + pan[i][j - 1] - pan[i - 1][j - 1];
        }
    }
    for (int i = 1; i + k - 1 <= n; i++)
    {
        for (int j = 1; j + k - 1 <= m; j++)
        {
            int xi, yi;
            xi = i + k - 1;
            yi = j + k - 1;
            int np = pan[xi][yi] + pan[i - 1][j - 1] - pan[xi][j - 1] - pan[i - 1][yi];
            if (np == k * k)
                return 1;
        }
    }
    return 0;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    cin >> n >> m >> k >> q;
    memset(pan, 0, sizeof pan);
    for (int i = 0; i < q; i++)
    {
        int a, b, c;
        cin >> a >> b >> c;
        pixel aux = { a, b, c };
        tv.push_back(aux);
    }
    sort(tv.begin(), tv.end(), ord);
    ll l = -1, r = MAX;
    while (r - l > 1)
    {
        ll mid = (l + r) / 2;
        if (check(mid))
        {
            r = mid;
        }
        else
            l = mid;
    }
    if (r == MAX)
        r = -1;
    cout << r << "\n";
}
