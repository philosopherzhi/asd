﻿#include <bits/stdc++.h>
#define INF -10e10
using namespace std;
typedef long long ll;
const int N = 250010;
int n, m, k, q;
ll mat[505][505];
ll x[N];
ll y[N];
ll t[N];
bool check(int mid)
{
    memset(mat, 0, sizeof(mat));
    for (int i = 0; i < q; i++)
        if (t[i] <= mid)
            mat[x[i] - 1][y[i] - 1] = 1;

    for (int i = 0; i < n; i++)
        for (int j = 1; j < m; j++)
            mat[i][j] += mat[i][j - 1];
    for (int j = 0; j < m; j++)
        for (int i = 1; i < n; i++)
            mat[i][j] += mat[i - 1][j];
    for (int i = 0; i < n - k + 1; i++)
        for (int j = 0; j < m - k + 1; j++)
        {
            int sum = 0;
            int i2 = i + k - 1;
            int j2 = j + k - 1;
            int a = 0, b = 0, c = 0, d = 0;
            if (i2 >= 0 && j2 >= 0)
                a = mat[i2][j2];
            if (i2 >= 0 && j >= 1)
                b = mat[i2][j - 1];
            if (i >= 1 && j2 >= 0)
                c = mat[i - 1][j2];
            if (i >= 1 && j >= 1)
                d = mat[i - 1][j - 1];
            sum = a - b - c + d;
            if (sum == k * k)
                return true;
        }
    return false;
}
int main()
{
    memset(mat, 0, sizeof(mat));
    cin >> n >> m >> k >> q;
    ll h = INT_MIN;
    for (int i = 0; i < q; i++)
    {
        cin >> x[i] >> y[i] >> t[i];
        h = max(h, t[i]);
    }
    ll l = 0;
    while (l <= h)
    {
        int m = (l + h) / 2;
        if (!check(m))
            l = m + 1;
        else
        {
            if (!check(m - 1))
            {
                cout << m;
                return 0;
            }
            else
                h = m - 1;
        }
    }

    cout << -1;
    return 0;
}
