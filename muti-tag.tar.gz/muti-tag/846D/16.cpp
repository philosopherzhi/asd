﻿#include <bits/stdc++.h>
using namespace std;
bool func(int val, vector<vector<int>>& mat, int n, int m, int len)
{
    vector<vector<int>> v(n + 1, vector<int>(m + 1, 0));
    for (int i = 0; i < mat.size(); i++)
    {
        if (mat[i][2] <= val)
            v[mat[i][0]][mat[i][1]] = 1;
    }
    for (int i = 1; i <= m; i++)
        v[0][i] += v[0][i - 1];

    for (int i = 1; i <= n; i++)
        v[i][0] += v[i - 1][0];

    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= m; j++)
        {
            v[i][j] = v[i][j] + v[i - 1][j] + v[i][j - 1] - v[i - 1][j - 1];
        }
    }

    for (int i = len; i <= n; i++)
    {
        for (int j = len; j <= m; j++)
        {
            if (v[i][j] - (i - len <= 0 ? 0 : v[i - len][j]) - (j - len <= 0 ? 0 : v[i][j - len])
                    + (i - len <= 0 || j - len <= 0 ? 0 : v[i - len][j - len])
                == len * len)
                return true;
        }
    }
    return false;
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m, k, q;
    cin >> n >> m >> k >> q;
    vector<vector<int>> mat(q, vector<int>(3));
    int high = -1;
    for (int i = 0; i < q; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            cin >> mat[i][j];
            if (j == 2 && mat[i][2] > high)
                high = mat[i][2];
        }
    }

    int low = 0;
    bool exists = false;
    while (low <= high)
    {
        int mid = low + (high - low) / 2;
        bool res = func(mid, mat, n, m, k);
        if (!res)
            low = mid + 1;
        else
        {
            exists = true;
            high = mid - 1;
        }
    }
    if (exists == false)
        cout << "-1" << endl;
    else
        cout << low << endl;
    return 0;
}