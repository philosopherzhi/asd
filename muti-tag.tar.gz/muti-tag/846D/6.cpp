﻿#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define pb push_back
#define F first
#define S second

const int N = 5e2 + 5;
int n, m, k, q, ans = -1;
bool v[N][N];
int pre[N][N];

struct query
{
    ll x = 0, y = 0, t = 0;
} Q[N * N];

bool ok(ll mid)
{
    bool ff = 0;

    for (int i = 1; i <= q; i++)
        if (Q[i].t <= mid)
            v[Q[i].x][Q[i].y] = 1;

    for (int i = 1; i <= m; i++)
        pre[1][i] = pre[1][i - 1] + v[1][i];

    for (int i = 1; i <= n; i++)
        pre[i][1] = pre[i - 1][1] + v[i][1];

    for (int i = 2; i <= n; i++)
        for (int j = 2; j <= m; j++)
            pre[i][j] = pre[i - 1][j] + pre[i][j - 1] - pre[i - 1][j - 1] + v[i][j];

    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
        {
            if (j < k || i < k)
                continue;
            int sm = pre[i][j] - pre[i][j - k] - pre[i - k][j] + pre[i - k][j - k];
            //     cout<<i<<" "<<j<<" "<<sm<<"\n";
            if (sm == k * k)
                ff = 1;
        }
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            pre[i][j] = 0;

    for (int i = 1; i <= q; i++)
        if (Q[i].t <= mid)
            v[Q[i].x][Q[i].y] = 0;
    return ff;
}

int main()
{
#ifdef Mohammad
    freopen("input.in", "r", stdin);
#endif
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin >> n >> m >> k >> q;
    for (int i = 1; i <= q; i++)
        cin >> Q[i].x >> Q[i].y >> Q[i].t;

    //  sort(Q+1, Q+1+q, comp) ;

    ll low = 0, hei = 1e9 + 6, mid;
    while (low <= hei)
    {
        mid = low + hei + 1 >> 1;

        if (ok(mid))
        {
            ans = mid;
            hei = mid - 1;
        }
        else
            low = mid + 1;
    }
    //  ok(1) ;
    cout << ans;

    //  cout<<ok(8);
}
