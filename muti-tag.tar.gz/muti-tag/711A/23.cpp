﻿#include <bits/stdc++.h>
#define ll long long
#define endl ("\n")
#define f(i, a, n) for (ll i = a; i < n; i++)
using namespace std;


int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    ll t;
    t = 1;
    // cin>>t;
    while (t--)
    {
        ll n, row, col;
        cin >> n;
        string s[n];
        bool k = true;
        f(i, 0, n)
        {
            cin >> s[i];
            if (s[i][0] == 'O' && s[i][1] == 'O' && k)
            {
                row = i, col = 0, k = false;
            }
            if (s[i][3] == 'O' && s[i][4] == 'O' && k)
            {
                row = i, col = 3, k = false;
            }
        }
        if (k)
            cout << "NO";
        else
        {
            cout << "YES\n";
            f(i, 0, n)
            {
                if (i == row)
                    s[i][col] = '+', s[i][col + 1] = '+';
                cout << s[i] << endl;
            }
        }
    }
}
