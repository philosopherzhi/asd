﻿#include <bits/stdc++.h>

using namespace std;
int n, i;
string s;
bool b = false;
char v[1002][5];

int main()
{
    cin >> n;
    for (i = 0; i < n; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            cin >> v[i][j];
            if (v[i][0] == 'O' && v[i][1] == 'O' && b == false)
            {

                v[i][0] = '+';
                v[i][1] = '+';
                b = true;
            }
            else if (v[i][3] == 'O' && v[i][4] == 'O' && b == false)
            {
                v[i][3] = '+';
                v[i][4] = '+';
                b = true;
            }
        }
    }
    if (b)
    {
        cout << "YES" << endl;
        for (i = 0; i < n; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                cout << v[i][j];
            }
            cout << endl;
        }
    }
    else
        cout << "NO";

    return 0;
}
