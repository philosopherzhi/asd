﻿#include <iostream>
#include <string>
#include <cstdio>
#include <cmath>
#include <iomanip>
#include <algorithm>

#define fori for (int i = 0; i < n; i++)
#define forim for (int i = 0; i < m; i++)
#define forjm for (int j = 0; j < m; j++)

int min(int a, int b, int c)
{
    int min;
    min = (a > b) ? ((b > c) ? c : b) : ((a > c) ? c : a);
    return min;
}
using namespace std;
int main()
{
    int n;
    cin >> n;
    char s[n][5];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            cin >> s[i][j];
        }
    }
    // for(int i = 0 ; i < n ; i++)
    // {
    //     for(int j = 0 ; j < 5 ; j++)
    //     {
    //         cout << s[i][j];
    //     }
    //     cout << endl;
    // }
    int c = 0;
    fori
    {
        if (s[i][0] == s[i][1] && s[i][1] == 'O')
        {
            s[i][0] = '+';
            s[i][1] = '+';
            c++;
            break;
        }
        if (s[i][3] == s[i][4] && s[i][3] == 'O')
        {
            s[i][3] = '+';
            s[i][4] = '+';
            c++;
            break;
        }
    }
    if (c > 0)
    {
        cout << "YES\n";
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                cout << s[i][j];
            }
            cout << endl;
        }
    }
    else
        cout << "NO\n";
    return 0;
}