﻿#include <bits/stdc++.h>
#define ll long long
using namespace std;
void __print(int x)
{
    cerr << x;
}
void __print(long x)
{
    cerr << x;
}
void __print(long long x)
{
    cerr << x;
}
void __print(unsigned x)
{
    cerr << x;
}
void __print(unsigned long x)
{
    cerr << x;
}
void __print(unsigned long long x)
{
    cerr << x;
}
void __print(float x)
{
    cerr << x;
}
void __print(double x)
{
    cerr << x;
}
void __print(long double x)
{
    cerr << x;
}
void __print(char x)
{
    cerr << '\'' << x << '\'';
}
void __print(const char* x)
{
    cerr << '\"' << x << '\"';
}
void __print(const string& x)
{
    cerr << '\"' << x << '\"';
}
void __print(bool x)
{
    cerr << (x ? "true" : "false");
}
template <typename T, typename V>
void __print(const pair<T, V>& x)
{
    cerr << '{';
    __print(x.first);
    cerr << ',';
    __print(x.second);
    cerr << '}';
}
template <typename T>
void __print(const T& x)
{
    int f = 0;
    cerr << '{';
    for (auto& i : x)
        cerr << (f++ ? "," : ""), __print(i);
    cerr << "}";
}
void _print()
{
    cerr << "]\n";
}
template <typename T, typename... V>
void _print(T t, V... v)
{
    __print(t);
    if (sizeof...(v))
        cerr << ", ";
    _print(v...);
}
#ifndef ONLINE_JUDGE
#define debug(x...)                                                                                \
    cerr << "[" << #x << "] = [";                                                                  \
    _print(x)
#else
#define debug(x...)
#endif

struct tri
{
    ll v;
    ll l;
    bool c;
};
int myXOR(int x, int y)
{
    return (x | y) & (~x | ~y);
}
int gcd(unsigned long long a, int b)
{
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

void solve()
{
    int n;
    cin >> n;
    vector<string> v;
    bool ok = false;
    for (int i = 0; i < n; i++)
    {
        string p;
        cin >> p;
        if (p[0] == 'O' && p[1] == 'O' && ok == false)
        {
            p[0] = '+';
            p[1] = '+';
            ok = true;
        }
        else if (p[3] == 'O' && p[4] == 'O' && ok == false)
        {
            p[3] = '+';
            p[4] = '+';
            ok = true;
        }
        v.push_back(p);
    }

    if (ok == true)
    {
        cout << "YES" << endl;
        for (int i = 0; i < v.size(); i++)
        {
            cout << v[i] << endl;
        }
    }
    else
    {
        cout << "NO" << endl;
    }
}

int main()
{
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    freopen("error.txt", "w", stderr);
#endif
    ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
    ll t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
    return 0;
}