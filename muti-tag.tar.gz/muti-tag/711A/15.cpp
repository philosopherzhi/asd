﻿#include <iostream>
#include <string>
#include <cmath>
using namespace std;

int main()
{
    int n;
    cin >> n;
    char a[n][5];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            cin >> a[i][j];
        }
    }
    bool f = false;
    for (int i = 0; i < n; i++)
    {
        if (a[i][0] == 'O' && a[i][1] == 'O')
        {
            a[i][0] = '+';
            a[i][1] = '+';
            f = true;
            break;
        }
        if (a[i][3] == 'O' && a[i][4] == 'O')
        {
            a[i][3] = '+';
            a[i][4] = '+';
            f = true;
            break;
        }
    }
    if (f)
    {
        cout << "YES" << endl;
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                cout << a[i][j];
            }
            cout << endl;
        }
    }
    else
    {
        cout << "NO";
    }
}
