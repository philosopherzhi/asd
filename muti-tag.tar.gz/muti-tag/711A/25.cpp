﻿#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin >> n;
    string str;
    bool b = false;
    vector<string> vc;

    for (int i = 0; i < n; i++)
    {
        cin >> str;
        if (str[0] == 'O' && str[1] == 'O' && b == false)
        {
            str[0] = str[1] = '+';
            b = true;
        }
        else if (str[3] == 'O' && str[4] == 'O' && b == false)
        {
            str[3] = str[4] = '+';
            b = true;
        }
        vc.push_back(str);
    }
    if (b)
    {
        cout << "YES" << endl;
        for (int i = 0; i < vc.size(); i++)
            cout << vc[i] << endl;
    }

    else
    {
        cout << "NO" << endl;
    }


    return 0;
}
