﻿#include <iostream>
using namespace std;

int main()
{
    int n;
    cin >> n;
    string s[n];
    for (int i = 0; i < n; i++)
        cin >> s[i];

    bool found = false;
    for (int i = 0; i < n; i++)
    {
        if (s[i][0] == 'O' && s[i][1] == 'O')
        {
            s[i][0] = s[i][1] = '+';
            found = true;
            break;
        }
        if (s[i][3] == 'O' && s[i][4] == 'O')
        {
            s[i][3] = s[i][4] = '+';
            found = true;
            break;
        }
    }
    if (found)
    {
        cout << "YES" << endl;
        for (int i = 0; i < n; i++)
            cout << s[i] << endl;
    }
    else
        cout << "NO";

    return 0;
}
