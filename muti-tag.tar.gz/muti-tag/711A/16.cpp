﻿#include <bits/stdc++.h>
using namespace std;

int main()
{
    // your code goes here
    int n;
    cin >> n;
    string s;
    vector<string> s1, s2;
    for (int i = 0; i < n; i++)
    {
        cin >> s;
        s1.push_back(s);
    }
    int flag = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            if (s1[i][j] == 'O' && s1[i][j + 1] == 'O' && j != 4)
            {
                flag = 1;
                s1[i][j] = '+';
                s1[i][j + 1] = '+';
                break;
            }
        }
        if (flag == 1)
            break;
    }
    if (flag == 1)
    {
        cout << "YES" << endl;
        for (int i = 0; i < n; i++)
        {
            cout << s1[i] << endl;
        }
    }
    else
        cout << "NO" << endl;
    return 0;
}
