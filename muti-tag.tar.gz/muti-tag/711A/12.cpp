﻿#include <iostream>
#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <set>
#include <vector>
#include <iomanip>
#include <string>
#include <map>
using namespace std;

int main()
{
    // freopen("input.txt","r",stdin);
    int n;
    cin >> n;
    vector<string> a;
    bool flag = true;
    for (int i = 0; i < n; i++)
    {
        string s;
        cin >> s;
        if ((s[0] == 'O') & (s[1] == 'O') & (flag == true))
        {
            s[0] = '+';
            s[1] = '+';
            flag = false;
            a.push_back(s);
        }
        else if ((s[3] == 'O') & (s[4] == 'O') & (flag == true))
        {
            s[3] = '+';
            s[4] = '+';
            flag = false;
            a.push_back(s);
        }
        else
        {
            a.push_back(s);
        }
    }

    if (flag == false)
    {
        cout << "YES" << endl;
        for (int i = 0; i < n; i++)
        {
            cout << a[i] << endl;
        }
    }
    else
    {
        cout << "NO" << endl;
    }

    return 0;
}
