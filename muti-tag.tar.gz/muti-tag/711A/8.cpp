﻿#include <bits/stdc++.h>
using namespace std;

int n;
char inp[1000 + 10][5 + 10];

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%s", inp[i]);
    }
    for (int i = 0; i < n; i++)
    {
        for (int j : { 0, 3 })
        {
            if (inp[i][j] == 'O' && inp[i][j + 1] == 'O')
            {
                inp[i][j] = inp[i][j + 1] = '+';
                printf("YES\n");
                for (int x = 0; x < n; x++)
                {
                    printf("%s\n", inp[x]);
                }
                exit(0);
            }
        }
    }
    printf("NO\n");
}
