﻿#include <bits/stdc++.h>

using namespace std;

char arr[1008][6];


int main()
{
    int n, flag = 0;
    cin >> n;

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            cin >> arr[i][j];
        }
    }

    for (int i = 0; i < n; i++)
    {
        if (arr[i][0] == 'O' && arr[i][1] == 'O')
        {
            arr[i][0] = '+';
            arr[i][1] = '+';
            flag = 1;
            break;
        }

        if (arr[i][3] == 'O' && arr[i][4] == 'O')
        {
            arr[i][3] = '+';
            arr[i][4] = '+';
            flag = 1;
            break;
        }
    }

    if (flag)
    {
        cout << "YES" << endl;

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                cout << arr[i][j];
            }
            cout << "\n";
        }
    }
    else
        cout << "NO" << endl;
}
