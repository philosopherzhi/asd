﻿#include <bits/stdc++.h>
using namespace std;

string s[1000111];
string res = "NO";

int main()
{
    int n;
    cin >> n;


    for (int i = 1; i <= n; i++)
    {
        cin >> s[i];

        if (res == "YES")
            continue;

        if (s[i][0] == s[i][1] and s[i][0] == 'O')
        {
            s[i][0] = '+';
            s[i][1] = '+';
            res = "YES";
        }

        if (res == "YES")
            continue;

        if (s[i][3] == s[i][4] and s[i][3] == 'O')
        {
            s[i][3] = '+';
            s[i][4] = '+';
            res = "YES";
        }
    }
    cout << res << "\n";
    if (res == "YES")
        for (int i = 1; i <= n; i++)
            cout << s[i] << "\n";
}