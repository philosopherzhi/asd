﻿#include <iostream>

using namespace std;

int main()
{
    int n, done = 0;
    cin >> n;
    char s[n][5];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            cin >> s[i][j];
        }
    }
    for (int i = 0; i < n; i++)
    {
        if (s[i][0] == 'O' && s[i][1] == 'O')
        {
            s[i][0] = '+';
            s[i][1] = '+';
            done = 1;
            break;
        }
        else if (s[i][3] == 'O' && s[i][4] == 'O')
        {
            s[i][3] = '+';
            s[i][4] = '+';
            done = 1;
            break;
        }
    }
    if (done)
    {
        cout << "YES" << endl;
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                cout << s[i][j];
            }
            cout << endl;
        }
    }
    else
        cout << "NO" << endl;
    return 0;
}
