﻿#include <bits/stdc++.h>
#define ll long long
#define fo(i, n) for (i = 0; i < n; i++)
#define fok(i, k, n) for (i = k; i < n; i++)
#define pb push_back
#define FLASH ios_base::sync_with_stdio(false), cin.tie(NULL);
#define float long double
#define fre(input, output)                                                                         \
    freopen(input, "r", stdin);                                                                    \
    freopen(output, "w", stdout);
using namespace std;

int main()
{
    FLASH
    int row;
    cin >> row;
    string s[row];
    int cnt = -1, j = 0;
    for (int i = 0; i < row; i++)
    {
        cin >> s[i];
        if ((s[i][0] == 'O' && s[i][1] == 'O' && j < 1)
            || (s[i][3] == 'O' && s[i][4] == 'O' && j < 1))
        {
            cout << "YES\n";
            cnt = i;
            ++j;
        }
    }
    if (cnt == -1)
    {
        cout << "NO";
        return 0;
    }
    else
    {
        for (int i = 0; i < row; i++)
        {
            if (i == cnt)
            {
                if (s[i][0] == 'O' && s[i][1] == 'O')
                {
                    cout << "++" << s[i][2] << s[i][3] << s[i][4] << '\n';
                    cnt = i;
                }
                else
                {
                    cout << s[i][0] << s[i][1] << s[i][2] << "++\n";
                    cnt = i;
                }
            }
            else
            {
                cout << s[i] << '\n';
            }
        }
    }
    return 0;
}