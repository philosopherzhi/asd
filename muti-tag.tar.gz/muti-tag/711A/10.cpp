﻿#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

void solve()
{
    ll n;
    cin >> n;
    vector<string> arr;
    string s;
    for (int i = 0; i < n; i++)
    {
        cin >> s;
        arr.push_back(s);
    }
    bool flag = true;
    for (int i = 0; i < n; i++)
    {
        if (arr[i][0] == 'O' and arr[i][1] == 'O')
        {
            arr[i][0] = '+';
            arr[i][1] = '+';
            flag = false;
            break;
        }
        if (arr[i][3] == 'O' and arr[i][4] == 'O')
        {
            arr[i][3] = '+';
            arr[i][4] = '+';
            flag = false;
            break;
        }
    }
    if (flag)
        cout << "NO";
    else
    {
        cout << "YES\n";
        for (auto i : arr)
            cout << i << endl;
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    // ll t;
    // cin >> t;
    // while (t--)
    // {
    //     solve();
    // }
    solve();
    return 0;
}