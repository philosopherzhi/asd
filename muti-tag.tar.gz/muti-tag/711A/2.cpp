﻿#include <stdio.h>

int main()
{
    int n, i, c = 0;
    char B[1000][6];
    char g;

    scanf("%d", &n);
    for (i = 0; i < n; ++i)
    {
        scanf("%s", B[i]);
        if (!c && B[i][0] == 'O' && B[i][1] == 'O')
        {
            c = 1;
            B[i][0] = '+';
            B[i][1] = '+';
        }
        if (!c && B[i][3] == 'O' && B[i][4] == 'O')
        {
            c = 1;
            B[i][3] = '+';
            B[i][4] = '+';
        }
    }
    if (c)
    {
        printf("YES\n");
        for (i = 0; i < n; ++i)
        {
            printf("%s\n", B[i]);
        }
    }
    else
    {
        printf("NO");
    }
    return 0;
}
