﻿#include <iostream>
#include <vector>
using namespace std;
int main()
{
    int n;
    vector<string> v;
    cin >> n;
    string s;
    for (int i = 0; i < n; ++i)
    {
        cin >> s;
        v.push_back(s);
    }
    bool ans = false;
    for (int i = 0; i < n; ++i)
    {
        if (v[i].at(0) == 'O' and v[i].at(1) == 'O')
        {
            v[i].at(0) = '+';
            v[i].at(1) = '+';
            ans = true;
            break;
        }
        else if (v[i].at(3) == 'O' and v[i].at(4) == 'O')
        {
            v[i].at(3) = '+';
            v[i].at(4) = '+';
            ans = true;
            break;
        }
    }
    if (ans)
    {
        cout << "YES" << endl;
        for (auto x : v)
        {
            cout << x << endl;
        }
    }
    else
        cout << "NO";
    return 0;
}