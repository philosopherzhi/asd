﻿#include <bits/stdc++.h>

int main()
{
    int t;
    std::cin >> t;
    std::vector<std::string> ris;
    bool flag = false;
    while (t--)
    {
        std::string s;
        std::cin >> s;
        std::string k;
        if (!flag)
        {
            if (s[0] == 'O' && s[1] == 'O')
            {
                flag = true;
                k = "++|" + s.substr(3, 2);
            }
            else if (s[3] == 'O' && s[4] == 'O')
            {
                flag = true;
                k = s.substr(0, 2) + "|++";
            }
            else
                k = s;
        }
        else
        {
            k = s;
        }
        ris.push_back(k);
    }
    if (flag)
    {
        std::cout << "YES" << std::endl;
        for (auto s : ris)
            std::cout << s << std::endl;
    }
    else
        std::cout << "NO" << std::endl;
    return 0;
}
