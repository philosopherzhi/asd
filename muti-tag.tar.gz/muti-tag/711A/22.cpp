﻿#include <bits/stdc++.h>

using namespace std;

int main()
{
    int n;
    cin >> n;
    char a[n][5];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < 5; j++)
            cin >> a[i][j];
    }
    bool ch = false;
    for (int i = 0; i < n && !ch; i++)
    {
        for (int j = 0; j < 5 && !ch; j++)
        {
            if (j + 1 < 5 && a[i][j] == 'O' && a[i][j + 1] == 'O')
            {
                ch = true;
                a[i][j] = '+';
                a[i][j + 1] = '+';
                break;
            }
        }
    }
    if (ch)
    {
        cout << "YES\n";
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < 5; j++)
                cout << a[i][j];
            cout << endl;
        }
    }
    else
        cout << "NO";
    return 0;
}
