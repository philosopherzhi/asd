﻿#include <iostream>
using namespace std;
int main()
{
    long long n, m = 5, i, j, c = 0;
    char s[1001][1001];
    cin >> n;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            cin >> s[i][j];
        }
    }
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            if (s[i][j] == 'O' && s[i][j + 1] == 'O')
            {
                s[i][j] = '+';
                s[i][j + 1] = '+';
                i = n;
                j = m;
            }
            else
            {
                c++;
            }
        }
    }
    if (c == n * m)
    {
        cout << "NO" << endl;
    }
    else
    {
        cout << "YES" << endl;

        for (i = 0; i < n; i++)
        {
            for (j = 0; j < m; j++)
            {
                cout << s[i][j];
            }
            cout << endl;
        }
    }
}
