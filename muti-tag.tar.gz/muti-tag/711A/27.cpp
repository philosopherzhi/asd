﻿#include <bits/stdc++.h>


using namespace std;
typedef long long ll;


int main()
{
    char a[1001][1001];
    bool q = 0;
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= 5; j++)
        {
            cin >> a[i][j];
        }
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= 5; j++)
        {
            if (a[i][j] == 'O' && a[i][j + 1] == 'O')
            {
                a[i][j] = '+';
                a[i][j + 1] = '+';
                q = 1;
                break;
            }
        }
        if (q)
            break;
    }
    if (q)
    {
        cout << "YES\n";
        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= 5; j++)
            {
                cout << a[i][j];
            }
            cout << endl;
        }
    }
    else
        cout << "NO";
}
