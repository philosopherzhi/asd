﻿#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    char a[n][5];
    bool y = true;
    for (int i = 0; i < n; i++)
    {
        cin >> a[i][0] >> a[i][1];
        if (y && a[i][0] == 'O' && a[i][1] == 'O')
        {
            a[i][0] = '+';
            a[i][1] = '+';
            y = false;
        }
        cin >> a[i][2];
        cin >> a[i][3] >> a[i][4];
        if (y && a[i][3] == 'O' && a[i][4] == 'O')
        {
            a[i][3] = '+';
            a[i][4] = '+';
            y = false;
        }
    }
    if (y)
        cout << "NO" << endl;
    else
    {
        cout << "YES" << endl;
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < 5; j++)
                cout << a[i][j];
            cout << endl;
        }
    }
}
