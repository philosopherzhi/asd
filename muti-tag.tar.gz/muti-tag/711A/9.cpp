﻿#include <iostream>
#include <string>
using namespace std;
string s[1005]; //存一堆字符串
int main()
{
    int n;
    cin >> n;
    bool g = false; //判断Yes或No
    for (int i = 0; i < n; i++)
    {
        cin >> s[i]; //进去
        if (g == false)
        {
            if (s[i][0] == 'O' && s[i][1] == 'O')
            {
                s[i][0] = '+';
                s[i][1] = '+'; //变！！
                cout << "Yes" << endl;
                g = true;
            }
            else if (s[i][3] == 'O' && s[i][4] == 'O')
            {
                s[i][3] = '+';
                s[i][4] = '+'; //我再变！！
                cout << "Yes" << endl;
                g = true;
            } //一定要加else，不然会变两次
        }
    }
    if (g == false)
    {
        cout << "No" << endl; //我说不！
    }
    else
        for (int i = 0; i < n; i++)
        {
            cout << s[i] << endl; //出去
        }
    return 0; //走了走了
}