﻿#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    string s[n];
    bool f = true;
    for (int i = 0; i < n; i++)
    {
        cin >> s[i];
    }
    for (int i = 0; i < n; i++)
    {
        if (s[i][0] == 'O' and s[i][1] == 'O')
        {
            f = false;
            s[i][0] = '+';
            s[i][1] = '+';
            break;
        }
        else if (s[i][3] == 'O' and s[i][4] == 'O')
        {
            f = false;
            s[i][3] = '+';
            s[i][4] = '+';
            break;
        }
    }
    if (f)
        cout << "NO";
    else
    {
        cout << "YES\n";
        for (int i = 0; i < n; i++)
        {
            cout << s[i] << endl;
        }
    }
    return 0;
}