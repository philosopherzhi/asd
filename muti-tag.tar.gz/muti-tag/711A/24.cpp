﻿#include <iostream>
#include <algorithm>
#include <vector>
#include <cmath>
#include <string>
#include <iomanip>

using namespace std;
void solve(int tc);

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n;
    cin >> n;

    string* arr = new string[n];
    bool isDone = false;
    for (int i = 0; i < n; i++)
        cin >> arr[i];

    for (int i = 0; i < n; i++)
    {
        if (isDone)
            break;
        for (int j = 1; j < 5; j++)
        {
            if (arr[i][j] == 'O' && arr[i][j - 1] == 'O')
            {
                arr[i][j] = '+';
                arr[i][j - 1] = '+';
                isDone = true;
                break;
            }
        }
    }

    if (isDone)
    {
        cout << "YES\n";
        for (int i = 0; i < n; i++)
            cout << arr[i] << "\n";
    }
    else
        cout << "NO\n";

    delete[] arr;
    return 0;
}