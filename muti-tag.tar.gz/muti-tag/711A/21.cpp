﻿#include <bits/stdc++.h>

using namespace std;

#define IOS                                                                                        \
    ios::sync_with_stdio(0);                                                                       \
    cin.tie(0);                                                                                    \
    cout.tie(0);
#define endl "\n"
#define int long long

int32_t main()
{
    int n;
    bool check = false;
    string str;
    vector<string> S;
    cin >> n;
    for (int z = 0; z < n; z++)
    {
        cin >> str;
        S.push_back(str);
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            if (S[i][j] == 'O' && S[i][j + 1] == 'O')
            {
                S[i][j] = '+';
                S[i][j + 1] = '+';
                check = true;
                break;
            }
        }
        if (check)
            break;
    }
    if (check)
    {
        cout << "YES\n";
        for (int i = 0; i < n; i++)
            cout << S[i] << "\n";
    }
    else
        cout << "NO\n";
}
