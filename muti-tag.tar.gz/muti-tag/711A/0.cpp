﻿#include <iostream>
using namespace std;

char asientos[1200][10];

int main()
{
    int n;
    cin >> n;

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            cin >> asientos[i][j];
        }
    }

    bool disponibles = false;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            if (asientos[i][j] == 'O' && asientos[i][j] == asientos[i][j + 1])
            {
                asientos[i][j] = '+';
                asientos[i][j + 1] = '+';
                disponibles = true;
                break;
            }
        }
        if (disponibles == true)
        {
            break;
        }
    }

    if (disponibles == true)
    {
        cout << "YES\n";
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                cout << asientos[i][j];
            }
            cout << "\n";
        }
    }
    else
    {
        cout << "NO";
    }


    return 0;
}